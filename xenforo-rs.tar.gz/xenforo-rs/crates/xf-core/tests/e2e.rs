//! End-to-end tests: boot an in-memory App, seed it, and exercise the full
//! request pipeline (MVC → controllers → templates → DB) without a network.
//!
//! These mirror the XenForo pub flows: forum list, forum view, thread view
//! (BBCode rendering), registration and replying.
use std::collections::HashMap;
use xf_core::app::App;
use xf_core::config::Config;
use xf_core::mvc::{Method, Request};

fn cfg() -> Config {
    Config {
        db_path: ":memory:".into(),
        board_title: "Test board".into(),
        ..Config::default()
    }
}

fn get(path: &str) -> Request {
    Request {
        method: Method::Get,
        path: path.trim_start_matches('/').to_string(),
        ..empty()
    }
}

fn post(path: &str, form: Vec<(&str, &str)>) -> Request {
    let mut req = Request {
        method: Method::Post,
        path: path.trim_start_matches('/').to_string(),
        ..empty()
    };
    for (k, v) in form {
        req.form.insert(k.into(), v.into());
    }
    req
}

fn empty() -> Request {
    Request {
        method: Method::Get,
        path: String::new(),
        query: HashMap::new(),
        form: HashMap::new(),
        headers: HashMap::new(),
        cookies: HashMap::new(),
        remote_ip: "127.0.0.1".into(),
        response_type: String::new(),
        visitor: None,
    }
}

/// Extract the session id from a `Set-Cookie` header in the response.
fn session_id_from(resp: &xf_core::mvc::Response, cookie_name: &str) -> Option<String> {
    for (k, v) in &resp.headers {
        if k == "set-cookie" && v.starts_with(cookie_name) {
            let after = v.split('=').nth(1)?;
            let val = after.split(';').next()?;
            return Some(val.to_string());
        }
    }
    None
}

/// Read the persisted CSRF token for a session from the DB.
fn csrf_for(app: &App, session_id: &str) -> String {
    let data: String = app
        .db
        .with_conn(|c| {
            c.query_row(
                "SELECT session_data FROM xf_session WHERE session_id = ?",
                rusqlite::params![session_id],
                |r| r.get::<_, String>(0),
            )
        })
        .ok()
        .unwrap_or_default();
    serde_json::from_str::<serde_json::Value>(&data)
        .ok()
        .and_then(|v| v.get("csrf").and_then(|c| c.as_str()).map(String::from))
        .unwrap_or_default()
}

#[test]
fn end_to_end_forum_thread_register_reply() {
    let app = App::boot(cfg()).expect("boot");

    // Seed an admin user + welcome thread directly via the repositories.
    let admin_id = app
        .user_repo()
        .create_user("admin", "admin@example.com", "admin1234", 1)
        .expect("create admin");
    app.db
        .execute(
            "UPDATE xf_user SET is_admin = 1 WHERE user_id = ?",
            &[&admin_id as &dyn rusqlite::ToSql],
        )
        .unwrap();
    let (tid, _) = app
        .thread_repo()
        .create_thread(2, admin_id, "admin", "Welcome thread", "Hello [b]world[/b]")
        .expect("seed thread");
    app.forum_repo().rebuild_totals(2).unwrap();
    assert!(tid > 0);

    // 1. Board index — should list the "General discussion" forum.
    let mut r = get("/");
    let resp = app.handle(&mut r);
    assert_eq!(resp.status, 200);
    let body = String::from_utf8_lossy(&resp.body);
    assert!(body.contains("General discussion"), "index lists forum");
    assert!(body.contains("Test board"));

    // Capture the session cookie for subsequent requests.
    let session_cookie = app.config.session_cookie();
    let sid = session_id_from(&resp, &session_cookie).expect("session cookie set");

    // 2. Forum view — should list the welcome thread.
    let mut r = get("/forums/2/general-discussion");
    r.cookies.insert(session_cookie.clone(), sid.clone());
    let resp = app.handle(&mut r);
    assert_eq!(resp.status, 200);
    let body = String::from_utf8_lossy(&resp.body);
    assert!(body.contains("Welcome thread"), "forum view lists thread");

    // 3. Thread view — BBCode [b]world[/b] must render as <b>world</b>.
    let mut r = get(&format!("/threads/{}/welcome-thread", tid));
    r.cookies.insert(session_cookie.clone(), sid.clone());
    let resp = app.handle(&mut r);
    assert_eq!(resp.status, 200);
    let body = String::from_utf8_lossy(&resp.body);
    assert!(body.contains("<b>world</b>"), "bbcode rendered in thread view");

    // 4. Registration flow — GET the form, then POST with the CSRF token.
    let mut r = get("/register");
    r.cookies.insert(session_cookie.clone(), sid.clone());
    let resp = app.handle(&mut r);
    assert_eq!(resp.status, 200);
    let csrf = csrf_for(&app, &sid);
    assert!(!csrf.is_empty(), "csrf token generated");

    let mut r = post(
        "/register",
        vec![
            ("csrf_token", csrf.as_str()),
            ("username", "newbie"),
            ("email", "newbie@example.com"),
            ("password", "supersecret"),
        ],
    );
    r.cookies.insert(session_cookie.clone(), sid.clone());
    let resp = app.handle(&mut r);
    assert_eq!(resp.status, 302, "register redirects");
    assert!(
        app.user_repo()
            .get_user_by_name("newbie")
            .unwrap()
            .is_some(),
        "newbie persisted"
    );

    // 5. Reply flow — as admin, POST a reply to the welcome thread.
    let mut r = post(
        &format!("/threads/{}/add-reply", tid),
        vec![("csrf_token", csrf.as_str()), ("message", "A [i]reply[/i] here")],
    );
    r.cookies.insert(session_cookie.clone(), sid.clone());
    let resp = app.handle(&mut r);
    assert_eq!(resp.status, 302, "reply redirects to post anchor");
    // reply_count should now be 1.
    let thread = app.thread_repo().get_thread(tid).unwrap().unwrap();
    assert_eq!(thread.reply_count, 1, "reply count incremented");
}

#[test]
fn login_flow() {
    let app = App::boot(cfg()).expect("boot");
    app.user_repo()
        .create_user("alice", "alice@example.com", "alicepass", 3)
        .unwrap();

    // Start a session via a GET.
    let mut r = get("/");
    let resp = app.handle(&mut r);
    let session_cookie = app.config.session_cookie();
    let sid = session_id_from(&resp, &session_cookie).unwrap();

    // GET the login form (renders csrf).
    let mut r = get("/login");
    r.cookies.insert(session_cookie.clone(), sid.clone());
    app.handle(&mut r);
    let csrf = csrf_for(&app, &sid);

    // POST wrong password → stays on form with an error (200).
    let mut r = post(
        "/login",
        vec![
            ("csrf_token", csrf.as_str()),
            ("login", "alice"),
            ("password", "wrongpassword"),
        ],
    );
    r.cookies.insert(session_cookie.clone(), sid.clone());
    let resp = app.handle(&mut r);
    assert_eq!(resp.status, 200);
    assert!(String::from_utf8_lossy(&resp.body).contains("Incorrect password"));

    // POST correct password → redirect (302) and session bound to alice.
    let mut r = post(
        "/login",
        vec![
            ("csrf_token", csrf.as_str()),
            ("login", "alice"),
            ("password", "alicepass"),
        ],
    );
    r.cookies.insert(session_cookie.clone(), sid.clone());
    let resp = app.handle(&mut r);
    assert_eq!(resp.status, 302, "login redirects on success");
    let alice_id = app
        .user_repo()
        .get_user_by_name("alice")
        .unwrap()
        .unwrap()
        .user_id;
    let bound: i64 = app
        .db
        .query_scalar("SELECT user_id FROM xf_session WHERE session_id = ?", &[&sid as &dyn rusqlite::ToSql])
        .unwrap()
        .unwrap_or(0);
    assert_eq!(bound, alice_id, "session bound to alice");
}
