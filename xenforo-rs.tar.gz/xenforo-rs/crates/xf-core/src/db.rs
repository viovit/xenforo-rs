//! Thin database layer wrapping a `rusqlite::Connection`.
//!
//! XenForo 2 uses a single primary adapter (`XF\Db\AbstractAdapter`); for the
//! Rust port SQLite is the backing store, accessed through one serialized
//! connection guarded by a `Mutex` (SQLite serializes writers anyway).
use crate::error::{Error, Result};
use rusqlite::{Connection, OptionalExtension};
use std::sync::{Arc, Mutex};

/// Bundled schema migration (the contents of `migrations/0001_init.sql`).
pub const MIGRATION_0001: &str = include_str!("../../../migrations/0001_init.sql");

/// Database handle. Cheap to clone (`Arc` internally).
#[derive(Clone)]
pub struct Db {
    conn: Arc<Mutex<Connection>>,
}

impl Db {
    /// Open (or create) a SQLite database at `path` and apply migrations.
    pub fn open(path: &str) -> Result<Self> {
        let conn = if path == ":memory:" {
            Connection::open_in_memory()?
        } else {
            Connection::open(path)?
        };
        // Recommended SQLite pragmas for a forum workload.
        conn.execute_batch(
            "PRAGMA journal_mode = WAL; \
             PRAGMA foreign_keys = ON; \
             PRAGMA busy_timeout = 5000;",
        )?;
        let db = Self {
            conn: Arc::new(Mutex::new(conn)),
        };
        db.migrate()?;
        Ok(db)
    }

    /// Apply the bundled migrations.
    pub fn migrate(&self) -> Result<()> {
        let conn = self.conn.lock().unwrap();
        conn.execute_batch(MIGRATION_0001).map_err(Error::Db)?;
        tracing::info!("applied schema migration 0001_init");
        Ok(())
    }

    /// Acquire the connection lock (held for the duration of the closure).
    pub fn with_conn<F, R>(&self, f: F) -> R
    where
        F: FnOnce(&Connection) -> R,
    {
        let conn = self.conn.lock().unwrap();
        f(&conn)
    }

    /// Like [`Db::with_conn`] but for closures that return a `rusqlite::Result`;
    /// the error is mapped to [`Error::Db`]. This is what repositories use so
    /// their methods can return `crate::error::Result<_>` directly.
    pub fn with_conn_r<F, R>(&self, f: F) -> Result<R>
    where
        F: FnOnce(&Connection) -> rusqlite::Result<R>,
    {
        let conn = self.conn.lock().unwrap();
        f(&conn).map_err(Error::Db)
    }

    /// Run a statement that returns nothing.
    pub fn execute(&self, sql: &str, params: &[&dyn rusqlite::ToSql]) -> Result<usize> {
        self.with_conn(|c| c.execute(sql, params).map_err(Error::Db))
    }

    /// Look up a single column scalar.
    pub fn query_scalar<T: rusqlite::types::FromSql>(&self, sql: &str, params: &[&dyn rusqlite::ToSql]) -> Result<Option<T>> {
        self.with_conn(|c| {
            c.query_row(sql, params, |row| row.get::<_, T>(0))
                .optional()
                .map_err(Error::Db)
        })
    }

    /// Run `f` inside a SQLite transaction. The connection lock is held for
    /// the duration, all statements share the transaction, and it is committed
    /// on success (rolled back on error).
    pub fn transaction<F, R>(&self, f: F) -> Result<R>
    where
        F: FnOnce(&rusqlite::Transaction<'_>) -> Result<R>,
    {
        let mut conn = self.conn.lock().unwrap();
        let tx = conn.transaction()?;
        let r = f(&tx)?;
        tx.commit()?;
        Ok(r)
    }
}

/// Re-export common rusqlite symbols used by repositories.
pub use rusqlite::{params_from_iter, types::Value as SqlValue};
