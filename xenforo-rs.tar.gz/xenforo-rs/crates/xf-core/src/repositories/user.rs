//! `XF\Repository\UserRepository`.
use crate::entities::{User, UserAuth, UserGroup, UserOption, UserPrivacy, UserProfile};
use crate::entity::Repository;
use crate::entity::Entity;
use crate::auth::Scheme;
use crate::error::{Error, Result};
use crate::{str, time, Db};
use rusqlite::params;

pub struct UserRepository {
    db: Db,
}

impl Repository for UserRepository {
    const SHORT_NAME: &'static str = "XF:User";
    fn from_db(db: Db) -> Self {
        Self { db }
    }
    fn db(&self) -> &Db {
        &self.db
    }
}

impl UserRepository {
    /// Find a user by id.
    pub fn get_user(&self, id: i64) -> Result<Option<User>> {
        self.db.with_conn_r(|c| {
            c.query_row(
                "SELECT * FROM xf_user WHERE user_id = ?",
                params![id],
                User::from_row,
            )
            .optional()
        })
    }

    /// Find a user by username or email (login lookup).
    pub fn get_user_by_login(&self, login: &str) -> Result<Option<User>> {
        self.db.with_conn_r(|c| {
            c.query_row(
                "SELECT * FROM xf_user WHERE username = ? OR email = ? COLLATE NOCASE LIMIT 1",
                params![login, login],
                User::from_row,
            )
            .optional()
        })
    }

    /// Find a user by username.
    pub fn get_user_by_name(&self, username: &str) -> Result<Option<User>> {
        self.db.with_conn_r(|c| {
            c.query_row(
                "SELECT * FROM xf_user WHERE username = ? COLLATE NOCASE LIMIT 1",
                params![username],
                User::from_row,
            )
            .optional()
        })
    }

    /// Get a user's auth record.
    pub fn get_auth(&self, user_id: i64) -> Result<Option<UserAuth>> {
        self.db.with_conn_r(|c| {
            c.query_row(
                "SELECT * FROM xf_user_auth WHERE user_id = ?",
                params![user_id],
                UserAuth::from_row,
            )
            .optional()
        })
    }

    pub fn get_profile(&self, user_id: i64) -> Result<Option<UserProfile>> {
        self.db.with_conn_r(|c| {
            c.query_row(
                "SELECT * FROM xf_user_profile WHERE user_id = ?",
                params![user_id],
                UserProfile::from_row,
            )
            .optional()
        })
    }

    pub fn get_option(&self, user_id: i64) -> Result<Option<UserOption>> {
        self.db.with_conn_r(|c| {
            c.query_row(
                "SELECT * FROM xf_user_option WHERE user_id = ?",
                params![user_id],
                UserOption::from_row,
            )
            .optional()
        })
    }

    pub fn get_privacy(&self, user_id: i64) -> Result<Option<UserPrivacy>> {
        self.db.with_conn_r(|c| {
            c.query_row(
                "SELECT * FROM xf_user_privacy WHERE user_id = ?",
                params![user_id],
                UserPrivacy::from_row,
            )
            .optional()
        })
    }

    pub fn get_group(&self, group_id: i64) -> Result<Option<UserGroup>> {
        self.db.with_conn_r(|c| {
            c.query_row(
                "SELECT * FROM xf_user_group WHERE user_group_id = ?",
                params![group_id],
                UserGroup::from_row,
            )
            .optional()
        })
    }

    /// Validate that `username` is acceptable (length, characters, uniqueness).
    pub fn validate_username(&self, username: &str, min: u32, max: u32) -> Result<()> {
        let len = username.chars().count() as u32;
        if len < min {
            return Err(Error::Validation(format!(
                "Username must be at least {min} characters."
            )));
        }
        if len > max {
            return Err(Error::Validation(format!(
                "Username must be at most {max} characters."
            )));
        }
        if !username
            .chars()
            .all(|c| c.is_alphanumeric() || c == '_' || c == '-' || c == ' ')
        {
            return Err(Error::Validation(
                "Username may only contain letters, numbers, spaces, _ and -.".into(),
            ));
        }
        if self.get_user_by_name(username)?.is_some() {
            return Err(Error::Validation("That username is already taken.".into()));
        }
        Ok(())
    }

    /// Validate an email (basic shape + uniqueness).
    pub fn validate_email(&self, email: &str) -> Result<()> {
        if !email.contains('@') || !email.contains('.') {
            return Err(Error::Validation("Please enter a valid email address.".into()));
        }
        let taken: Option<i64> = self.db.with_conn_r(|c| {
            c.query_row(
                "SELECT user_id FROM xf_user WHERE email = ? COLLATE NOCASE LIMIT 1",
                params![email],
                |r| r.get(0),
            )
            .optional()
        })?;
        if taken.is_some() {
            return Err(Error::Validation("That email is already in use.".into()));
        }
        Ok(())
    }

    /// Insert a brand-new user with all related rows, mirroring
    /// `XF\Service\User\Create`'s side effects. Returns the new user id.
    pub fn create_user(&self, username: &str, email: &str, password: &str, group_id: i64) -> Result<i64> {
        self.validate_username(username, 3, 50)?;
        self.validate_email(email)?;
        if password.len() < 8 {
            return Err(Error::Validation("Password must be at least 8 characters.".into()));
        }

        let now = time::now();
        let secret = str::random_hex(32);
        let scheme = crate::auth::Core12;
        let auth_data = scheme.generate(password)?;

        let user_id = self.db.transaction(|tx| {
            tx.execute(
                "INSERT INTO xf_user \
                 (username, email, user_group_id, secondary_group_ids, permission_combination_id, \
                  message_count, register_date, last_activity, user_state, timezone, secret_key) \
                 VALUES (?, ?, ?, '', ?, 0, ?, ?, 'valid', 'Europe/London', ?)",
                params![username, email, group_id, group_id, now, now, secret],
            )?;
            let user_id = tx.last_insert_rowid();
            tx.execute(
                "INSERT INTO xf_user_auth (user_id, scheme_class, data) VALUES (?, 'XF:Core12', ?)",
                params![user_id, auth_data],
            )?;
            tx.execute(
                "INSERT INTO xf_user_option (user_id) VALUES (?)",
                params![user_id],
            )?;
            tx.execute(
                "INSERT INTO xf_user_privacy (user_id) VALUES (?)",
                params![user_id],
            )?;
            tx.execute(
                "INSERT INTO xf_user_profile (user_id) VALUES (?)",
                params![user_id],
            )?;
            Ok(user_id)
        })?;
        Ok(user_id)
    }

    /// Update `last_activity` for `user_id` (mirrors `XF::visitor()->last_activity`).
    pub fn touch_activity(&self, user_id: i64) -> Result<()> {
        if user_id == 0 {
            return Ok(());
        }
        let now = time::now();
        self.db.execute(
            "UPDATE xf_user SET last_activity = ? WHERE user_id = ?",
            &[&now as &dyn rusqlite::ToSql, &user_id],
        )?;
        Ok(())
    }

    /// Page through members (newest first).
    pub fn list_members(&self, page: i64, per_page: i64) -> Result<Vec<User>> {
        let offset = (page.max(1) - 1) * per_page;
        self.db.with_conn_r(|c| {
            let mut stmt = c.prepare(
                "SELECT * FROM xf_user WHERE user_state = 'valid' ORDER BY register_date DESC LIMIT ? OFFSET ?",
            )?;
            let rows = stmt
                .query_map(params![per_page, offset], User::from_row)?
                .collect::<rusqlite::Result<Vec<_>>>()?;
            Ok(rows)
        })
    }

    /// Count visible members.
    pub fn count_members(&self) -> Result<i64> {
        Ok(self.db.query_scalar::<i64>(
            "SELECT COUNT(*) FROM xf_user WHERE user_state = 'valid'",
            &[],
        )?
        .unwrap_or(0))
    }
}

use rusqlite::OptionalExtension;
