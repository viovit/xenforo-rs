//! `XF\Repository\NodeRepository` — the forum/category tree.
use crate::entities::{Category, Forum, Node};
use crate::entity::Repository;
use crate::entity::Entity;
use crate::error::Result;
use crate::Db;
use rusqlite::params;

pub struct NodeRepository {
    db: Db,
}

impl Repository for NodeRepository {
    const SHORT_NAME: &'static str = "XF:Node";
    fn from_db(db: Db) -> Self {
        Self { db }
    }
    fn db(&self) -> &Db {
        &self.db
    }
}

/// A node joined with its forum data (for listing).
#[derive(Debug, Clone, serde::Serialize)]
pub struct NodeForum {
    pub node_id: i64,
    pub title: String,
    pub node_name: Option<String>,
    pub description: String,
    pub node_type_id: String,
    pub parent_node_id: i64,
    pub display_order: i64,
    pub depth: i64,
    pub slug: String,
    // forum-only fields:
    pub discussion_count: i64,
    pub message_count: i64,
    pub last_thread_id: i64,
    pub last_thread_title: String,
    pub last_post_id: i64,
    pub last_post_username: String,
    pub last_post_date: i64,
}

impl NodeRepository {
    pub fn get_node(&self, id: i64) -> Result<Option<Node>> {
        self.db.with_conn_r(|c| {
            c.query_row(
                "SELECT * FROM xf_node WHERE node_id = ?",
                params![id],
                Node::from_row,
            )
            .optional()
        })
    }

    pub fn get_node_by_name(&self, name: &str) -> Result<Option<Node>> {
        self.db.with_conn_r(|c| {
            c.query_row(
                "SELECT * FROM xf_node WHERE node_name = ?",
                params![name],
                Node::from_row,
            )
            .optional()
        })
    }

    /// Load every node ordered for nested-set display.
    pub fn list_nodes(&self) -> Result<Vec<Node>> {
        self.db.with_conn_r(|c| {
            let mut stmt = c.prepare("SELECT * FROM xf_node ORDER BY lft ASC")?;
            let rows = stmt
                .query_map([], Node::from_row)?
                .collect::<rusqlite::Result<Vec<_>>>()?;
            Ok(rows)
        })
    }

    /// Load the forum row for a node.
    pub fn get_forum(&self, node_id: i64) -> Result<Option<Forum>> {
        self.db.with_conn_r(|c| {
            c.query_row(
                "SELECT * FROM xf_forum WHERE node_id = ?",
                params![node_id],
                Forum::from_row,
            )
            .optional()
        })
    }

    pub fn get_category(&self, node_id: i64) -> Result<Option<Category>> {
        self.db.with_conn_r(|c| {
            c.query_row(
                "SELECT * FROM xf_category WHERE node_id = ?",
                params![node_id],
                Category::from_row,
            )
            .optional()
        })
    }

    /// Full node+forum join, ordered by lft, for the forum list page.
    pub fn list_node_forums(&self) -> Result<Vec<NodeForum>> {
        self.db.with_conn_r(|c| {
            let mut stmt = c.prepare(
                "SELECT n.node_id, n.title, n.node_name, n.description, n.node_type_id, \
                        n.parent_node_id, n.display_order, n.depth, \
                        COALESCE(f.discussion_count, 0) AS discussion_count, \
                        COALESCE(f.message_count, 0)    AS message_count, \
                        COALESCE(f.last_thread_id, 0)   AS last_thread_id, \
                        COALESCE(f.last_thread_title,'') AS last_thread_title, \
                        COALESCE(f.last_post_id, 0)     AS last_post_id, \
                        COALESCE(f.last_post_username,'') AS last_post_username, \
                        COALESCE(f.last_post_date, 0)   AS last_post_date \
                 FROM xf_node n \
                 LEFT JOIN xf_forum f ON f.node_id = n.node_id \
                 ORDER BY n.lft ASC",
            )?;
            let rows = stmt.query_map([], |r| {
                let title: String = r.get("title")?;
                Ok(NodeForum {
                    node_id: r.get("node_id")?,
                    slug: crate::str::slug(&title),
                    title,
                    node_name: r.get("node_name")?,
                    description: r.get("description")?,
                    node_type_id: r.get("node_type_id")?,
                    parent_node_id: r.get("parent_node_id")?,
                    display_order: r.get("display_order")?,
                    depth: r.get("depth")?,
                    discussion_count: r.get("discussion_count")?,
                    message_count: r.get("message_count")?,
                    last_thread_id: r.get("last_thread_id")?,
                    last_thread_title: r.get("last_thread_title")?,
                    last_post_id: r.get("last_post_id")?,
                    last_post_username: r.get("last_post_username")?,
                    last_post_date: r.get("last_post_date")?,
                })
            })?;
            let mut out = Vec::new();
            for row in rows {
                out.push(row?);
            }
            Ok(out)
        })
    }

    /// Build breadcrumb nodes from the root down to `node` (inclusive).
    pub fn breadcrumbs(&self, node: &Node) -> Result<Vec<Node>> {
        if node.parent_node_id == 0 {
            return Ok(vec![node.clone()]);
        }
        self.db.with_conn_r(|c| {
            let mut stmt = c.prepare(
                "SELECT * FROM xf_node WHERE lft <= ? AND rgt >= ? ORDER BY lft ASC",
            )?;
            let rows = stmt
                .query_map(params![node.lft, node.rgt], Node::from_row)?
                .collect::<rusqlite::Result<Vec<_>>>()?;
            Ok(rows)
        })
    }
}

use rusqlite::OptionalExtension;
