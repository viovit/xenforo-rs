//! `XF\Repository\ThreadRepository`.
use crate::entities::{Node, Post, Thread};
use crate::entity::Repository;
use crate::entity::Entity;
use crate::error::Result;
use crate::time;
use crate::Db;
use rusqlite::params;

pub struct ThreadRepository {
    db: Db,
}

impl Repository for ThreadRepository {
    const SHORT_NAME: &'static str = "XF:Thread";
    fn from_db(db: Db) -> Self {
        Self { db }
    }
    fn db(&self) -> &Db {
        &self.db
    }
}

impl ThreadRepository {
    pub fn get_thread(&self, id: i64) -> Result<Option<Thread>> {
        self.db.with_conn_r(|c| {
            c.query_row(
                "SELECT * FROM xf_thread WHERE thread_id = ?",
                params![id],
                Thread::from_row,
            )
            .optional()
        })
    }

    /// Fetch the thread + its forum node (for permission checks / breadcrumb).
    pub fn get_thread_with_forum(&self, id: i64) -> Result<Option<(Thread, Node)>> {
        let Some(thread) = self.get_thread(id)? else {
            return Ok(None);
        };
        let node = self.db.with_conn_r(|c| {
            c.query_row(
                "SELECT * FROM xf_node WHERE node_id = ?",
                params![thread.node_id],
                Node::from_row,
            )
            .optional()
        })?;
        Ok(node.map(|n| (thread, n)))
    }

    /// Page through visible threads in a forum, sticky first.
    pub fn list_in_forum(&self, node_id: i64, page: i64, per_page: i64) -> Result<Vec<Thread>> {
        let offset = (page.max(1) - 1) * per_page;
        self.db.with_conn_r(|c| {
            let mut stmt = c.prepare(
                "SELECT * FROM xf_thread \
                 WHERE node_id = ? AND discussion_state = 'visible' \
                 ORDER BY sticky DESC, last_post_date DESC LIMIT ? OFFSET ?",
            )?;
            let rows = stmt
                .query_map(params![node_id, per_page, offset], Thread::from_row)?
                .collect::<rusqlite::Result<Vec<_>>>()?;
            Ok(rows)
        })
    }

    pub fn count_in_forum(&self, node_id: i64) -> Result<i64> {
        Ok(self.db.query_scalar::<i64>(
            "SELECT COUNT(*) FROM xf_thread WHERE node_id = ? AND discussion_state = 'visible'",
            &[&node_id as &dyn rusqlite::ToSql],
        )?
        .unwrap_or(0))
    }

    /// Create a thread + its first post in one transaction, mirroring
    /// `XF\Service\Thread\Create`. Returns `(thread_id, post_id)`.
    pub fn create_thread(
        &self,
        node_id: i64,
        user_id: i64,
        username: &str,
        title: &str,
        message: &str,
    ) -> Result<(i64, i64)> {
        let now = time::now();
        self.db.transaction(|tx| {
            // Insert the thread with first_post_id = 0, then the first post,
            // then back-fill first_post_id / last_post_*.
            tx.execute(
                "INSERT INTO xf_thread \
                 (node_id, title, user_id, username, post_date, discussion_state, discussion_open, \
                  first_post_id, last_post_date, last_post_id, last_post_user_id, last_post_username) \
                 VALUES (?, ?, ?, ?, ?, 'visible', 1, 0, ?, 0, ?, ?)",
                params![node_id, title, user_id, username, now, now, user_id, username],
            )?;
            let thread_id = tx.last_insert_rowid();
            tx.execute(
                "INSERT INTO xf_post \
                 (thread_id, user_id, username, post_date, message, message_state, position) \
                 VALUES (?, ?, ?, ?, ?, 'visible', 0)",
                params![thread_id, user_id, username, now, message],
            )?;
            let post_id = tx.last_insert_rowid();
            tx.execute(
                "UPDATE xf_thread SET first_post_id = ?, last_post_id = ? WHERE thread_id = ?",
                params![post_id, post_id, thread_id],
            )?;
            // Bump the user's message_count.
            tx.execute(
                "UPDATE xf_user SET message_count = message_count + 1 WHERE user_id = ?",
                params![user_id],
            )?;
            Ok((thread_id, post_id))
        })
    }

    /// Append a reply to `thread_id`, mirroring `XF\Service\Post\Replier`.
    pub fn add_reply(
        &self,
        thread_id: i64,
        user_id: i64,
        username: &str,
        message: &str,
    ) -> Result<i64> {
        let now = time::now();
        self.db.transaction(|tx| {
            // position = current reply_count + 1
            let position: i64 = tx.query_row(
                "SELECT reply_count FROM xf_thread WHERE thread_id = ?",
                params![thread_id],
                |r| r.get(0),
            )?;
            let position = position + 1;
            tx.execute(
                "INSERT INTO xf_post \
                 (thread_id, user_id, username, post_date, message, message_state, position) \
                 VALUES (?, ?, ?, ?, ?, 'visible', ?)",
                params![thread_id, user_id, username, now, message, position],
            )?;
            let post_id = tx.last_insert_rowid();
            tx.execute(
                "UPDATE xf_thread SET reply_count = reply_count + 1, \
                 last_post_id = ?, last_post_date = ?, last_post_user_id = ?, last_post_username = ? \
                 WHERE thread_id = ?",
                params![post_id, now, user_id, username, thread_id],
            )?;
            tx.execute(
                "UPDATE xf_forum SET message_count = message_count + 1, \
                 last_post_id = ?, last_post_date = ?, last_post_user_id = ?, last_post_username = ?, \
                 last_thread_id = ? WHERE node_id = (SELECT node_id FROM xf_thread WHERE thread_id = ?)",
                params![post_id, now, user_id, username, thread_id, thread_id],
            )?;
            tx.execute(
                "UPDATE xf_user SET message_count = message_count + 1 WHERE user_id = ?",
                params![user_id],
            )?;
            Ok(post_id)
        })
    }

    /// Increment view count (mirrors `ThreadRepository::incrementViewCounter`).
    pub fn increment_views(&self, thread_id: i64) -> Result<()> {
        self.db.execute(
            "UPDATE xf_thread SET view_count = view_count + 1 WHERE thread_id = ?",
            &[&thread_id as &dyn rusqlite::ToSql],
        )?;
        Ok(())
    }

    /// Soft-delete a thread (discussion_state = 'deleted').
    pub fn soft_delete(&self, thread_id: i64, _by_user_id: i64) -> Result<()> {
        self.db.execute(
            "UPDATE xf_thread SET discussion_state = 'deleted' WHERE thread_id = ?",
            &[&thread_id as &dyn rusqlite::ToSql],
        )?;
        Ok(())
    }

    /// List posts in a thread, paged, ordered by position.
    pub fn list_posts(&self, thread_id: i64, page: i64, per_page: i64) -> Result<Vec<Post>> {
        let offset = (page.max(1) - 1) * per_page;
        self.db.with_conn_r(|c| {
            let mut stmt = c.prepare(
                "SELECT * FROM xf_post \
                 WHERE thread_id = ? AND message_state = 'visible' \
                 ORDER BY position ASC LIMIT ? OFFSET ?",
            )?;
            let rows = stmt
                .query_map(params![thread_id, per_page, offset], Post::from_row)?
                .collect::<rusqlite::Result<Vec<_>>>()?;
            Ok(rows)
        })
    }

    /// Full-text-ish search across thread titles + post messages.
    pub fn search(&self, query: &str, limit: i64) -> Result<Vec<SearchHit>> {
        let like = format!("%{}%", query.replace('%', "\\%"));
        self.db.with_conn_r(|c| {
            let mut stmt = c.prepare(
                "SELECT t.thread_id, t.title, t.user_id, t.username, t.post_date, \
                        p.post_id, p.message \
                 FROM xf_thread t \
                 JOIN xf_post p ON p.post_id = t.first_post_id \
                 WHERE t.discussion_state = 'visible' \
                   AND (t.title LIKE ? ESCAPE '\\' OR p.message LIKE ? ESCAPE '\\') \
                 ORDER BY t.post_date DESC LIMIT ?",
            )?;
            let rows = stmt.query_map(params![&like, &like, limit], |r| {
                let message: String = r.get("message")?;
                Ok(SearchHit {
                    thread_id: r.get("thread_id")?,
                    post_id: r.get("post_id")?,
                    title: r.get("title")?,
                    user_id: r.get("user_id")?,
                    username: r.get("username")?,
                    post_date: r.get("post_date")?,
                    snippet: crate::str::snippet(&crate::str::strip_bbcode(&message), 200),
                })
            })?;
            let mut out = Vec::new();
            for row in rows {
                out.push(row?);
            }
            Ok(out)
        })
    }
}

#[derive(Debug, Clone, serde::Serialize)]
pub struct SearchHit {
    pub thread_id: i64,
    pub post_id: i64,
    pub title: String,
    pub user_id: i64,
    pub username: String,
    pub post_date: i64,
    pub snippet: String,
}

use rusqlite::OptionalExtension;
