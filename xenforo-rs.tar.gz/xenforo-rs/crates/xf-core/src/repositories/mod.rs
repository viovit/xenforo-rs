//! Data-access repositories — Rust translations of `src/XF/Repository/*`.
pub mod forum;
pub mod node;
pub mod post;
pub mod thread;
pub mod user;

pub use forum::ForumRepository;
pub use node::NodeRepository;
pub use post::PostRepository;
pub use thread::ThreadRepository;
pub use user::UserRepository;
