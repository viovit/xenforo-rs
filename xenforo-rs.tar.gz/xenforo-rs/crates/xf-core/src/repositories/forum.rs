//! `XF\Repository\ForumRepository`.
use crate::entities::{Forum, Node};
use crate::entity::Repository;
use crate::entity::Entity;
use crate::error::Result;
use crate::Db;

pub struct ForumRepository {
    db: Db,
}

impl Repository for ForumRepository {
    const SHORT_NAME: &'static str = "XF:Forum";
    fn from_db(db: Db) -> Self {
        Self { db }
    }
    fn db(&self) -> &Db {
        &self.db
    }
}

impl ForumRepository {
    pub fn get_forum(&self, node_id: i64) -> Result<Option<Forum>> {
        self.db.with_conn_r(|c| {
            c.query_row(
                "SELECT * FROM xf_forum WHERE node_id = ?",
                rusqlite::params![node_id],
                Forum::from_row,
            )
            .optional()
        })
    }

    /// Fetch the node + forum pair for a forum view.
    pub fn get_viewable_forum(&self, node_id: i64) -> Result<Option<(Node, Forum)>> {
        let Some(node) = self.db.with_conn_r(|c| {
            c.query_row(
                "SELECT * FROM xf_node WHERE node_id = ?",
                rusqlite::params![node_id],
                Node::from_row,
            )
            .optional()
        })?
        else {
            return Ok(None);
        };
        if !node.is_forum() {
            return Ok(None);
        }
        let forum = self.get_forum(node_id)?;
        Ok(forum.map(|f| (node, f)))
    }

    /// Recompute `discussion_count`, `message_count` and last-post fields.
    /// Mirrors `ForumRepository::rebuildForumTotals`.
    pub fn rebuild_totals(&self, node_id: i64) -> Result<()> {
        self.db.transaction(|tx| {
            let last: Option<(i64, i64, i64, String, i64)> = tx.query_row(
                "SELECT t.thread_id, t.last_post_id, t.last_post_user_id, t.last_post_username, t.last_post_date \
                 FROM xf_thread t \
                 WHERE t.node_id = ? AND t.discussion_state = 'visible' \
                 ORDER BY t.last_post_date DESC LIMIT 1",
                rusqlite::params![node_id],
                |r| {
                    Ok((
                        r.get::<_, i64>(0)?,
                        r.get::<_, i64>(1)?,
                        r.get::<_, i64>(2)?,
                        r.get::<_, String>(3)?,
                        r.get::<_, i64>(4)?,
                    ))
                },
            )
            .optional()?;
            let (disc, msg) = tx.query_row(
                "SELECT COUNT(*), COALESCE(SUM(reply_count+1), 0) \
                 FROM xf_thread WHERE node_id = ? AND discussion_state = 'visible'",
                rusqlite::params![node_id],
                |r| Ok((r.get::<_, i64>(0)?, r.get::<_, i64>(1)?)),
            )?;
            if let Some((tid, pid, uid, uname, date)) = last {
                tx.execute(
                    "UPDATE xf_forum SET discussion_count=?, message_count=?, \
                     last_thread_id=?, last_post_id=?, last_post_user_id=?, \
                     last_post_username=?, last_post_date=? WHERE node_id=?",
                    rusqlite::params![disc, msg, tid, pid, uid, uname, date, node_id],
                )?;
                if tid != 0 {
                    // title update
                    let title: Option<String> = tx
                        .query_row(
                            "SELECT title FROM xf_thread WHERE thread_id = ?",
                            rusqlite::params![tid],
                            |r| r.get::<_, String>(0),
                        )
                        .optional()?;
                    if let Some(t) = title {
                        tx.execute(
                            "UPDATE xf_forum SET last_thread_title=? WHERE node_id=?",
                            rusqlite::params![t, node_id],
                        )?;
                    }
                }
            } else {
                tx.execute(
                    "UPDATE xf_forum SET discussion_count=?, message_count=0, \
                     last_thread_id=0, last_post_id=0, last_post_user_id=0, \
                     last_post_username='', last_post_date=0, last_thread_title='' WHERE node_id=?",
                    rusqlite::params![disc, node_id],
                )?;
            }
            Ok(())
        })
    }

    /// Mark a forum read for `user_id` (sets `forum_read_date` to now).
    pub fn mark_read(&self, node_id: i64, user_id: i64) -> Result<()> {
        if user_id == 0 {
            return Ok(());
        }
        let now = crate::time::now();
        self.db.execute(
            "INSERT INTO xf_forum_read (node_id, user_id, forum_read_date) VALUES (?, ?, ?) \
             ON CONFLICT(node_id, user_id) DO UPDATE SET forum_read_date = excluded.forum_read_date",
            &[&node_id as &dyn rusqlite::ToSql, &user_id, &now],
        )?;
        Ok(())
    }
}

use rusqlite::OptionalExtension;
