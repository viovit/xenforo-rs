//! `XF\Repository\PostRepository`.
use crate::entities::Post;
use crate::entity::Repository;
use crate::entity::Entity;
use crate::error::Result;
use crate::time;
use crate::Db;
use rusqlite::params;

pub struct PostRepository {
    db: Db,
}

impl Repository for PostRepository {
    const SHORT_NAME: &'static str = "XF:Post";
    fn from_db(db: Db) -> Self {
        Self { db }
    }
    fn db(&self) -> &Db {
        &self.db
    }
}

impl PostRepository {
    pub fn get_post(&self, id: i64) -> Result<Option<Post>> {
        self.db.with_conn_r(|c| {
            c.query_row(
                "SELECT * FROM xf_post WHERE post_id = ?",
                params![id],
                Post::from_row,
            )
            .optional()
        })
    }

    /// Edit a post's message (mirrors `XF\Service\Post\Editor`).
    /// Bumps `edit_count` and `last_edit_date`.
    pub fn edit(&self, post_id: i64, editor_id: i64, message: &str) -> Result<()> {
        let now = time::now();
        self.db.execute(
            "UPDATE xf_post SET message = ?, last_edit_date = ?, last_edit_user_id = ?, \
             edit_count = edit_count + 1 WHERE post_id = ?",
            &[
                &message as &dyn rusqlite::ToSql,
                &now,
                &editor_id,
                &post_id,
            ],
        )?;
        Ok(())
    }

    /// Soft-delete a post.
    pub fn soft_delete(&self, post_id: i64) -> Result<()> {
        self.db.execute(
            "UPDATE xf_post SET message_state = 'deleted' WHERE post_id = ?",
            &[&post_id as &dyn rusqlite::ToSql],
        )?;
        Ok(())
    }

    /// Recount `reply_count` / positions for a thread after a deletion
    /// (mirrors `ThreadRepository::rebuildThreadPostCounters`).
    pub fn rebuild_thread_counters(&self, thread_id: i64) -> Result<()> {
        self.db.transaction(|tx| {
            // Reposition visible posts.
            tx.execute(
                "UPDATE xf_post SET position = ( \
                    SELECT COUNT(*) FROM xf_post p2 \
                    WHERE p2.thread_id = xf_post.thread_id \
                      AND p2.message_state = 'visible' \
                      AND p2.post_id <= xf_post.post_id \
                 ) - 1 \
                 WHERE thread_id = ? AND message_state = 'visible'",
                params![thread_id],
            )?;
            let reply_count: i64 = tx.query_row(
                "SELECT COUNT(*) - 1 FROM xf_post WHERE thread_id = ? AND message_state = 'visible'",
                params![thread_id],
                |r| r.get(0),
            )?;
            tx.execute(
                "UPDATE xf_thread SET reply_count = ? WHERE thread_id = ?",
                params![reply_count, thread_id],
            )?;
            Ok(())
        })
    }
}

use rusqlite::OptionalExtension;
