//! xf-core — Rust port of the XenForo 2.3 forum engine core.
//!
//! Module layout mirrors `src/XF/`:
//! * [`app`]        — `App` container (config, db, templater, bbcode, router).
//! * [`mvc`]        — `Router` / `Dispatcher` / `Controller` / `Reply` / `Renderer`.
//! * [`entity`]     — ORM primitives: `Structure`, `Manager`, `Finder`, `Repository`.
//! * [`entities`]   — concrete entities (`User`, `Forum`, `Thread`, `Post`, …).
//! * [`repositories`] — `UserRepository`, `ForumRepository`, `ThreadRepository`, …
//! * [`bbcode`]     — BBCode parser, `RuleSet` (30+ tags) and `Html` renderer.
//! * [`auth`]       — password authentication (bcrypt, `XF:Core12` equivalent).
//! * [`session`]    — session store and visitor resolution.
//! * [`permission`] — permission combination resolution and content permissions.
//! * [`template`]   — minijinja-backed template engine (PAGE_CONTAINER, macros).
//! * [`str`]        — string utilities (romanize, snippet, censor, slug).
//! * [`pub`]        — public controllers and the route table.
#![allow(clippy::module_inception)]
#![allow(clippy::too_many_arguments)]

pub mod app;
pub mod auth;
pub mod bbcode;
pub mod config;
pub mod db;
pub mod entities;
pub mod entity;
pub mod mvc;
pub mod permission;
pub mod pubc;
pub mod repositories;
pub mod session;
pub mod str;
pub mod template;
pub mod time;

pub use app::App;
pub use config::Config;
pub use db::Db;
pub use mvc::{Controller, Dispatcher, ParamBag, Reply, Request, RouteMatch, Router};

/// Re-export of the common error / result types.
pub use error::{Error, Result};

mod error {
    use thiserror::Error;

    /// Top-level error type used across xf-core.
    #[derive(Debug, Error)]
    pub enum Error {
        #[error("database error: {0}")]
        Db(#[from] rusqlite::Error),
        #[error("not found: {0}")]
        NotFound(String),
        #[error("permission denied: {0}")]
    NoPermission(String),
        #[error("validation: {0}")]
        Validation(String),
        #[error("auth: {0}")]
        Auth(String),
        #[error("template: {0}")]
        Template(String),
        #[error("bbcode: {0}")]
        BbCode(String),
        #[error("io: {0}")]
        Io(#[from] std::io::Error),
        #[error("{0}")]
        Other(String),
    }

    pub type Result<T> = std::result::Result<T, Error>;

    impl From<serde_json::Error> for Error {
        fn from(e: serde_json::Error) -> Self {
            Error::Other(format!("json: {e}"))
        }
    }
    impl From<&str> for Error {
        fn from(e: &str) -> Self {
            Error::Other(e.to_string())
        }
    }
    impl From<String> for Error {
        fn from(e: String) -> Self {
            Error::Other(e)
        }
    }
}
