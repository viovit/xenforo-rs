//! Password authentication — a translation of `XF\Authentication`.
//!
//! The default scheme is [`Core12`], the Rust equivalent of
//! `XF\Authentication\Core12` (PHP `password_hash` / `password_verify` with
//! bcrypt, cost 10). The produced hashes are `$2b$…` (bcrypt crate), which
//! verify correctly against PHP's `$2y$…` hashes and vice-versa.
use crate::error::{Error, Result};
use serde::{Deserialize, Serialize};

pub mod core12;

pub use core12::Core12;

/// A password-authentication scheme, mirroring `XF\Authentication\AbstractAuth`.
pub trait Scheme: Send + Sync {
    /// Short class name, e.g. `"XF:Core12"`.
    fn scheme_class(&self) -> &'static str;

    /// Build the JSON `data` blob stored in `xf_user_auth.data` for `password`.
    fn generate(&self, password: &str) -> Result<String>;

    /// Verify `password` against the stored `data` blob.
    fn authenticate(&self, data: &str, password: &str) -> Result<bool>;
}

/// The stored JSON shape: `{"hash":"$2b$…"}`.
#[derive(Debug, Clone, Serialize, Deserialize)]
struct CoreData {
    #[serde(default)]
    hash: String,
    #[serde(default, rename = "algo")]
    algo: Option<String>,
}

/// Resolve a scheme by its class name.
pub fn scheme_for(scheme_class: &str) -> Box<dyn Scheme> {
    match scheme_class {
        "XF:Core12" | "core12" | "" => Box::new(Core12),
        other => {
            tracing::warn!(scheme = other, "unknown auth scheme, falling back to Core12");
            Box::new(Core12)
        }
    }
}

/// Verify a password against a stored `data` blob, auto-detecting the scheme
/// from `scheme_class` (defaults to Core12 / bcrypt).
pub fn verify(scheme_class: &str, data: &str, password: &str) -> Result<bool> {
    Ok(scheme_for(scheme_class).authenticate(data, password)?)
}

/// Convenience error when authentication fails.
pub fn auth_error(msg: impl Into<String>) -> Error {
    Error::Auth(msg.into())
}
