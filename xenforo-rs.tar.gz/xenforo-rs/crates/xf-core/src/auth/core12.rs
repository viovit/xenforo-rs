//! `XF\Authentication\Core12` — bcrypt (`password_hash` / `password_verify`).
use super::{Scheme, CoreData};
use crate::error::{Error, Result};
use bcrypt::{hash as bcrypt_hash, verify as bcrypt_verify, BcryptError};

/// Cost 10 matches XenForo's default `password_hash` cost.
const COST: u32 = 10;

pub struct Core12;

impl Scheme for Core12 {
    fn scheme_class(&self) -> &'static str {
        "XF:Core12"
    }

    fn generate(&self, password: &str) -> Result<String> {
        // bcrypt truncates at 72 bytes, exactly like PHP's `password_hash`.
        if password.is_empty() {
            return Err(Error::Auth("password must not be empty".into()));
        }
        let h = bcrypt_hash(password, COST).map_err(map_bcrypt_err)?;
        let data = CoreData {
            hash: h,
            algo: Some("2y".into()),
        };
        Ok(serde_json::to_string(&data)?)
    }

    fn authenticate(&self, data: &str, password: &str) -> Result<bool> {
        let parsed: CoreData = serde_json::from_str(data)
            .map_err(|e| Error::Auth(format!("invalid auth data: {e}")))?;
        if parsed.hash.is_empty() {
            return Ok(false);
        }
        // Normalise the PHP `$2y$` prefix to `$2b$` for the bcrypt crate if needed.
        let stored = normalize_hash(&parsed.hash);
        match bcrypt_verify(password, &stored) {
            Ok(ok) => Ok(ok),
            // Any hash-format / verification error means "not authenticated";
            // we never want a malformed hash to crash the request.
            Err(e) => {
                tracing::debug!(error = %e, "bcrypt verify failed");
                Ok(false)
            }
        }
    }
}

fn map_bcrypt_err(e: BcryptError) -> Error {
    Error::Auth(format!("bcrypt: {e}"))
}

/// The bcrypt crate expects `$2a$` or `$2b$`. PHP emits `$2y$`; the algorithm
/// is identical, so swap the prefix before verification.
fn normalize_hash(h: &str) -> String {
    if let Some(rest) = h.strip_prefix("$2y$") {
        format!("$2b${rest}")
    } else if let Some(rest) = h.strip_prefix("$2a$") {
        format!("$2b${rest}")
    } else {
        h.to_string()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn roundtrip() {
        let s = Core12;
        let data = s.generate("hunter2password").unwrap();
        assert!(s.authenticate(&data, "hunter2password").unwrap());
        assert!(!s.authenticate(&data, "wrong").unwrap());
    }

    #[test]
    fn verifies_php_style_2y_hash() {
        // Produce a hash with the bcrypt crate ($2b$), then rewrite the prefix to
        // PHP's $2y$ to confirm prefix normalisation works for imported hashes.
        let s = Core12;
        let data = s.generate("my-secret-password").unwrap();
        let parsed: super::CoreData = serde_json::from_str(&data).unwrap();
        let php_style = format!("$2y${}", parsed.hash.strip_prefix("$2b$").unwrap());
        let php_data = serde_json::to_string(&super::CoreData {
            hash: php_style,
            algo: Some("2y".into()),
        })
        .unwrap();
        assert!(s.authenticate(&php_data, "my-secret-password").unwrap());
        assert!(!s.authenticate(&php_data, "nope").unwrap());
    }
}
