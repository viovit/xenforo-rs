//! Session handling — a translation of `XF\Session\Session`.
//!
//! Sessions are cookie-based: the front controller reads the `xf_session`
//! cookie, loads (or creates) a row in `xf_session`, and the request's
//! *visitor* user is derived from `session.user_id`.
use crate::error::Result;
use crate::{str, Config, Db};
use rusqlite::params;
use serde::{Deserialize, Serialize};

/// A session row (`xf_session`).
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct Session {
    pub session_id: String,
    pub session_data: String,
    pub user_id: i64,
    pub ip: String,
    pub last_activity: i64,
}

/// The session store, mirroring `XF\Session\SessionStorage`.
pub struct SessionStore {
    db: Db,
}

impl SessionStore {
    pub fn new(db: Db) -> Self {
        Self { db }
    }

    /// Look up a session by id. Returns `None` if missing or expired.
    pub fn get(&self, id: &str) -> Result<Option<Session>> {
        if id.is_empty() {
            return Ok(None);
        }
        let row = self.db.with_conn(|c| {
            c.query_row(
                "SELECT session_id, session_data, user_id, ip, last_activity FROM xf_session WHERE session_id = ?",
                params![id],
                |r| {
                    Ok(Session {
                        session_id: r.get(0)?,
                        session_data: r.get(1)?,
                        user_id: r.get(2)?,
                        ip: r.get(3)?,
                        last_activity: r.get(4)?,
                    })
                },
            )
            .optional()
        })?;
        Ok(row)
    }

    /// Create a brand-new guest session.
    pub fn create(&self, ip: &str) -> Result<Session> {
        let id = str::random_hex(16);
        let now = crate::time::now();
        self.db.execute(
            "INSERT INTO xf_session (session_id, session_data, user_id, ip, last_activity) VALUES (?, '{}', 0, ?, ?)",
            &[&id as &dyn rusqlite::ToSql, &ip, &now],
        )?;
        Ok(Session {
            session_id: id,
            session_data: "{}".into(),
            user_id: 0,
            ip: ip.into(),
            last_activity: now,
        })
    }

    /// Bind a user to the session (called after successful login).
    pub fn attach_user(&self, id: &str, user_id: i64) -> Result<()> {
        let now = crate::time::now();
        self.db.execute(
            "UPDATE xf_session SET user_id = ?, last_activity = ? WHERE session_id = ?",
            &[&user_id as &dyn rusqlite::ToSql, &now, &id],
        )?;
        Ok(())
    }

    /// Destroy a session (logout).
    pub fn destroy(&self, id: &str) -> Result<()> {
        self.db.execute(
            "DELETE FROM xf_session WHERE session_id = ?",
            &[&id as &dyn rusqlite::ToSql],
        )?;
        Ok(())
    }

    /// Bump `last_activity` so the session stays alive.
    pub fn touch(&self, id: &str) -> Result<()> {
        let now = crate::time::now();
        self.db.execute(
            "UPDATE xf_session SET last_activity = ? WHERE session_id = ?",
            &[&now as &dyn rusqlite::ToSql, &id],
        )?;
        Ok(())
    }
}

/// Garbage-collect expired sessions (older than `lifetime` seconds).
pub fn gc(db: &Db, lifetime: i64) -> Result<usize> {
    let cutoff = crate::time::now() - lifetime;
    db.execute(
        "DELETE FROM xf_session WHERE last_activity < ?",
        &[&cutoff as &dyn rusqlite::ToSql],
    )
}

/// Build the Set-Cookie header value for a session id.
pub fn cookie(name: &str, value: &str, cfg: &Config) -> String {
    format!(
        "{name}={value}; Path=/; Max-Age={}; HttpOnly; SameSite=Lax",
        cfg.session_lifetime
    )
}

use rusqlite::OptionalExtension;
