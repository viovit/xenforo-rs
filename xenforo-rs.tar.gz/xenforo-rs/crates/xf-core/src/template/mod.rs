//! Template engine — backed by [`minijinja`], mirroring `XF\Template\Templater`.
//!
//! Templates are embedded at compile time via `include_str!` (the contents of
//! `templates/*.html`). They use Jinja2 syntax (`{{ var }}`, `{% if %}`,
//! `{% for %}`, `{% extends %}`, `{% block %}`, `{% include %}`) which is close
//! to XenForo's own template syntax.
use crate::error::{Error, Result};
use minijinja::{Environment, Value};
use once_cell::sync::OnceCell;
use std::sync::Arc;

/// Embedded template sources, keyed by name.
const TEMPLATES: &[(&str, &str)] = &[
    ("PAGE_CONTAINER", include_str!("../../../../templates/PAGE_CONTAINER.html")),
    ("forum_list", include_str!("../../../../templates/forum_list.html")),
    ("forum_view", include_str!("../../../../templates/forum_view.html")),
    ("post_thread", include_str!("../../../../templates/post_thread.html")),
    ("thread_view", include_str!("../../../../templates/thread_view.html")),
    ("post_macros", include_str!("../../../../templates/post_macros.html")),
    ("member_view", include_str!("../../../../templates/member_view.html")),
    ("member_list", include_str!("../../../../templates/member_list.html")),
    ("login", include_str!("../../../../templates/login.html")),
    ("register", include_str!("../../../../templates/register.html")),
    ("account", include_str!("../../../../templates/account.html")),
    ("message", include_str!("../../../../templates/message.html")),
    ("error", include_str!("../../../../templates/error.html")),
    ("online", include_str!("../../../../templates/online.html")),
    ("search", include_str!("../../../../templates/search.html")),
];

/// The template engine. Cheap to clone (`Arc` internally).
#[derive(Clone)]
pub struct TemplateEngine {
    env: Arc<Environment<'static>>,
}

static GLOBAL: OnceCell<TemplateEngine> = OnceCell::new();

impl TemplateEngine {
    /// Build a fresh engine with all embedded templates registered.
    pub fn new() -> Result<Self> {
        let mut env = Environment::new();
        for (name, src) in TEMPLATES {
            env.add_template(*name, *src)
                .map_err(|e| Error::Template(format!("register {name}: {e}")))?;
        }
        Ok(Self {
            env: Arc::new(env),
        })
    }

    /// Install a process-global engine (used by `App`).
    pub fn install_global(engine: TemplateEngine) {
        let _ = GLOBAL.set(engine);
    }

    /// Access the global engine (must be installed first).
    pub fn global() -> TemplateEngine {
        GLOBAL
            .get()
            .expect("template engine not initialised")
            .clone()
    }

    /// Render `name` with `context`.
    pub fn render(&self, name: &str, context: &serde_json::Value) -> Result<String> {
        let tmpl = self
            .env
            .get_template(name)
            .map_err(|e| Error::Template(format!("load {name}: {e}")))?;
        let ctx = Value::from_serialize(context);
        tmpl.render(&ctx)
            .map_err(|e| Error::Template(format!("render {name}: {e}")))
    }
}
