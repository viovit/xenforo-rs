//! Mirrors `\XF::$time` — a request-scoped Unix timestamp cached at boot.
use std::sync::OnceLock;

static NOW: OnceLock<i64> = OnceLock::new();

/// Returns the cached request-start timestamp (seconds since epoch).
/// If not yet initialised, lazily captures the current time.
pub fn now() -> i64 {
    *NOW.get_or_init(|| chrono::Utc::now().timestamp())
}

/// Resets the cached timestamp (used by tests).
pub fn reset_for_tests() {
    // OnceLock cannot be unset; tests instead call `set_for_tests`.
}

/// Sets an explicit timestamp for deterministic tests.
pub fn set_for_tests(ts: i64) -> bool {
    NOW.set(ts).is_ok()
}
