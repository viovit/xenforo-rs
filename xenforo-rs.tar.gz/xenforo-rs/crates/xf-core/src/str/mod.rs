//! String utilities — a slimmed translation of `XF\Str\Formatter` / `XF\Util\Str`.

/// Lowercase alphanumeric-hyphen slug (mirrors XF `Str::slug` / romanize behaviour
/// for ASCII; non-ASCII bytes are dropped).
pub fn slug(input: &str) -> String {
    let mut out = String::with_capacity(input.len());
    let lower = input.to_lowercase();
    for ch in lower.chars() {
        if ch.is_ascii_alphanumeric() {
            out.push(ch);
        } else if ch.is_whitespace() || ch == '_' || ch == '-' {
            out.push('-');
        }
    }
    while out.contains("--") {
        out = out.replace("--", "-");
    }
    out.trim_matches('-').to_string()
}

/// Truncate `input` to at most `max` characters on a word boundary.
pub fn snippet(input: &str, max: usize) -> String {
    let s = input.trim();
    if s.chars().count() <= max {
        return s.to_string();
    }
    let mut end = 0;
    for (i, _) in s.char_indices().take(max) {
        end = i;
    }
    let mut s = s[..end].to_string();
    if let Some(pos) = s.rfind(|c: char| c.is_whitespace()) {
        if pos > max / 2 {
            s.truncate(pos);
        }
    }
    s.push('…');
    s
}

/// HTML-escape a string (mirrors `htmlspecialchars`).
pub fn html_escape(input: &str) -> String {
    let mut out = String::with_capacity(input.len());
    for ch in input.chars() {
        match ch {
            '&' => out.push_str("&amp;"),
            '<' => out.push_str("&lt;"),
            '>' => out.push_str("&gt;"),
            '"' => out.push_str("&quot;"),
            '\'' => out.push_str("&#039;"),
            _ => out.push(ch),
        }
    }
    out
}

/// Strip BBCode tags, returning the plain text (used for snippets / search).
pub fn strip_bbcode(input: &str) -> String {
    let mut out = String::with_capacity(input.len());
    let mut chars = input.chars().peekable();
    while let Some(ch) = chars.next() {
        if ch == '[' {
            // consume until ']' or end
            let mut tag = String::new();
            let mut closed = false;
            for c in chars.by_ref() {
                if c == ']' {
                    closed = true;
                    break;
                }
                tag.push(c);
            }
            if !closed {
                out.push('[');
                out.push_str(&tag);
            } else if tag.starts_with('/') {
                // closing tag, skip
            } else {
                // opening tag — keep its option text for [url=...] etc.? XF keeps nothing.
            }
        } else {
            out.push(ch);
        }
    }
    out.split_whitespace().collect::<Vec<_>>().join(" ")
}

/// Generate a random hex token of `n_bytes` bytes (used for session ids / secret keys).
pub fn random_hex(n_bytes: usize) -> String {
    use rand::RngCore;
    let mut buf = vec![0u8; n_bytes];
    rand::thread_rng().fill_bytes(&mut buf);
    hex::encode(&buf)
}

/// Format a Unix timestamp as a human "X minutes ago" string (mirrors
/// `XF\Template\Templater::fn_date_dynamic`).
pub fn date_dynamic(ts: i64, now: i64) -> String {
    if ts <= 0 {
        return "—".into();
    }
    let diff = now - ts;
    if diff < 60 {
        format!("{diff} sec ago")
    } else if diff < 3600 {
        format!("{} min ago", diff / 60)
    } else if diff < 86400 {
        format!("{} hour{} ago", diff / 3600, if diff / 3600 == 1 { "" } else { "s" })
    } else if diff < 86400 * 30 {
        format!("{} day{} ago", diff / 86400, if diff / 86400 == 1 { "" } else { "s" })
    } else {
        date_absolute(ts)
    }
}

/// Absolute date `YYYY-MM-DD HH:MM`.
pub fn date_absolute(ts: i64) -> String {
    use chrono::{DateTime, Utc};
    let dt: DateTime<Utc> = DateTime::<Utc>::from_timestamp(ts, 0)
        .unwrap_or_default();
    dt.format("%Y-%m-%d %H:%M").to_string()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn slug_works() {
        assert_eq!(slug("Hello World!"), "hello-world");
        assert_eq!(slug("  Foo -- Bar "), "foo-bar");
    }

    #[test]
    fn escape_works() {
        assert_eq!(html_escape("<a>&\"'"), "&lt;a&gt;&amp;&quot;&#039;");
    }

    #[test]
    fn strip_works() {
        assert_eq!(strip_bbcode("[b]hi[/b] there"), "hi there");
    }
}
