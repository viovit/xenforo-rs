//! `XF\Pub\Controller\PostController`.
use crate::app::App;
use crate::mvc::{Controller, ParamBag, Reply, Request};
use crate::permission::perm;
use crate::pubc::controllers::check_csrf;
use serde_json::json;

pub struct PostController;

impl Controller for PostController {
    fn handle(&self, action: &str, params: &ParamBag, req: &mut Request, app: &App) -> Reply {
        match action {
            "Index" => self.action_index(params, req, app),
            "Edit" => self.action_edit(params, req, app),
            "Delete" => self.action_delete(params, req, app),
            _ => self.action_index(params, req, app),
        }
    }
}

impl PostController {
    /// `posts/{id}` — redirect to the thread at the post anchor (mirrors XF).
    fn action_index(&self, params: &ParamBag, _req: &Request, app: &App) -> Reply {
        let post_id = params.int("post_id", 0);
        let Some(post) = app.post_repo().get_post(post_id).unwrap_or_default() else {
            return Reply::not_found("Post not found.");
        };
        if post.message_state != "visible" {
            return Reply::not_found("Post not found.");
        }
        // Compute the page the post falls on (20 per page) and redirect.
        let per_page = app.config.posts_per_page as i64;
        let page = (post.position / per_page) + 1;
        Reply::redirect(format!(
            "/threads/{}/{}#post-{}",
            post.thread_id,
            if page > 1 { format!("?page={page}") } else { String::new() },
            post.post_id
        ))
    }

    /// `posts/{id}/edit` — edit form (GET) + save (POST).
    fn action_edit(&self, params: &ParamBag, req: &mut Request, app: &App) -> Reply {
        let visitor = app.visitor(req);
        if visitor.is_guest() {
            return Reply::no_permission();
        }
        let post_id = params.int("post_id", 0);
        let Some(post) = app.post_repo().get_post(post_id).unwrap_or_default() else {
            return Reply::not_found("Post not found.");
        };
        let Some(thread) = app.thread_repo().get_thread(post.thread_id).unwrap_or_default() else {
            return Reply::not_found("Thread not found.");
        };
        let can_edit = post.user_id == visitor.user.user_id
            && perm::edit_own_post(&visitor.perms, thread.node_id)
            && post.message_state == "visible";
        if !can_edit {
            return Reply::no_permission();
        }

        if req.method.is_post() {
            if let Some(r) = check_csrf(req, app) {
                return r;
            }
            let message = req.input_or("message", "").trim().to_string();
            if message.is_empty() {
                return Reply::error(400, "Your message is empty.");
            }
            match app.post_repo().edit(post_id, visitor.user.user_id, &message) {
                Ok(()) => return Reply::redirect(format!("/posts/{}", post_id)),
                Err(e) => return Reply::error(500, format!("Could not save: {e}")),
            }
        }

        // GET — render a minimal inline edit form via the message template.
        let ctx = json!({
            "message": format!("<h2>Editing post #{}</h2><form method=\"post\" action=\"/posts/{}/edit\" class=\"form\"><input type=\"hidden\" name=\"csrf_token\" value=\"{}\"><div class=\"form-row\"><textarea name=\"message\" rows=\"10\" required>{}</textarea></div><div class=\"form-actions\"><button class=\"button button--primary\" type=\"submit\">Save</button> <a class=\"button\" href=\"/posts/{}\">Cancel</a></div></form>", post.post_id, post.post_id, visitor.csrf_token, post.message, post.post_id),
        });
        Reply::view("message", ctx)
    }

    /// `posts/{id}/delete` — soft-delete (owner or admin).
    fn action_delete(&self, params: &ParamBag, req: &mut Request, app: &App) -> Reply {
        let visitor = app.visitor(req);
        if visitor.is_guest() {
            return Reply::no_permission();
        }
        let post_id = params.int("post_id", 0);
        let Some(post) = app.post_repo().get_post(post_id).unwrap_or_default() else {
            return Reply::not_found("Post not found.");
        };
        let Some(thread) = app.thread_repo().get_thread(post.thread_id).unwrap_or_default() else {
            return Reply::not_found("Thread not found.");
        };
        let can_delete = (post.user_id == visitor.user.user_id
            && perm::delete_own_post(&visitor.perms, thread.node_id))
            || visitor.is_admin();
        if !can_delete {
            return Reply::no_permission();
        }
        if let Some(r) = check_csrf(req, app) {
            return r;
        }
        let _ = app.post_repo().soft_delete(post_id);
        let _ = app.post_repo().rebuild_thread_counters(post.thread_id);
        let _ = app.forum_repo().rebuild_totals(thread.node_id);
        Reply::redirect(format!("/threads/{}/", post.thread_id))
    }
}
