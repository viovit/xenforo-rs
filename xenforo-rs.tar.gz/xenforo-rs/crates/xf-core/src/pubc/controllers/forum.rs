//! `XF\Pub\Controller\ForumController`.
use crate::app::App;
use crate::mvc::{Controller, ParamBag, Reply, Request};
use crate::permission::perm;
use crate::pubc::helpers::{self, paginate, pagination_json, breadcrumbs_json};
use crate::pubc::controllers::check_csrf;
use serde_json::json;

pub struct ForumController;

impl Controller for ForumController {
    fn handle(&self, action: &str, params: &ParamBag, req: &mut Request, app: &App) -> Reply {
        match action {
            "Index" => self.action_index(req, app),
            "Forum" => self.action_forum(params, req, app),
            "PostThread" => self.action_post_thread(params, req, app),
            "MarkRead" => self.action_mark_read(params, req, app),
            _ => self.action_index(req, app),
        }
    }
}

impl ForumController {
    /// `forums/` — the forum list. XF's `forumsDefaultPage` is the index, so
    /// redirect there (the index renders the same `forum_list` template).
    fn action_index(&self, _req: &Request, _app: &App) -> Reply {
        Reply::redirect("/")
    }

    /// `forums/{id}` — view a forum (thread list, paged).
    fn action_forum(&self, params: &ParamBag, req: &Request, app: &App) -> Reply {
        let visitor = app.visitor(req);
        let node_id = params.int("node_id", 0);
        let forum_opt = match app.forum_repo().get_viewable_forum(node_id) {
            Ok(v) => v,
            Err(e) => {
                tracing::error!(error = %e, "forum view load");
                return Reply::error(500, "Failed to load forum.");
            }
        };
        let Some((node, forum)) = forum_opt else {
            return Reply::not_found("The requested forum could not be found.");
        };

        if !perm::view_forum(&visitor.perms, node_id) || !perm::view_content(&visitor.perms, node_id)
        {
            return Reply::no_permission();
        }

        let per_page = app.config.threads_per_page as i64;
        let page = req.input_int("page", 1).max(1);
        let threads = match app.thread_repo().list_in_forum(node_id, page, per_page) {
            Ok(t) => t,
            Err(e) => {
                tracing::error!(error = %e, "forum threads");
                return Reply::error(500, "Failed to load threads.");
            }
        };
        let total = app.thread_repo().count_in_forum(node_id).unwrap_or(0);
        let total_pages = ((total + per_page - 1) / per_page).max(1);
        let base = format!("/forums/{}/{}", node_id, crate::str::slug(&node.title));
        let pagination = paginate(&base, page, total_pages);

        let crumbs = app
            .node_repo()
            .breadcrumbs(&node)
            .unwrap_or_default();

        let ctx = json!({
            "forum": {
                "node_id": forum.node_id,
                "title": node.title,
                "description": node.description,
                "slug": crate::str::slug(&node.title),
            },
            "threads": threads.iter().map(helpers::thread_json).collect::<Vec<_>>(),
            "pagination": pagination_json(&pagination),
            "can_post_thread": perm::post_thread(&visitor.perms, node_id) && forum.allow_posting,
            "breadcrumbs": breadcrumbs_json(&crumbs),
        });
        Reply::view("forum_view", ctx)
    }

    /// `forums/{id}/post-thread` — create-thread form (GET) + submit (POST).
    fn action_post_thread(&self, params: &ParamBag, req: &mut Request, app: &App) -> Reply {
        let visitor = app.visitor(req);
        if visitor.is_guest() {
            return Reply::redirect("/login?redirect=/forums/".to_string()
                + &params.int("node_id", 0).to_string()
                + "/post-thread");
        }
        let node_id = params.int("node_id", 0);
        let forum_opt = match app.forum_repo().get_viewable_forum(node_id) {
            Ok(v) => v,
            Err(_) => return Reply::error(500, "Failed to load forum."),
        };
        let Some((node, forum)) = forum_opt else {
            return Reply::not_found("Forum not found.");
        };
        if !perm::post_thread(&visitor.perms, node_id) || !forum.allow_posting {
            return Reply::no_permission();
        }

        if req.method.is_post() {
            if let Some(r) = check_csrf(req, app) {
                return r;
            }
            let title = req.input_or("title", "").trim().to_string();
            let message = req.input_or("message", "").trim().to_string();
            if title.is_empty() || title.chars().count() > 150 {
                return render_post_thread_form(node_id, &node.title, &title, &message, "Please enter a valid title (max 150 characters).");
            }
            if message.is_empty() {
                return render_post_thread_form(node_id, &node.title, &title, &message, "Please enter a message.");
            }
            match app.thread_repo().create_thread(
                node_id,
                visitor.user.user_id,
                &visitor.user.username,
                &title,
                &message,
            ) {
                Ok((tid, _)) => {
                    if let Err(e) = app.forum_repo().rebuild_totals(node_id) {
                        tracing::warn!(error = %e, "rebuild totals");
                    }
                    return Reply::redirect(format!("/threads/{}/", tid));
                }
                Err(e) => {
                    return render_post_thread_form(node_id, &node.title, &title, &message, &e.to_string());
                }
            }
        }

        render_post_thread_form(node_id, &node.title, "", "", "")
    }

    /// `forums/-/mark-read` — mark a forum (or all) read.
    fn action_mark_read(&self, _params: &ParamBag, req: &mut Request, app: &App) -> Reply {
        let visitor = app.visitor(req);
        if visitor.is_guest() {
            return Reply::no_permission();
        }
        let node_id = req.input_int("node_id", 0);
        if node_id > 0 {
            let _ = app.forum_repo().mark_read(node_id, visitor.user.user_id);
        }
        Reply::message("Forum marked as read.")
    }
}

fn render_post_thread_form(node_id: i64, forum_title: &str, title: &str, message: &str, error: &str) -> Reply {
    Reply::view(
        "post_thread",
        json!({
            "forum": { "node_id": node_id, "title": forum_title },
            "title": title,
            "message": message,
            "error": error,
        }),
    )
}
