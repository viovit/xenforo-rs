//! `XF\Pub\Controller\IndexController` — the board index (forum list).
use crate::mvc::{Controller, ParamBag, Reply, Request};
use crate::app::App;
use crate::permission::perm;
use serde_json::{json, Value};

pub struct IndexController;

impl Controller for IndexController {
    fn handle(&self, action: &str, _params: &ParamBag, req: &mut Request, app: &App) -> Reply {
        match action {
            "Index" => self.action_index(req, app),
            _ => self.action_index(req, app),
        }
    }
}

impl IndexController {
    fn action_index(&self, req: &mut Request, app: &App) -> Reply {
        let visitor = app.visitor(req);
        if !perm::view(&visitor.perms) {
            return Reply::no_permission();
        }

        let nodes = match app.node_repo().list_node_forums() {
            Ok(n) => n,
            Err(e) => {
                tracing::error!(error = %e, "index: list nodes failed");
                return Reply::error(500, "Failed to load forum list.");
            }
        };

        // Filter by view permission and build a category → forums tree.
        let mut categories: Vec<Value> = Vec::new();
        let mut current_cat: Option<Value> = None;
        for n in &nodes {
            if n.node_type_id == "Category" {
                if let Some(cat) = current_cat.take() {
                    categories.push(cat);
                }
                current_cat = Some(json!({
                    "node_id": n.node_id,
                    "title": n.title,
                    "slug": n.slug,
                    "description": n.description,
                    "forums": [],
                }));
            } else if n.node_type_id == "Forum" {
                if !perm::view_forum(&visitor.perms, n.node_id) {
                    continue;
                }
                let forum = json!({
                    "node_id": n.node_id,
                    "title": n.title,
                    "slug": n.slug,
                    "description": n.description,
                    "discussion_count": n.discussion_count,
                    "message_count": n.message_count,
                    "last_thread_id": n.last_thread_id,
                    "last_thread_title": n.last_thread_title,
                    "last_post_username": n.last_post_username,
                    "last_post_date": n.last_post_date,
                    "last_post_date_human": crate::str::date_dynamic(n.last_post_date, crate::time::now()),
                });
                if let Some(cat) = current_cat.as_mut() {
                    if let Some(arr) = cat.get_mut("forums").and_then(|f| f.as_array_mut()) {
                        arr.push(forum);
                    }
                } else {
                    // Orphan forum with no category: create a synthetic one.
                    current_cat = Some(json!({
                        "node_id": 0,
                        "title": "Forums",
                        "slug": "forums",
                        "description": "",
                        "forums": [forum],
                    }));
                }
            }
        }
        if let Some(cat) = current_cat.take() {
            categories.push(cat);
        }

        let ctx = json!({
            "categories": categories,
        });
        Reply::view("forum_list", ctx)
    }
}
