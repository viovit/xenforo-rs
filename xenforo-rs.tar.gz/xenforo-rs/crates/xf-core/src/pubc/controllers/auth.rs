//! `XF\Pub\Controller\LoginController` / `LogoutController` / `RegisterController`.
use crate::app::App;
use crate::auth::verify;
use crate::mvc::{Controller, ParamBag, Reply, Request};
use crate::pubc::controllers::check_csrf;
use serde_json::json;

// ---------------------------------------------------------------------------
// Login
// ---------------------------------------------------------------------------
pub struct LoginController;

impl Controller for LoginController {
    fn handle(&self, action: &str, _params: &ParamBag, req: &mut Request, app: &App) -> Reply {
        match action {
            "Login" | "Index" => self.action_login(req, app),
            _ => self.action_login(req, app),
        }
    }
}

impl LoginController {
    fn action_login(&self, req: &mut Request, app: &App) -> Reply {
        if req.method.is_post() {
            if let Some(r) = check_csrf(req, app) {
                return r;
            }
            let login = req.input_or("login", "").trim().to_string();
            let password = req.input_or("password", "").to_string();
            let redirect = req.input_or("redirect", "/").to_string();

            if login.is_empty() || password.is_empty() {
                return render_login("", "Please enter both your username and password.");
            }
            let Some(user) = app.user_repo().get_user_by_login(&login).unwrap_or_default() else {
                return render_login(&login, "No account matching that username/email was found.");
            };
            if user.is_banned || user.user_state == "disabled" {
                return render_login(&login, "Your account has been disabled.");
            }
            let Some(auth) = app.user_repo().get_auth(user.user_id).unwrap_or_default() else {
                return render_login(&login, "Account has no credentials set.");
            };
            let ok = verify(&auth.scheme_class, &auth.data, &password).unwrap_or(false);
            if !ok {
                return render_login(&login, "Incorrect password. Please try again.");
            }

            // Success — bind the visitor's session to the user.
            let visitor = app.visitor(req);
            let session_id = visitor.session_id.clone();
            if !session_id.is_empty() {
                let _ = app.db.execute(
                    "UPDATE xf_session SET user_id = ? WHERE session_id = ?",
                    &[&user.user_id as &dyn rusqlite::ToSql, &session_id],
                );
            }
            return Reply::redirect(safe_redirect(&redirect, &app.config.board_url));
        }
        render_login("", "")
    }
}

fn render_login(login: &str, error: &str) -> Reply {
    Reply::view(
        "login",
        json!({ "login": login, "error": error, "redirect": "" }),
    )
}

/// Only allow redirects to same-origin paths.
fn safe_redirect(url: &str, board_url: &str) -> String {
    if url.starts_with('/') && !url.starts_with("//") {
        return url.to_string();
    }
    if url.starts_with(board_url) {
        return url[board_url.len()..].to_string();
    }
    "/".to_string()
}

// ---------------------------------------------------------------------------
// Logout
// ---------------------------------------------------------------------------
pub struct LogoutController;

impl Controller for LogoutController {
    fn handle(&self, _action: &str, _params: &ParamBag, req: &mut Request, app: &App) -> Reply {
        if req.method.is_post() {
            if let Some(r) = check_csrf(req, app) {
                return r;
            }
        }
        let visitor = app.visitor(req);
        if !visitor.session_id.is_empty() {
            // Detach the user (keep the session row, set user_id = 0).
            let _ = app.db.execute(
                "UPDATE xf_session SET user_id = 0 WHERE session_id = ?",
                &[&visitor.session_id as &dyn rusqlite::ToSql],
            );
        }
        Reply::redirect("/")
    }
}

// ---------------------------------------------------------------------------
// Register
// ---------------------------------------------------------------------------
pub struct RegisterController;

impl Controller for RegisterController {
    fn handle(&self, _action: &str, _params: &ParamBag, req: &mut Request, app: &App) -> Reply {
        if !app.config.registration_enabled {
            return Reply::view(
                "register",
                json!({
                    "registration_enabled": false,
                    "error": "",
                    "min_username": app.config.min_username_length,
                    "max_username": app.config.max_username_length,
                    "min_password": app.config.min_password_length,
                }),
            );
        }
        if req.method.is_post() {
            if let Some(r) = check_csrf(req, app) {
                return r;
            }
            let username = req.input_or("username", "").trim().to_string();
            let email = req.input_or("email", "").trim().to_string();
            let password = req.input_or("password", "").to_string();

            match app
                .user_repo()
                .create_user(&username, &email, &password, 3 /* Registered */)
            {
                Ok(user_id) => {
                    // Auto-login: bind the session to the new user.
                    let visitor = app.visitor(req);
                    if !visitor.session_id.is_empty() {
                        let _ = app.db.execute(
                            "UPDATE xf_session SET user_id = ? WHERE session_id = ?",
                            &[&user_id as &dyn rusqlite::ToSql, &visitor.session_id],
                        );
                    }
                    Reply::redirect("/")
                }
                Err(e) => Reply::view(
                    "register",
                    json!({
                        "registration_enabled": true,
                        "error": e.to_string(),
                        "min_username": app.config.min_username_length,
                        "max_username": app.config.max_username_length,
                        "min_password": app.config.min_password_length,
                        "username": username,
                        "email": email,
                    }),
                ),
            }
        } else {
            Reply::view(
                "register",
                json!({
                    "registration_enabled": true,
                    "error": "",
                    "min_username": app.config.min_username_length,
                    "max_username": app.config.max_username_length,
                    "min_password": app.config.min_password_length,
                }),
            )
        }
    }
}
