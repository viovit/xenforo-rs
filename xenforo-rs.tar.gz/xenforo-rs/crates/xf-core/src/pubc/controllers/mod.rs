//! Public controllers — one module per logical group.
pub mod account;
pub mod admin;
pub mod forum;
pub mod index;
pub mod member;
pub mod misc;
pub mod post;
pub mod thread;

pub use account::AccountController;
pub use admin::AdminController;
pub use forum::ForumController;
pub use index::IndexController;
pub use member::MemberController;
pub use misc::{OnlineController, SearchController};
pub use post::PostController;
pub use thread::ThreadController;

// Auth controllers live together (login / logout / register).
mod auth;
pub use auth::{LoginController, LogoutController, RegisterController};

/// Verify the CSRF token on a POST request. Returns a [`Reply::error`] on
/// mismatch, else `None` (caller proceeds).
pub fn check_csrf(req: &crate::mvc::Request, app: &crate::app::App) -> Option<crate::mvc::Reply> {
    if !req.method.is_post() {
        return None;
    }
    let visitor = app.visitor(req);
    let token = req.input("csrf_token").unwrap_or("");
    if token.is_empty() || token != visitor.csrf_token {
        return Some(crate::mvc::Reply::error(
            403,
            "Security token missing or invalid. Please refresh and try again.",
        ));
    }
    None
}
