//! `XF\Pub\Controller\ThreadController`.
use crate::app::App;
use crate::bbcode;
use crate::mvc::{Controller, ParamBag, Reply, Request};
use crate::permission::perm;
use crate::pubc::controllers::check_csrf;
use crate::pubc::helpers::{self, paginate, pagination_json, breadcrumbs_json};
use serde_json::json;

pub struct ThreadController;

impl Controller for ThreadController {
    fn handle(&self, action: &str, params: &ParamBag, req: &mut Request, app: &App) -> Reply {
        match action {
            "Index" => self.action_index(params, req, app),
            "AddReply" => self.action_add_reply(params, req, app),
            "MarkRead" => self.action_mark_read(params, req, app),
            _ => self.action_index(params, req, app),
        }
    }
}

impl ThreadController {
    /// `threads/{id}` — view a thread (posts, paged).
    fn action_index(&self, params: &ParamBag, req: &Request, app: &App) -> Reply {
        let visitor = app.visitor(req);
        let thread_id = params.int("thread_id", 0);
        let thread_opt = match app.thread_repo().get_thread_with_forum(thread_id) {
            Ok(v) => v,
            Err(e) => {
                tracing::error!(error = %e, "thread load");
                return Reply::error(500, "Failed to load thread.");
            }
        };
        let Some((thread, node)) = thread_opt else {
            return Reply::not_found("The requested thread could not be found.");
        };

        if !perm::view_content(&visitor.perms, thread.node_id) {
            return Reply::no_permission();
        }
        if thread.discussion_state != "visible" && !visitor.is_admin() {
            return Reply::not_found("The requested thread could not be found.");
        }

        // Increment view counter (mirrors `incrementViewCounter`).
        let _ = app.thread_repo().increment_views(thread_id);

        let per_page = app.config.posts_per_page as i64;
        let page = req.input_int("page", 1).max(1);
        let posts = match app.thread_repo().list_posts(thread_id, page, per_page) {
            Ok(p) => p,
            Err(e) => {
                tracing::error!(error = %e, "thread posts");
                return Reply::error(500, "Failed to load posts.");
            }
        };

        let total_posts = thread.reply_count + 1;
        let total_pages = ((total_posts + per_page - 1) / per_page).max(1);
        let base = format!("/threads/{}/", thread_id);
        let pagination = paginate(&base, page, total_pages);

        let crumbs = app.node_repo().breadcrumbs(&node).unwrap_or_default();
        let viewer_id = visitor.user.user_id;
        let posts_json: Vec<_> = posts
            .iter()
            .map(|p| {
                let html = bbcode::render_to_html(&p.message).unwrap_or_default();
                helpers::post_json(p, html, thread.first_post_id, viewer_id)
            })
            .collect();

        let can_reply = !visitor.is_guest()
            && thread.discussion_open
            && perm::reply(&visitor.perms, thread.node_id);
        let can_edit = !visitor.is_guest() && perm::edit_own_post(&visitor.perms, thread.node_id);

        let ctx = json!({
            "thread": helpers::thread_json(&thread),
            "posts": posts_json,
            "pagination": pagination_json(&pagination),
            "can_reply": can_reply,
            "can_edit": can_edit,
            "breadcrumbs": breadcrumbs_json(&crumbs),
        });
        Reply::view("thread_view", ctx)
    }

    /// `threads/{id}/add-reply` — POST a reply.
    fn action_add_reply(&self, params: &ParamBag, req: &mut Request, app: &App) -> Reply {
        let visitor = app.visitor(req);
        if visitor.is_guest() {
            return Reply::redirect(format!("/login?redirect=/threads/{}/", params.int("thread_id", 0)));
        }
        let thread_id = params.int("thread_id", 0);
        let Some(thread) = app.thread_repo().get_thread(thread_id).unwrap_or_default() else {
            return Reply::not_found("Thread not found.");
        };
        if !perm::reply(&visitor.perms, thread.node_id) || !thread.discussion_open {
            return Reply::no_permission();
        }
        if let Some(r) = check_csrf(req, app) {
            return r;
        }
        let message = req.input_or("message", "").trim().to_string();
        if message.is_empty() {
            return Reply::error(400, "Your message is empty.");
        }
        match app.thread_repo().add_reply(
            thread_id,
            visitor.user.user_id,
            &visitor.user.username,
            &message,
        ) {
            Ok(post_id) => {
                // Rebuild the forum totals (last post etc.).
                if let Err(e) = app.forum_repo().rebuild_totals(thread.node_id) {
                    tracing::warn!(error = %e, "rebuild totals after reply");
                }
                // Redirect to the new post anchor.
                Reply::redirect(format!("/threads/{}/#post-{}", thread_id, post_id))
            }
            Err(e) => Reply::error(500, format!("Could not post reply: {e}")),
        }
    }

    /// `threads/{id}/mark-read`.
    fn action_mark_read(&self, _params: &ParamBag, req: &mut Request, app: &App) -> Reply {
        let visitor = app.visitor(req);
        if visitor.is_guest() {
            return Reply::no_permission();
        }
        let thread_id = req.input_int("thread_id", 0);
        if thread_id > 0 {
            let now = crate::time::now();
            let _ = app.db.execute(
                "INSERT INTO xf_thread_read (thread_id, user_id, thread_read_date) VALUES (?, ?, ?) \
                 ON CONFLICT(thread_id, user_id) DO UPDATE SET thread_read_date = excluded.thread_read_date",
                &[
                    &thread_id as &dyn rusqlite::ToSql,
                    &visitor.user.user_id,
                    &now,
                ],
            );
        }
        Reply::message("Thread marked as read.")
    }
}
