//! `XF\Pub\Controller\MemberController`.
use crate::app::App;
use crate::mvc::{Controller, ParamBag, Reply, Request};
use crate::permission::perm;
use crate::pubc::controllers::check_csrf;
use crate::pubc::helpers::{self, paginate, pagination_json};
use serde_json::json;

pub struct MemberController;

impl Controller for MemberController {
    fn handle(&self, action: &str, params: &ParamBag, req: &mut Request, app: &App) -> Reply {
        match action {
            "List" | "Index" => self.action_list(req, app),
            "View" => self.action_view(params, req, app),
            "Follow" => self.action_follow(params, req, app),
            _ => self.action_list(req, app),
        }
    }
}

impl MemberController {
    /// `members` — member list (paged).
    fn action_list(&self, req: &Request, app: &App) -> Reply {
        let visitor = app.visitor(req);
        if !perm::view(&visitor.perms) {
            return Reply::no_permission();
        }
        let per_page = 30;
        let page = req.input_int("page", 1).max(1);
        let users = app.user_repo().list_members(page, per_page).unwrap_or_default();
        let total = app.user_repo().count_members().unwrap_or(0);
        let total_pages = ((total + per_page - 1) / per_page).max(1);
        let pagination = paginate("/members", page, total_pages);

        let ctx = json!({
            "users": users.iter().map(helpers::user_json).collect::<Vec<_>>(),
            "pagination": pagination_json(&pagination),
        });
        Reply::view("member_list", ctx)
    }

    /// `members/{id}` — view a member profile.
    fn action_view(&self, params: &ParamBag, req: &Request, app: &App) -> Reply {
        let visitor = app.visitor(req);
        let user_id = params.int("user_id", 0);
        let Some(user) = app.user_repo().get_user(user_id).unwrap_or_default() else {
            return Reply::not_found("Member not found.");
        };
        if user.user_state != "valid" && !visitor.is_admin() {
            return Reply::not_found("Member not found.");
        }
        let profile = app.user_repo().get_profile(user_id).unwrap_or_default();
        let following = is_following(app, visitor.user.user_id, user_id);

        let ctx = json!({
            "user": helpers::user_json(&user),
            "profile": {
                "about": profile.as_ref().map(|p| p.about.clone()).unwrap_or_default(),
                "signature": profile.as_ref().map(|p| p.signature.clone()).unwrap_or_default(),
                "website": profile.as_ref().map(|p| p.website.clone()).unwrap_or_default(),
                "location": profile.as_ref().map(|p| p.location.clone()).unwrap_or_default(),
            },
            "is_following": following,
            "visitor": {
                "is_guest": visitor.is_guest(),
                "is_self": visitor.user.user_id == user_id,
            },
        });
        Reply::view("member_view", ctx)
    }

    /// `members/{id}/follow` — toggle follow (POST).
    fn action_follow(&self, params: &ParamBag, req: &mut Request, app: &App) -> Reply {
        let visitor = app.visitor(req);
        if visitor.is_guest() {
            return Reply::no_permission();
        }
        if let Some(r) = check_csrf(req, app) {
            return r;
        }
        let target_id = params.int("user_id", 0);
        if target_id == 0 || target_id == visitor.user.user_id {
            return Reply::error(400, "Invalid member.");
        }
        let currently = is_following(app, visitor.user.user_id, target_id);
        if currently {
            let _ = app.db.execute(
                "DELETE FROM xf_user_follow WHERE user_id = ? AND follow_user_id = ?",
                &[
                    &visitor.user.user_id as &dyn rusqlite::ToSql,
                    &target_id,
                ],
            );
        } else {
            let now = crate::time::now();
            let _ = app.db.execute(
                "INSERT OR IGNORE INTO xf_user_follow (user_id, follow_user_id, follow_date) VALUES (?, ?, ?)",
                &[
                    &visitor.user.user_id as &dyn rusqlite::ToSql,
                    &target_id,
                    &now,
                ],
            );
        }
        Reply::redirect(format!("/members/{}", target_id))
    }
}

/// Check whether `viewer_id` follows `target_id`. (The `xf_user_follow` table
/// is created lazily here if it does not yet exist.)
fn is_following(app: &App, viewer_id: i64, target_id: i64) -> bool {
    if viewer_id == 0 || target_id == 0 {
        return false;
    }
    let _ = app.db.execute(
        "CREATE TABLE IF NOT EXISTS xf_user_follow (\
            user_id INTEGER NOT NULL, \
            follow_user_id INTEGER NOT NULL, \
            follow_date INTEGER NOT NULL DEFAULT 0, \
            PRIMARY KEY(user_id, follow_user_id))",
        &[],
    );
    app.db
        .query_scalar::<i64>(
            "SELECT COUNT(*) FROM xf_user_follow WHERE user_id = ? AND follow_user_id = ?",
            &[&viewer_id as &dyn rusqlite::ToSql, &target_id],
        )
        .ok()
        .flatten()
        .map(|c| c > 0)
        .unwrap_or(false)
}
