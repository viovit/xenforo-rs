//! `XF\Pub\Controller\OnlineController` + `SearchController`.
use crate::app::App;
use crate::entities::SessionActivity;
use crate::entity::Entity;
use crate::mvc::{Controller, ParamBag, Reply, Request};
use crate::str;
use serde_json::json;

// ---------------------------------------------------------------------------
// Online
// ---------------------------------------------------------------------------
pub struct OnlineController;

impl Controller for OnlineController {
    fn handle(&self, _action: &str, _params: &ParamBag, _req: &mut Request, app: &App) -> Reply {
        let cutoff = crate::time::now() - 15 * 60;
        let activities = app
            .db
            .with_conn(|c| {
                let mut stmt = c.prepare(
                    "SELECT * FROM xf_session_activity WHERE last_activity >= ? ORDER BY last_activity DESC LIMIT 200",
                )?;
                let rows = stmt
                    .query_map(rusqlite::params![cutoff], SessionActivity::from_row)?
                    .collect::<rusqlite::Result<Vec<_>>>()?;
                Ok::<_, rusqlite::Error>(rows)
            })
            .unwrap_or_default();

        // Resolve usernames.
        let mut rows = Vec::new();
        for a in &activities {
            let username = if a.user_id != 0 {
                app.user_repo()
                    .get_user(a.user_id)
                    .ok()
                    .flatten()
                    .map(|u| u.username)
                    .unwrap_or_else(|| "Guest".into())
            } else {
                "Guest".to_string()
            };
            rows.push(json!({
                "user_id": a.user_id,
                "username": username,
                "last_activity": a.last_activity,
                "last_activity_human": str::date_dynamic(a.last_activity, crate::time::now()),
                "action": format!("{}::{}", a.controller, a.action),
            }));
        }

        let ctx = json!({
            "total": rows.len(),
            "cutoff_minutes": 15,
            "users": rows,
        });
        Reply::view("online", ctx)
    }
}

// ---------------------------------------------------------------------------
// Search
// ---------------------------------------------------------------------------
pub struct SearchController;

impl Controller for SearchController {
    fn handle(&self, _action: &str, _params: &ParamBag, req: &mut Request, app: &App) -> Reply {
        let query = req.input_or("q", "").trim().to_string();
        if query.is_empty() {
            return Reply::view("search", json!({ "query": "", "results": [], "total": 0 }));
        }
        let hits = app.thread_repo().search(&query, 50).unwrap_or_default();
        let now = crate::time::now();
        let results: Vec<_> = hits
            .iter()
            .map(|h| {
                json!({
                    "thread_id": h.thread_id,
                    "post_id": h.post_id,
                    "title": h.title,
                    "username": h.username,
                    "user_id": h.user_id,
                    "post_date": h.post_date,
                    "post_date_human": str::date_dynamic(h.post_date, now),
                    "snippet": h.snippet,
                })
            })
            .collect();
        let ctx = json!({
            "query": query,
            "results": results,
            "total": results.len(),
        });
        Reply::view("search", ctx)
    }
}
