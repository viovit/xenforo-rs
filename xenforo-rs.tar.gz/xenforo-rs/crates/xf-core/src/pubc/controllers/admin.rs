//! `XF\Admin\Controller\Index` — a minimal admin scaffold.
//!
//! The full XenForo admin control panel is a large sub-application; this port
//! exposes a lightweight dashboard showing board statistics and a user-search
//! box. It is gated on the visitor being an administrator.
use crate::app::App;
use crate::mvc::{Controller, ParamBag, Reply, Request};
use crate::str;
use serde_json::json;

pub struct AdminController;

impl Controller for AdminController {
    fn handle(&self, _action: &str, _params: &ParamBag, req: &mut Request, app: &App) -> Reply {
        let visitor = app.visitor(req);
        if !visitor.is_admin() {
            return Reply::redirect("/login?redirect=/admin");
        }

        let stats = app
            .db
            .with_conn(|c| {
                let users: i64 = c.query_row("SELECT COUNT(*) FROM xf_user", [], |r| r.get(0))?;
                let threads: i64 =
                    c.query_row("SELECT COUNT(*) FROM xf_thread WHERE discussion_state='visible'", [], |r| {
                        r.get(0)
                    })?;
                let posts: i64 =
                    c.query_row("SELECT COUNT(*) FROM xf_post WHERE message_state='visible'", [], |r| {
                        r.get(0)
                    })?;
                let forums: i64 = c.query_row("SELECT COUNT(*) FROM xf_forum", [], |r| r.get(0))?;
                Ok::<_, rusqlite::Error>(json!({
                    "users": users,
                    "threads": threads,
                    "posts": posts,
                    "forums": forums,
                }))
            })
            .unwrap_or(json!({}));

        let body = format!(
            "<h1>Admin dashboard</h1>\
             <p>Welcome, <strong>{}</strong>. This is a lightweight Rust port of the \
             XenForo admin control panel.</p>\
             <h2>Board statistics</h2>\
             <ul>\
               <li>Users: {}</li>\
               <li>Threads: {}</li>\
               <li>Posts: {}</li>\
               <li>Forums: {}</li>\
             </ul>\
             <p><a href=\"/\">Back to forum</a> &middot; <a href=\"/logout\">Log out</a></p>",
            str::html_escape(&visitor.user.username),
            stats["users"], stats["threads"], stats["posts"], stats["forums"],
        );

        Reply::view(
            "message",
            json!({ "message": body }),
        )
    }
}
