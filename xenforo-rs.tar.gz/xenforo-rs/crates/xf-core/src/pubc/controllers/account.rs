//! `XF\Pub\Controller\AccountController` — minimal account self-service.
use crate::app::App;
use crate::mvc::{Controller, ParamBag, Reply, Request};
use crate::pubc::controllers::check_csrf;
use serde_json::json;

pub struct AccountController;

impl Controller for AccountController {
    fn handle(&self, _action: &str, _params: &ParamBag, req: &mut Request, app: &App) -> Reply {
        let visitor = app.visitor(req);
        if visitor.is_guest() {
            return Reply::redirect("/login?redirect=/account");
        }

        if req.method.is_post() {
            if let Some(r) = check_csrf(req, app) {
                return r;
            }
            // Allow updating the email (mirrors `actionEmail`).
            if let Some(email) = req.input("email") {
                let email = email.trim().to_string();
                if email.contains('@') {
                    let _ = app.db.execute(
                        "UPDATE xf_user SET email = ? WHERE user_id = ?",
                        &[
                            &email as &dyn rusqlite::ToSql,
                            &visitor.user.user_id,
                        ],
                    );
                }
            }
            return Reply::message("Your account has been updated.");
        }

        let ctx = json!({
            "visitor": {
                "user_id": visitor.user.user_id,
                "username": visitor.user.username,
                "email": visitor.user.email,
                "message_count": visitor.user.message_count,
                "reaction_score": visitor.user.reaction_score,
            },
        });
        Reply::view("account", ctx)
    }
}
