//! Shared helpers for pub controllers — pagination, breadcrumbs, and the
//! JSON shapes templates expect for users / threads / posts.
use crate::entities::{Node, Post, Thread, User};
use crate::str;
use serde_json::{json, Value};

/// A page descriptor for pagination.
pub struct Page {
    pub number: i64,
    pub url: Option<String>,
    pub current: bool,
}

/// Pagination bundle.
pub struct Pagination {
    pub pages: Vec<Page>,
    pub prev_url: Option<String>,
    pub next_url: Option<String>,
}

/// Build a pagination bundle for `page` of `total_pages`, linking to `base`
/// (which should contain a `{page}` placeholder or be appended with `?page=N`).
pub fn paginate(base: &str, page: i64, total_pages: i64) -> Pagination {
    let mut pages = Vec::new();
    let start = (page - 2).max(1);
    let end = (start + 4).min(total_pages.max(1));
    for n in start..=end {
        let url = if n == 1 {
            Some(base.to_string())
        } else {
            Some(format!("{base}?page={n}"))
        };
        pages.push(Page {
            number: n,
            url,
            current: n == page,
        });
    }
    let prev_url = if page > 1 {
        Some(if page - 1 == 1 {
            base.to_string()
        } else {
            format!("{base}?page={}", page - 1)
        })
    } else {
        None
    };
    let next_url = if page < total_pages {
        Some(format!("{base}?page={}", page + 1))
    } else {
        None
    };
    Pagination {
        pages,
        prev_url,
        next_url,
    }
}

pub fn pagination_json(p: &Pagination) -> Value {
    json!({
        "pages": p.pages.iter().map(|pg| json!({
            "number": pg.number,
            "url": pg.url,
            "current": pg.current,
        })).collect::<Vec<_>>(),
        "prev_url": p.prev_url,
        "next_url": p.next_url,
    })
}

/// Build breadcrumb JSON from a chain of nodes (root → leaf).
pub fn breadcrumbs_json(nodes: &[Node]) -> Value {
    json!(nodes
        .iter()
        .map(|n| {
            let url = if n.is_forum() {
                format!("/forums/{}/{}", n.node_id, str::slug(&n.title))
            } else {
                "/".to_string()
            };
            json!({ "title": n.title, "url": url })
        })
        .collect::<Vec<_>>())
}

/// Serialise a thread for templates (with human dates).
pub fn thread_json(t: &Thread) -> Value {
    let now = crate::time::now();
    json!({
        "thread_id": t.thread_id,
        "node_id": t.node_id,
        "title": t.title,
        "user_id": t.user_id,
        "username": t.username,
        "reply_count": t.reply_count,
        "view_count": t.view_count,
        "post_date": t.post_date,
        "post_date_human": str::date_dynamic(t.post_date, now),
        "sticky": t.sticky,
        "discussion_state": t.discussion_state,
        "discussion_open": t.discussion_open,
        "first_post_id": t.first_post_id,
        "last_post_id": t.last_post_id,
        "last_post_user_id": t.last_post_user_id,
        "last_post_username": t.last_post_username,
        "last_post_date": t.last_post_date,
        "last_post_date_human": str::date_dynamic(t.last_post_date, now),
    })
}

/// Serialise a post for templates — `html` is the BBCode-rendered message body.
pub fn post_json(p: &Post, html: String, thread_first_post_id: i64, viewer_id: i64) -> Value {
    let now = crate::time::now();
    json!({
        "post_id": p.post_id,
        "thread_id": p.thread_id,
        "user_id": p.user_id,
        "username": p.username,
        "post_date": p.post_date,
        "post_date_human": str::date_dynamic(p.post_date, now),
        "message": p.message,
        "html": html,
        "position": p.position,
        "edit_count": p.edit_count,
        "is_edited": p.is_edited(),
        "last_edit_date": p.last_edit_date,
        "last_edit_date_human": str::date_dynamic(p.last_edit_date, now),
        "is_first_post": p.is_first_post(thread_first_post_id),
        "can_edit": p.user_id == viewer_id && p.message_state == "visible",
    })
}

/// Serialise a user for templates.
pub fn user_json(u: &User) -> Value {
    let now = crate::time::now();
    json!({
        "user_id": u.user_id,
        "username": u.username,
        "email": u.email,
        "message_count": u.message_count,
        "reaction_score": u.reaction_score,
        "custom_title": u.custom_title,
        "register_date": u.register_date,
        "register_date_human": str::date_absolute(u.register_date),
        "last_activity": u.last_activity,
        "last_activity_human": str::date_dynamic(u.last_activity, now),
        "is_admin": u.is_admin(),
        "is_staff": u.is_staff,
    })
}
