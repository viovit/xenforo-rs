//! Public controllers — translations of `src/XF/Pub/Controller/*`.
//!
//! Each controller implements [`crate::mvc::Controller`] and dispatches on the
//! `action` string produced by the router (e.g. `"Forum"`, `"AddReply"`).
pub mod controllers;
pub mod helpers;

pub use controllers::*;
