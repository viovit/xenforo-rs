//! BBCode parser — produces an AST of [`Node`]s.
//!
//! This mirrors `XF\BbCode\Parser` / `Traverser`: text is split into tag and
//! text tokens, open/close tags are matched into a tree, and unmatched tags
//! degrade gracefully to literal text (XF behaviour).

/// A parsed AST node.
#[derive(Debug, Clone)]
pub enum Node {
    /// Plain text.
    Text(String),
    /// A BBCode tag with optional option and child nodes.
    Tag {
        name: String,
        option: Option<String>,
        children: Vec<Node>,
    },
}

/// The parser.
pub struct Parser;

impl Parser {
    /// Parse `input` into a list of top-level nodes.
    pub fn parse(input: &str) -> Vec<Node> {
        let chars: Vec<char> = input.chars().collect();
        let mut pos = 0;
        parse_nodes(&chars, &mut pos, None)
    }
}

/// Parse nodes until we hit a close tag matching `expected` (or end of input).
fn parse_nodes(chars: &[char], pos: &mut usize, expected: Option<&str>) -> Vec<Node> {
    let mut nodes = Vec::new();
    let mut text = String::new();

    while *pos < chars.len() {
        let c = chars[*pos];
        if c == '[' {
            // Try to read a close tag [/name]
            if let Some((name, end)) = try_close(chars, *pos) {
                // Flush pending text.
                flush_text(&mut nodes, &mut text);
                if let Some(exp) = expected {
                    if name == exp {
                        // Matching close — consume and return.
                        *pos = end;
                        return nodes;
                    }
                }
                // Unmatched close — flush pending text, then emit the literal
                // `[/name]` as its own text node (so it survives verbatim).
                flush_text(&mut nodes, &mut text);
                let lit: String = chars[*pos..end].iter().collect();
                nodes.push(Node::Text(lit));
                *pos = end;
                continue;
            }
            // Try to read an open tag [name] or [name=option]
            if let Some((name, option, end)) = try_open(chars, *pos) {
                flush_text(&mut nodes, &mut text);
                *pos = end;
                if name == "*" {
                    // List-item markers are void (no [/list-item] close);
                    // emit them as siblings, exactly like XF.
                    nodes.push(Node::Tag {
                        name,
                        option,
                        children: Vec::new(),
                    });
                    continue;
                }
                // Recurse to collect children until matching close.
                let children = parse_nodes(chars, pos, Some(&name));
                nodes.push(Node::Tag {
                    name,
                    option,
                    children,
                });
                continue;
            }
            // Not a tag — literal '['.
            text.push('[');
            *pos += 1;
        } else {
            text.push(c);
            *pos += 1;
        }
    }
    flush_text(&mut nodes, &mut text);
    nodes
}

fn flush_text(nodes: &mut Vec<Node>, text: &mut String) {
    if !text.is_empty() {
        nodes.push(Node::Text(std::mem::take(text)));
    }
}

/// Attempt to read `[/name]` starting at `start`. Returns `(name, end_index)`.
fn try_close(chars: &[char], start: usize) -> Option<(String, usize)> {
    if chars.get(start) != Some(&'[') || chars.get(start + 1) != Some(&'/') {
        return None;
    }
    let mut i = start + 2;
    let mut name = String::new();
    while i < chars.len() {
        let c = chars[i];
        if c == ']' {
            if name.is_empty() {
                return None;
            }
            if !is_valid_tag_name(&name) {
                return None;
            }
            return Some((name.to_ascii_lowercase(), i + 1));
        }
        name.push(c);
        i += 1;
    }
    None
}

/// Attempt to read `[name]` or `[name=option]`. Returns `(name, option, end)`.
fn try_open(chars: &[char], start: usize) -> Option<(String, Option<String>, usize)> {
    if chars.get(start) != Some(&'[') {
        return None;
    }
    let mut i = start + 1;
    let mut name = String::new();
    while i < chars.len() {
        let c = chars[i];
        if c == ']' {
            if name.is_empty() || !is_valid_tag_name(&name) {
                return None;
            }
            return Some((name.to_ascii_lowercase(), None, i + 1));
        }
        if c == '=' {
            if name.is_empty() || !is_valid_tag_name(&name) {
                return None;
            }
            // Read the option up to ']'.
            let mut opt = String::new();
            i += 1;
            while i < chars.len() && chars[i] != ']' {
                opt.push(chars[i]);
                i += 1;
            }
            if i >= chars.len() {
                return None;
            }
            let opt = opt.trim().to_string();
            let opt = if opt.is_empty() { None } else { Some(opt) };
            return Some((name.to_ascii_lowercase(), opt, i + 1));
        }
        name.push(c);
        i += 1;
    }
    None
}

fn is_valid_tag_name(s: &str) -> bool {
    !s.is_empty() && s.chars().all(|c| c.is_ascii_alphanumeric() || c == '*' || c == '-')
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_simple() {
        let nodes = Parser::parse("[b]hello[/b]");
        assert_eq!(nodes.len(), 1);
        match &nodes[0] {
            Node::Tag { name, option, children } => {
                assert_eq!(name, "b");
                assert!(option.is_none());
                assert_eq!(children.len(), 1);
            }
            _ => panic!(),
        }
    }

    #[test]
    fn parses_with_option() {
        let nodes = Parser::parse("[url=https://x.com]click[/url]");
        match &nodes[0] {
            Node::Tag { name, option, .. } => {
                assert_eq!(name, "url");
                assert_eq!(option.as_deref(), Some("https://x.com"));
            }
            _ => panic!(),
        }
    }

    #[test]
    fn unmatched_close_is_text() {
        let nodes = Parser::parse("a [/b] b");
        assert_eq!(nodes.len(), 3);
    }

    #[test]
    fn nested() {
        let nodes = Parser::parse("[b][i]x[/i][/b]");
        match &nodes[0] {
            Node::Tag { name, children, .. } => {
                assert_eq!(name, "b");
                assert_eq!(children.len(), 1);
            }
            _ => panic!(),
        }
    }
}
