//! HTML renderer — a translation of `XF\BbCode\Renderer\Html`.
use super::parser::Node;
use super::ruleset::RuleSet;
use crate::error::Result;
use crate::str;
use once_cell::sync::Lazy;
use regex::Regex;

static URL_RE: Lazy<Regex> =
    Lazy::new(|| Regex::new(r#"(?i)\bhttps?://[^\s<>\[\]"']+"#).unwrap());

/// The HTML renderer.
pub struct HtmlRenderer;

impl HtmlRenderer {
    pub fn new() -> Self {
        Self
    }

    /// Render a slice of nodes to HTML.
    pub fn render(&self, nodes: &[Node], rs: &RuleSet) -> Result<String> {
        let mut out = String::new();
        self.render_nodes(nodes, rs, &mut out, false, &[])?;
        Ok(out)
    }

    fn render_nodes(
        &self,
        nodes: &[Node],
        rs: &RuleSet,
        out: &mut String,
        stop_auto_link: bool,
        parent_stack: &[&str],
    ) -> Result<()> {
        for node in nodes {
            match node {
                Node::Text(t) => {
                    if stop_auto_link {
                        out.push_str(&str::html_escape(t));
                    } else {
                        out.push_str(&auto_link(t));
                    }
                }
                Node::Tag {
                    name,
                    option,
                    children,
                } => {
                    let rule = match rs.validate(name, option.as_deref(), parent_stack) {
                        Some(r) => r,
                        None => {
                            // Unknown / invalid tag — render its children as text.
                            let mut inner = String::new();
                            collect_text(children, &mut inner);
                            out.push_str(&str::html_escape(&inner));
                            continue;
                        }
                    };
                    let mut new_stack: Vec<&str> = parent_stack.to_vec();
                    new_stack.push(name);
                    self.render_tag(name, option.as_deref(), children, rule, rs, out, &new_stack)?;
                }
            }
        }
        Ok(())
    }

    #[allow(clippy::too_many_arguments)]
    fn render_tag(
        &self,
        name: &str,
        option: Option<&str>,
        children: &[Node],
        rule: &super::ruleset::TagRule,
        rs: &RuleSet,
        out: &mut String,
        parent_stack: &[&str],
    ) -> Result<()> {
        // For "plain" tags the children are raw text (escaped).
        if rule.plain {
            let mut inner = String::new();
            collect_text(children, &mut inner);
            let escaped = str::html_escape(&inner);
            return Ok(match name {
                "img" => {
                    let alt = escaped.clone();
                    out.push_str(&format!(
                        "<img src=\"{escaped}\" alt=\"{alt}\" class=\"bbImage\" loading=\"lazy\">"
                    ));
                }
                "code" | "icode" => {
                    if name == "icode" {
                        out.push_str(&format!("<code class=\"bbCodeInline\">{escaped}</code>"));
                    } else {
                        out.push_str(&format!(
                            "<pre class=\"bbCodeCode\"><code>{escaped}</code></pre>"
                        ));
                    }
                }
                "php" => {
                    out.push_str(&format!(
                        "<pre class=\"bbCodeCode phpCode\"><code>{escaped}</code></pre>"
                    ));
                }
                "html" => {
                    out.push_str(&format!(
                        "<pre class=\"bbCodeCode htmlCode\"><code>{escaped}</code></pre>"
                    ));
                }
                "plain" => out.push_str(&escaped),
                "media" => {
                    // Without the media-site table we render a link to the raw URL.
                    out.push_str(&format!(
                        "<a href=\"{escaped}\" rel=\"nofollow noopener\" target=\"_blank\">{escaped}</a>"
                    ));
                }
                "attach" => {
                    out.push_str(&format!("<span class=\"bbAttach\" data-id=\"{escaped}\">[attachment={escaped}]</span>"));
                }
                "user" => {
                    let id = option.unwrap_or("0");
                    out.push_str(&format!(
                        "<a href=\"/members/{id}\" class=\"username\">{escaped}</a>"
                    ));
                }
                _ => out.push_str(&escaped),
            });
        }

        // Non-plain: render children into a buffer, then wrap.
        let mut inner = String::new();
        self.render_nodes(children, rs, &mut inner, rule.stop_auto_link, parent_stack)?;

        match name {
            "b" => out.push_str(&format!("<b>{inner}</b>")),
            "i" => out.push_str(&format!("<i>{inner}</i>")),
            "u" => out.push_str(&format!("<u>{inner}</u>")),
            "s" => out.push_str(&format!("<s>{inner}</s>")),
            "color" => {
                let v = option.unwrap_or("");
                out.push_str(&format!("<span style=\"color:{v}\">{inner}</span>"));
            }
            "font" => {
                let v = option.unwrap_or("");
                out.push_str(&format!("<span style=\"font-family:{v}\">{inner}</span>"));
            }
            "size" => {
                let v = option.unwrap_or("");
                let v = if v.chars().all(|c| c.is_ascii_digit()) && !v.is_empty() {
                    format!("{v}px")
                } else {
                    v.to_string()
                };
                out.push_str(&format!("<span style=\"font-size:{v}\">{inner}</span>"));
            }
            "url" => {
                let href = option.unwrap_or(&inner).to_string();
                let href = sanitize_url(&href);
                out.push_str(&format!(
                    "<a href=\"{href}\" target=\"_blank\" rel=\"nofollow noopener\">{inner}</a>"
                ));
            }
            "email" => {
                let href = option.unwrap_or(&inner).to_string();
                out.push_str(&format!("<a href=\"mailto:{href}\">{inner}</a>"));
            }
            "embed" => {
                out.push_str(&format!("<div class=\"bbEmbed\">{inner}</div>"));
            }
            "left" => out.push_str(&format!("<div style=\"text-align:left\">{inner}</div>")),
            "center" => out.push_str(&format!("<div style=\"text-align:center\">{inner}</div>")),
            "right" => out.push_str(&format!("<div style=\"text-align:right\">{inner}</div>")),
            "justify" => out.push_str(&format!("<div style=\"text-align:justify\">{inner}</div>")),
            "indent" => {
                let n = option.unwrap_or("1");
                out.push_str(&format!("<div style=\"margin-left:{n}em\">{inner}</div>"));
            }
            "heading" => {
                let lvl = option.and_then(|o| o.parse::<u8>().ok()).unwrap_or(2);
                let lvl = lvl.clamp(1, 6);
                out.push_str(&format!("<h{lvl}>{inner}</h{lvl}>"));
            }
            "hr" => out.push_str("<hr>"),
            "quote" => {
                let by = option
                    .and_then(|o| o.split(',').next())
                    .unwrap_or("");
                if by.is_empty() {
                    out.push_str(&format!(
                        "<blockquote class=\"bbCodeBlock bbCodeBlock--quote\"><div class=\"bbCodeBlock-content\">{inner}</div></blockquote>"
                    ));
                } else {
                    out.push_str(&format!(
                        "<blockquote class=\"bbCodeBlock bbCodeBlock--quote\"><div class=\"bbCodeBlock-title\">{by} wrote:</div><div class=\"bbCodeBlock-content\">{inner}</div></blockquote>"
                    ));
                }
            }
            "spoiler" => out.push_str(&format!(
                "<details class=\"bbCodeSpoiler\"><summary>Spoiler</summary><div class=\"bbCodeSpoiler-content\">{inner}</div></details>"
            )),
            "ispoiler" => out.push_str(&format!("<span class=\"bbCodeIspoiler\">{inner}</span>")),
            "list" => {
                // Detect ordered vs unordered via option.
                let tag = if option.is_some() { "ol" } else { "ul" };
                // Convert [*] markers into <li>.
                let converted = render_list(children, rs, parent_stack)?;
                out.push_str(&format!("<{tag} class=\"bbCodeList\">{converted}</{tag}>"));
            }
            "table" => {
                out.push_str(&format!("<table class=\"bbCodeTable\">{inner}</table>"));
            }
            "tr" => out.push_str(&format!("<tr>{inner}</tr>")),
            "th" => out.push_str(&format!("<th>{inner}</th>")),
            "td" => out.push_str(&format!("<td>{inner}</td>")),
            _ => out.push_str(&inner),
        }
        Ok(())
    }
}

/// Render a `[list]`'s children: `[*] item` markers become `<li>`.
/// Render a `[list]`'s children. Each `[*]` marker starts a new item; the
/// nodes following it (until the next `[*]`) become that item's content.
fn render_list(children: &[Node], rs: &RuleSet, parent_stack: &[&str]) -> Result<String> {
    let mut out = String::new();
    let mut current: Vec<Node> = Vec::new();
    let renderer = HtmlRenderer;
    for child in children {
        match child {
            Node::Tag { name, .. } if name == "*" => {
                render_list_item(&renderer, rs, parent_stack, &current, &mut out)?;
                current.clear();
            }
            other => current.push(other.clone()),
        }
    }
    render_list_item(&renderer, rs, parent_stack, &current, &mut out)?;
    Ok(out)
}

/// Render one accumulated item as `<li>…</li>` (skipping empty items).
fn render_list_item(
    renderer: &HtmlRenderer,
    rs: &RuleSet,
    parent_stack: &[&str],
    nodes: &[Node],
    out: &mut String,
) -> Result<()> {
    if nodes.is_empty() {
        return Ok(());
    }
    let mut inner = String::new();
    renderer.render_nodes(nodes, rs, &mut inner, false, parent_stack)?;
    let trimmed = inner.trim();
    if !trimmed.is_empty() {
        out.push_str(&format!("<li>{trimmed}</li>"));
    }
    Ok(())
}

/// Flatten a node slice to its raw text (used for plain tags).
fn collect_text(nodes: &[Node], out: &mut String) {
    for n in nodes {
        match n {
            Node::Text(t) => out.push_str(t),
            Node::Tag { children, .. } => collect_text(children, out),
        }
    }
}

/// Auto-link bare URLs in text, escaping everything else.
fn auto_link(input: &str) -> String {
    let mut out = String::with_capacity(input.len());
    let mut last = 0;
    for m in URL_RE.find_iter(input) {
        out.push_str(&str::html_escape(&input[last..m.start()]));
        let url = m.as_str();
        out.push_str(&format!(
            "<a href=\"{}\" target=\"_blank\" rel=\"nofollow noopener\">{}</a>",
            sanitize_url(url),
            str::html_escape(url)
        ));
        last = m.end();
    }
    out.push_str(&str::html_escape(&input[last..]));
    out
}

/// Only allow http/https/ftp URLs through (XF `allowedUrlProtocolRegex`).
fn sanitize_url(url: &str) -> String {
    if url.starts_with("http://")
        || url.starts_with("https://")
        || url.starts_with("ftp://")
        || url.starts_with("mailto:")
    {
        str::html_escape(url)
    } else if url.starts_with('/') || url.starts_with('#') {
        str::html_escape(url)
    } else {
        // Disallow javascript: etc.
        str::html_escape(&format!("https://{url}"))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn render(bb: &str) -> String {
        let nodes = super::super::Parser::parse(bb);
        let rs = RuleSet::default_tags();
        HtmlRenderer::new().render(&nodes, &rs).unwrap()
    }

    #[test]
    fn basic_formatting() {
        assert_eq!(render("[b]hi[/b]"), "<b>hi</b>");
        assert_eq!(render("[i]hi[/i]"), "<i>hi</i>");
        assert_eq!(render("[u]hi[/u]"), "<u>hi</u>");
        assert_eq!(render("[s]hi[/s]"), "<s>hi</s>");
    }

    #[test]
    fn color_size_font() {
        assert_eq!(render("[color=red]x[/color]"), "<span style=\"color:red\">x</span>");
        assert_eq!(render("[size=12]x[/size]"), "<span style=\"font-size:12px\">x</span>");
        assert_eq!(render("[font=Arial]x[/font]"), "<span style=\"font-family:Arial\">x</span>");
    }

    #[test]
    fn url_with_option() {
        let html = render("[url=https://example.com]click[/url]");
        assert!(html.contains("href=\"https://example.com\""));
        assert!(html.contains(">click<"));
    }

    #[test]
    fn url_without_option() {
        let html = render("[url]https://example.com[/url]");
        assert!(html.contains("href=\"https://example.com\""));
    }

    #[test]
    fn code_escapes() {
        let html = render("[code]<b>raw</b>[/code]");
        assert!(html.contains("&lt;b&gt;"));
        assert!(html.contains("<pre"));
    }

    #[test]
    fn quote() {
        let html = render("[quote]hello[/quote]");
        assert!(html.contains("<blockquote"));
        assert!(html.contains("hello"));
    }

    #[test]
    fn img() {
        let html = render("[img]https://example.com/x.png[/img]");
        assert!(html.contains("<img src=\"https://example.com/x.png\""));
    }

    #[test]
    fn list() {
        let html = render("[list][*]one[*]two[/list]");
        assert!(html.contains("<ul"));
        assert!(html.contains("<li>one</li>"));
        assert!(html.contains("<li>two</li>"));
    }

    #[test]
    fn auto_link() {
        let html = render("see https://example.com here");
        assert!(html.contains("<a href=\"https://example.com\""));
    }

    #[test]
    fn disallows_javascript_url() {
        let html = render("[url=javascript:alert(1)]x[/url]");
        // The javascript scheme is rewritten to https://.
        assert!(html.contains("https://javascript:alert(1)"));
        assert!(!html.contains("href=\"javascript"));
    }

    #[test]
    fn escapes_plain_text() {
        let html = render("a < b & c > d");
        assert!(html.contains("&lt;"));
        assert!(html.contains("&amp;"));
        assert!(html.contains("&gt;"));
    }
}
