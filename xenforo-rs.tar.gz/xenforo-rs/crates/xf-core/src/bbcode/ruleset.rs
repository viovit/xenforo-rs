//! BBCode rule set — a translation of `XF\BbCode\RuleSet::addDefaultTags`.
use std::collections::HashMap;

/// Whether a tag accepts an option.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum HasOption {
    None,
    Yes,
    Optional,
}

/// A tag rule.
#[derive(Debug, Clone)]
pub struct TagRule {
    pub has_option: HasOption,
    /// Regex the option must match (if any).
    pub option_match: Option<&'static str>,
    /// `plain` children — raw text, no nested rendering (XF `plain`).
    pub plain: bool,
    /// Stop auto-linking URLs inside.
    pub stop_auto_link: bool,
    /// Tags that must be the immediate parent (e.g. `tr` requires `table`).
    pub valid_parents: &'static [&'static str],
}

impl Default for TagRule {
    fn default() -> Self {
        Self {
            has_option: HasOption::Optional,
            option_match: None,
            plain: false,
            stop_auto_link: false,
            valid_parents: &[],
        }
    }
}

/// The rule set.
pub struct RuleSet {
    pub tags: HashMap<&'static str, TagRule>,
}

impl RuleSet {
    /// Build the default XF rule set (all 30+ default tags).
    pub fn default_tags() -> Self {
        let mut tags = HashMap::new();

        let mut add = |name: &'static str, rule: TagRule| {
            tags.insert(name, rule);
        };

        // Inline formatting.
        add(
            "b",
            TagRule {
                has_option: HasOption::None,
                ..Default::default()
            },
        );
        add(
            "i",
            TagRule {
                has_option: HasOption::None,
                ..Default::default()
            },
        );
        add(
            "u",
            TagRule {
                has_option: HasOption::None,
                ..Default::default()
            },
        );
        add(
            "s",
            TagRule {
                has_option: HasOption::None,
                ..Default::default()
            },
        );

        add(
            "color",
            TagRule {
                has_option: HasOption::Yes,
                option_match: Some(
                    r"(?i)^(rgb\(\s*\d+%?\s*,\s*\d+%?\s*,\s*\d+%?\s*\)|#[a-f0-9]{6}|#[a-f0-9]{3}|[a-z]+)$",
                ),
                ..Default::default()
            },
        );
        add(
            "font",
            TagRule {
                has_option: HasOption::Yes,
                option_match: Some(r"(?i)^[a-z0-9 \-]+$"),
                ..Default::default()
            },
        );
        add(
            "size",
            TagRule {
                has_option: HasOption::Yes,
                option_match: Some(r"^[0-9]+(px)?$"),
                ..Default::default()
            },
        );

        add(
            "url",
            TagRule {
                stop_auto_link: true,
                ..Default::default()
            },
        );
        add(
            "email",
            TagRule {
                stop_auto_link: true,
                ..Default::default()
            },
        );
        add(
            "embed",
            TagRule {
                stop_auto_link: true,
                ..Default::default()
            },
        );

        // Alignment.
        const ALIGN: [&'static str; 4] = ["left", "center", "right", "justify"];
        for &n in ALIGN.iter() {
            add(
                n,
                TagRule {
                    has_option: HasOption::None,
                    ..Default::default()
                },
            );
        }
        add("indent", TagRule { option_match: Some(r"^[0-9]+$"), ..Default::default() });
        add("heading", TagRule { option_match: Some(r"^[0-9]+$"), ..Default::default() });
        add(
            "hr",
            TagRule {
                has_option: HasOption::None,
                ..Default::default()
            },
        );

        add(
            "img",
            TagRule {
                plain: true,
                stop_auto_link: true,
                ..Default::default()
            },
        );
        add("quote", TagRule::default());
        add(
            "code",
            TagRule {
                plain: true,
                stop_auto_link: true,
                ..Default::default()
            },
        );
        add(
            "icode",
            TagRule {
                plain: true,
                stop_auto_link: true,
                ..Default::default()
            },
        );
        add(
            "php",
            TagRule {
                has_option: HasOption::None,
                plain: true,
                stop_auto_link: true,
                ..Default::default()
            },
        );
        add(
            "html",
            TagRule {
                has_option: HasOption::None,
                plain: true,
                stop_auto_link: true,
                ..Default::default()
            },
        );
        add("list", TagRule::default());
        add(
            "plain",
            TagRule {
                has_option: HasOption::None,
                plain: true,
                stop_auto_link: true,
                ..Default::default()
            },
        );
        add(
            "media",
            TagRule {
                has_option: HasOption::Yes,
                plain: true,
                stop_auto_link: true,
                ..Default::default()
            },
        );
        add("spoiler", TagRule::default());
        add("ispoiler", TagRule::default());
        add(
            "attach",
            TagRule {
                plain: true,
                stop_auto_link: true,
                ..Default::default()
            },
        );
        add(
            "user",
            TagRule {
                has_option: HasOption::Yes,
                plain: true,
                stop_auto_link: true,
                ..Default::default()
            },
        );
        add("table", TagRule::default());
        add(
            "tr",
            TagRule {
                valid_parents: &["table"],
                ..Default::default()
            },
        );
        add(
            "th",
            TagRule {
                valid_parents: &["tr"],
                ..Default::default()
            },
        );
        add(
            "td",
            TagRule {
                valid_parents: &["tr"],
                ..Default::default()
            },
        );

        Self { tags }
    }

    /// Validate a tag against its rule (option correctness, parent constraint).
    pub fn validate(&self, name: &str, option: Option<&str>, parent_stack: &[&str]) -> Option<&TagRule> {
        // Lookup is case-insensitive.
        let rule = self.tags.get(name)?;
        if !rule.valid_parents.is_empty() {
            let parent = parent_stack.last()?;
            if !rule.valid_parents.contains(parent) {
                return None;
            }
        }
        match rule.has_option {
            HasOption::None => {
                if option.is_some() {
                    return None;
                }
            }
            HasOption::Yes => {
                if option.is_none() {
                    return None;
                }
            }
            HasOption::Optional => {}
        }
        if let (Some(opt), Some(rx)) = (option, rule.option_match) {
            if let Ok(re) = regex::Regex::new(rx) {
                if !re.is_match(opt) {
                    return None;
                }
            }
        }
        Some(rule)
    }
}
