//! BBCode parsing & rendering — a translation of `XF\BbCode`.
//!
//! * [`parser`]   — tokenizer + AST builder (`XF\BbCode\Parser`).
//! * [`ruleset`]  — the default tag rules (`XF\BbCode\RuleSet`).
//! * [`html`]     — the `XF\BbCode\Renderer\Html` renderer.
pub mod html;
pub mod parser;
pub mod ruleset;

pub use html::HtmlRenderer;
pub use parser::{Node, Parser};
pub use ruleset::RuleSet;

use crate::error::{Error, Result};

/// Render `bbcode` to safe HTML using the default rule set and HTML renderer.
pub fn render_to_html(bbcode: &str) -> Result<String> {
    let nodes = Parser::parse(bbcode);
    let rs = RuleSet::default_tags();
    let renderer = HtmlRenderer::new();
    renderer.render(&nodes, &rs).map_err(Error::from)
}
