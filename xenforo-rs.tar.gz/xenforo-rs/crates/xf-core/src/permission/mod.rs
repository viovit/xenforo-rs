//! Permission resolution — a translation of `XF\Permission\*`.
//!
//! XenForo computes a *permission combination* per distinct set of user groups
//! a member belongs to, then looks up `xf_permission_entry` rows for that
//! combination. The port keeps the same data model:
//!
//! * each user group maps to a `xf_permission_combination` (seeded so
//!   `combination_id == group_id` for the four built-in groups);
//! * the [`PermissionSet`] loads every entry for the visitor's groups and
//!   resolves a permission with the XF precedence:
//!   `content_allow` > `content deny` > `global allow` > `global deny` > default.
use crate::entities::User;
use crate::error::Result;
use crate::Db;
use std::collections::HashMap;

/// Resolved permission value.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Value {
    Allow,
    Deny,
    /// `reset` — no explicit entry; fall back to the parent scope.
    Reset,
}

impl Value {
    fn from_db(s: &str) -> Self {
        match s {
            "allow" | "content_allow" => Value::Allow,
            "deny" => Value::Deny,
            _ => Value::Reset,
        }
    }
}

/// A loaded permission set for one visitor.
#[derive(Debug)]
pub struct PermissionSet {
    /// (content_type, content_id, group, id) -> Value
    entries: HashMap<(String, i64, String, String), Value>,
    group_ids: Vec<i64>,
}

impl PermissionSet {
    /// Build the set for `user` by loading every entry across the user's groups.
    /// A guest (user_id == 0) uses group 4.
    pub fn for_user(db: &Db, user: &User) -> Result<Self> {
        let group_ids = if user.is_guest() {
            vec![4]
        } else {
            user.group_ids()
        };
        // Each built-in group's combination_id == group_id (see migration seed).
        let combos: Vec<i64> = group_ids.clone();
        let entries = load_entries(db, &combos)?;
        Ok(Self { entries, group_ids })
    }

    /// Build an empty (guest) set without hitting the DB.
    pub fn guest() -> Self {
        Self {
            entries: HashMap::new(),
            group_ids: vec![4],
        }
    }

    pub fn group_ids(&self) -> &[i64] {
        &self.group_ids
    }

    /// Resolve a *global* permission (`content_type = "global"`, id 0).
    pub fn has_global(&self, group: &str, id: &str) -> bool {
        // Any 'allow' across the visitor's groups grants; 'deny' only matters
        // when no group allows.
        let mut any_allow = false;
        for _g in &self.group_ids {
            if let Some(v) = self.entries.get(&("global".to_string(), 0, group.to_string(), id.to_string())) {
                match v {
                    Value::Allow => any_allow = true,
                    Value::Deny => {}
                    Value::Reset => {}
                }
            }
        }
        any_allow
    }

    /// Resolve a *content* permission (e.g. node `view`, `postThread`).
    /// Content-level entries override global ones, exactly like XF.
    pub fn has_content(&self, content_type: &str, content_id: i64, group: &str, id: &str) -> bool {
        // First look for a content-scoped entry across the visitor's groups.
        let mut content_allow = false;
        let mut content_deny = false;
        for _g in &self.group_ids {
            if let Some(v) = self.entries.get(&(content_type.to_string(), content_id, group.to_string(), id.to_string())) {
                match v {
                    Value::Allow => content_allow = true,
                    Value::Deny => content_deny = true,
                    Value::Reset => {}
                }
            }
        }
        if content_allow {
            return true;
        }
        if content_deny {
            return false;
        }
        // Fall back to the global permission.
        self.has_global(group, id)
    }
}

fn load_entries(db: &Db, combination_ids: &[i64]) -> Result<HashMap<(String, i64, String, String), Value>> {
    if combination_ids.is_empty() {
        return Ok(HashMap::new());
    }
    let placeholders = combination_ids.iter().map(|_| "?").collect::<Vec<_>>().join(",");
    let sql = format!(
        "SELECT content_type, content_id, permission_group_id, permission_id, permission_value \
         FROM xf_permission_entry WHERE permission_combination_id IN ({placeholders})"
    );
    let mut out = HashMap::new();
    db.with_conn(|c| -> rusqlite::Result<()> {
        let mut stmt = c.prepare(&sql)?;
        let params_iter: Vec<&dyn rusqlite::ToSql> = combination_ids
            .iter()
            .map(|g| g as &dyn rusqlite::ToSql)
            .collect();
        let rows = stmt.query_map(params_iter.as_slice(), |r| {
            Ok((
                r.get::<_, String>(0)?,
                r.get::<_, i64>(1)?,
                r.get::<_, String>(2)?,
                r.get::<_, String>(3)?,
                r.get::<_, String>(4)?,
            ))
        })?;
        for row in rows {
            let (ct, cid, grp, id, val) = row?;
            out.insert((ct, cid, grp, id), Value::from_db(&val));
        }
        Ok(())
    })?;
    Ok(out)
}

/// Convenience permission checks used by the pub controllers.
pub mod perm {
    use super::PermissionSet;

    pub const GROUP_FORUM: &str = "forum";
    pub const GROUP_GENERAL: &str = "general";

    pub fn view(ps: &PermissionSet) -> bool {
        ps.has_global(GROUP_GENERAL, "view")
    }
    pub fn view_forum(ps: &PermissionSet, node_id: i64) -> bool {
        ps.has_content("node", node_id, GROUP_FORUM, "view")
    }
    pub fn view_content(ps: &PermissionSet, node_id: i64) -> bool {
        ps.has_content("node", node_id, GROUP_FORUM, "viewContent")
    }
    pub fn post_thread(ps: &PermissionSet, node_id: i64) -> bool {
        ps.has_content("node", node_id, GROUP_FORUM, "postThread")
    }
    pub fn reply(ps: &PermissionSet, node_id: i64) -> bool {
        ps.has_content("node", node_id, GROUP_FORUM, "reply")
    }
    pub fn edit_own_post(ps: &PermissionSet, node_id: i64) -> bool {
        ps.has_content("node", node_id, GROUP_FORUM, "editOwnPost")
    }
    pub fn delete_own_post(ps: &PermissionSet, node_id: i64) -> bool {
        ps.has_content("node", node_id, GROUP_FORUM, "deleteOwnPost")
    }
}

/// Grant a content permission for a combination (used by the installer / admin).
pub fn grant_content(
    db: &Db,
    combination_id: i64,
    content_type: &str,
    content_id: i64,
    group: &str,
    id: &str,
    value: &str,
) -> crate::error::Result<()> {
    db.execute(
        "INSERT OR REPLACE INTO xf_permission_entry \
         (permission_combination_id, content_type, content_id, permission_group_id, permission_id, permission_value, permission_value_int) \
         VALUES (?, ?, ?, ?, ?, ?, 0)",
        &[
            &combination_id as &dyn rusqlite::ToSql,
            &content_type,
            &content_id,
            &group,
            &id,
            &value,
        ],
    )?;
    Ok(())
}
