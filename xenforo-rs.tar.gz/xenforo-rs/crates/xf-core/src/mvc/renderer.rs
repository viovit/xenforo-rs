//! `XF\Mvc\Renderer\*` — turn a [`Reply`] into an HTTP [`Response`].
use super::{Reply, Request};
use crate::app::App;
use serde_json::{json, Value};

/// A rendered HTTP response.
#[derive(Debug, Clone)]
pub struct Response {
    pub status: u16,
    pub headers: Vec<(String, String)>,
    pub body: Vec<u8>,
}

impl Response {
    pub fn new(status: u16, body: impl Into<Vec<u8>>, content_type: &str) -> Self {
        Self {
            status,
            headers: vec![("content-type".into(), content_type.into())],
            body: body.into(),
        }
    }
    pub fn header(mut self, k: impl Into<String>, v: impl Into<String>) -> Self {
        self.headers.push((k.into(), v.into()));
        self
    }
}

/// The renderer.
pub struct Renderer;

impl Renderer {
    /// Render `reply` into a [`Response`], given the request and app context.
    pub fn render(reply: Reply, req: &Request, app: &App) -> Response {
        match reply {
            Reply::View { template, context } => {
                if req.wants_json() {
                    return Response::new(
                        200,
                        serde_json::to_vec(&json!({ "template": template, "context": context }))
                            .unwrap_or_default(),
                        "application/json",
                    );
                }
                match app.render_template(&template, context, req) {
                    Ok(html) => Response::new(200, html.into_bytes(), "text/html; charset=utf-8"),
                    Err(e) => {
                        tracing::error!(error = %e, template, "template render failed");
                        error_response(500, "Internal template error", app, req)
                    }
                }
            }
            Reply::Redirect { url, permanent } => {
                let status = if permanent { 301 } else { 302 };
                Response::new(status, Vec::new(), "text/html; charset=utf-8")
                    .header("location", url.clone())
                    .header("x-redirect", url)
            }
            Reply::RedirectBack => {
                let url = req
                    .header("referer")
                    .map(|s| s.to_string())
                    .unwrap_or_else(|| "/".into());
                Response::new(302, Vec::new(), "text/html; charset=utf-8").header("location", url)
            }
            Reply::Error { status, message } => error_response(status, &message, app, req),
            Reply::Message { message, redirect } => {
                let ctx = json!({
                    "message": message,
                    "redirect": redirect,
                });
                match app.render_template("message", ctx, req) {
                    Ok(html) => Response::new(200, html.into_bytes(), "text/html; charset=utf-8"),
                    Err(_) => Response::new(200, message.into_bytes(), "text/plain; charset=utf-8"),
                }
            }
            Reply::Json(v) => Response::new(
                200,
                serde_json::to_vec(&v).unwrap_or_default(),
                "application/json",
            ),
            Reply::Raw { body, content_type, status } => {
                Response::new(status, body.into_bytes(), &content_type)
            }
        }
    }
}

fn error_response(status: u16, message: &str, app: &App, req: &Request) -> Response {
    let ctx: Value = json!({
        "status": status,
        "message": message,
    });
    match app.render_template("error", ctx, req) {
        Ok(html) => Response::new(status, html.into_bytes(), "text/html; charset=utf-8"),
        Err(_) => Response::new(status, message.as_bytes().to_vec(), "text/plain; charset=utf-8"),
    }
}
