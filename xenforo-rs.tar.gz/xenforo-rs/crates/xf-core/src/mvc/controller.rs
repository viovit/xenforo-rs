//! `XF\Mvc\Controller` trait + the [`ControllerKind`] registry.
//!
//! XF maps a route to `(controller_class, action)` and the dispatcher
//! instantiates the controller. Here a [`ControllerKind`] enum replaces the
//! PHP class string; each variant maps to a controller struct implementing
//! [`Controller`].
use super::{ParamBag, Reply};
use crate::app::App;
use crate::mvc::Request;

/// Identifies a controller, mirroring the `XF:Forum` / `XF:Thread` short names.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ControllerKind {
    Index,
    Forum,
    Thread,
    Post,
    Member,
    Login,
    Logout,
    Register,
    Account,
    Online,
    Search,
    Admin,
}

impl ControllerKind {
    /// Instantiate the controller for this kind.
    pub fn make(self) -> Box<dyn Controller> {
        use crate::pubc::controllers::*;
        match self {
            ControllerKind::Index => Box::new(IndexController),
            ControllerKind::Forum => Box::new(ForumController),
            ControllerKind::Thread => Box::new(ThreadController),
            ControllerKind::Post => Box::new(PostController),
            ControllerKind::Member => Box::new(MemberController),
            ControllerKind::Login => Box::new(LoginController),
            ControllerKind::Logout => Box::new(LogoutController),
            ControllerKind::Register => Box::new(RegisterController),
            ControllerKind::Account => Box::new(AccountController),
            ControllerKind::Online => Box::new(OnlineController),
            ControllerKind::Search => Box::new(SearchController),
            ControllerKind::Admin => Box::new(AdminController),
        }
    }
}

/// The controller trait. `handle` dispatches on `action` (e.g. `"Forum"`,
/// `"AddReply"`), mirroring `XF\Mvc\Controller::actionXyz`.
pub trait Controller: Send + Sync {
    fn handle(
        &self,
        action: &str,
        params: &ParamBag,
        req: &mut Request,
        app: &App,
    ) -> Reply;

    /// Pre-render hook (mirrors `preDispatch` / `assertViewableUser`).
    fn pre_dispatch(&self, _action: &str, _params: &ParamBag, _req: &mut Request, _app: &App) {}
}

// Note: the public-controller module is named `pubc` (because `pub` is a Rust
// keyword); it mirrors `XF\Pub\Controller`.
