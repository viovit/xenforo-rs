//! `XF\Mvc\Reply\*` — controller reply types.
use serde_json::{json, Value};

/// What a controller returns, mirroring `XF\Mvc\Reply\View` / `Redirect` /
/// `Error` / `Message` / `Reroute` and the JSON API reply.
#[derive(Debug, Clone)]
pub enum Reply {
    /// Render a template with a context map.
    View {
        template: String,
        context: Value,
    },
    /// HTTP redirect (302 by default).
    Redirect {
        url: String,
        permanent: bool,
    },
    /// A redirect back to the HTTP referer (XF `Reply::Redirect` with empty url).
    RedirectBack,
    /// An error page.
    Error {
        status: u16,
        message: String,
    },
    /// A plain message page (XF `Reply\Message`).
    Message {
        message: String,
        redirect: Option<String>,
    },
    /// JSON response (API / `_xfResponseType=json`).
    Json(Value),
    /// Raw body with an explicit content type.
    Raw {
        body: String,
        content_type: String,
        status: u16,
    },
}

impl Reply {
    pub fn view(template: impl Into<String>, context: Value) -> Self {
        Reply::View {
            template: template.into(),
            context,
        }
    }

    pub fn redirect(url: impl Into<String>) -> Self {
        Reply::Redirect {
            url: url.into(),
            permanent: false,
        }
    }

    pub fn error(status: u16, message: impl Into<String>) -> Self {
        Reply::Error {
            status,
            message: message.into(),
        }
    }

    pub fn message(message: impl Into<String>) -> Self {
        Reply::Message {
            message: message.into(),
            redirect: None,
        }
    }

    pub fn not_found(msg: impl Into<String>) -> Self {
        Self::error(404, msg)
    }

    pub fn no_permission() -> Self {
        Self::error(403, "You do not have permission to view this page or perform this action.")
    }

    pub fn json(value: Value) -> Self {
        Reply::Json(value)
    }

    pub fn ok() -> Self {
        Reply::Json(json!({ "status": "ok" }))
    }
}
