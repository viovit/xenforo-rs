//! `XF\Mvc\ParameterBag` — named route parameters.
use std::collections::HashMap;

#[derive(Debug, Clone, Default)]
pub struct ParamBag {
    pub params: HashMap<String, String>,
}

impl ParamBag {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn insert(&mut self, k: impl Into<String>, v: impl Into<String>) {
        self.params.insert(k.into(), v.into());
    }

    pub fn get(&self, k: &str) -> Option<&str> {
        self.params.get(k).map(|s| s.as_str())
    }

    /// Parse a param as `i64`, defaulting to `def`.
    pub fn int(&self, k: &str, def: i64) -> i64 {
        self.params
            .get(k)
            .and_then(|s| s.parse::<i64>().ok())
            .unwrap_or(def)
    }
}
