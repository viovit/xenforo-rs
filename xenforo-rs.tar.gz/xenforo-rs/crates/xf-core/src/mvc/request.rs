//! `XF\Http\Request` — the incoming HTTP request, simplified.
use std::collections::HashMap;
use std::sync::Arc;

use crate::app::Visitor;

/// HTTP method.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum Method {
    #[default]
    Get,
    Post,
    Put,
    Delete,
    Other,
}

impl Method {
    pub fn from_str(s: &str) -> Self {
        match s.to_ascii_uppercase().as_str() {
            "GET" => Method::Get,
            "POST" => Method::Post,
            "PUT" => Method::Put,
            "DELETE" => Method::Delete,
            _ => Method::Other,
        }
    }
    pub fn is_post(&self) -> bool {
        matches!(self, Method::Post)
    }
}

/// The request. Built by the HTTP front controller and passed to the dispatcher.
#[derive(Debug, Clone, Default)]
pub struct Request {
    pub method: Method,
    /// Path without query string, no leading slash.
    pub path: String,
    /// Query parameters (`?key=value`).
    pub query: HashMap<String, String>,
    /// Parsed form body (POST `application/x-www-form-urlencoded`).
    pub form: HashMap<String, String>,
    /// Request headers, lowercased keys.
    pub headers: HashMap<String, String>,
    /// Cookies, keyed by name (without the board prefix).
    pub cookies: HashMap<String, String>,
    /// Peer IP.
    pub remote_ip: String,
    /// The response type hint (e.g. `html`, `json`) — mirrors XF `_xfResponseType`.
    pub response_type: String,
    /// Resolved visitor (set by `App::handle` before dispatch).
    pub visitor: Option<Arc<Visitor>>,
}

impl Request {
    /// Read a query or form param (form wins on POST), like XF `$request->filter`.
    pub fn input(&self, key: &str) -> Option<&str> {
        if let Some(v) = self.form.get(key) {
            return Some(v);
        }
        self.query.get(key).map(|s| s.as_str())
    }

    pub fn input_or<'a>(&'a self, key: &str, def: &'a str) -> &'a str {
        self.input(key).unwrap_or(def)
    }

    pub fn input_int(&self, key: &str, def: i64) -> i64 {
        self.input(key)
            .and_then(|s| s.parse::<i64>().ok())
            .unwrap_or(def)
    }

    pub fn cookie(&self, name: &str) -> Option<&str> {
        self.cookies.get(name).map(|s| s.as_str())
    }

    pub fn header(&self, name: &str) -> Option<&str> {
        self.headers.get(&name.to_ascii_lowercase()).map(|s| s.as_str())
    }

    pub fn wants_json(&self) -> bool {
        self.response_type == "json"
            || self
                .header("accept")
                .map(|a| a.contains("application/json"))
                .unwrap_or(false)
    }
}
