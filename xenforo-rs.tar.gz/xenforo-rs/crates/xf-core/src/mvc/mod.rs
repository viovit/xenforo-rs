//! Model-View-Controller — a translation of `XF\Mvc`.
//!
//! * [`Request`]    — `XF\Http\Request` (method, path, query, form, cookies).
//! * [`ParamBag`]   — `XF\Mvc\ParameterBag` (route params).
//! * [`Router`]     — `XF\Mvc\Router` (prefix + format → controller/action).
//! * [`Controller`] — `XF\Mvc\Controller` trait.
//! * [`Reply`]      — `XF\Mvc\Reply\*` (View / Redirect / Error / Json / Raw).
//! * [`Dispatcher`] — `XF\Mvc\Dispatcher` (route → controller → reply).
//! * [`Renderer`]   — `XF\Mvc\Renderer\*` (reply → [`Response`]).
pub mod controller;
pub mod dispatcher;
pub mod param_bag;
pub mod reply;
pub mod renderer;
pub mod request;
pub mod router;

pub use controller::{Controller, ControllerKind};
pub use dispatcher::Dispatcher;
pub use param_bag::ParamBag;
pub use reply::Reply;
pub use renderer::{Renderer, Response};
pub use request::{Method, Request};
pub use router::{Route, RouteMatch, Router};
