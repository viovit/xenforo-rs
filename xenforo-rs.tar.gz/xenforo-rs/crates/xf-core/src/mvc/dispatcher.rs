//! `XF\Mvc\Dispatcher` — route → controller → reply.
use super::{Reply, Request, Router};
use crate::app::App;
use crate::mvc::{ControllerKind, ParamBag};

pub struct Dispatcher;

impl Dispatcher {
    /// Resolve the route and invoke the controller, returning a [`Reply`].
    pub fn dispatch(req: &mut Request, app: &App) -> Reply {
        let path = req.path.trim_start_matches('/');
        let Some(matched) = Router::route(path) else {
            return Reply::not_found("The requested page could not be found.");
        };
        Self::dispatch_match(matched.controller, &matched.action, &matched.params, req, app)
    }

    /// Dispatch an already-resolved route (used by tests and reroutes).
    pub fn dispatch_match(
        kind: ControllerKind,
        action: &str,
        params: &ParamBag,
        req: &mut Request,
        app: &App,
    ) -> Reply {
        let controller = kind.make();
        controller.pre_dispatch(action, params, req, app);
        let reply = controller.handle(action, params, req, app);
        // Record session activity, mirroring `XF\Pub\Controller::postDispatch`.
        app.record_session_activity(kind, action, req);
        reply
    }
}
