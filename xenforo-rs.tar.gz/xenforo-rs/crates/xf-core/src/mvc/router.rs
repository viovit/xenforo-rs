//! `XF\Mvc\Router` — prefix + format string → controller/action.
//!
//! Mirrors XF's `routeToController`: the path is split into a prefix (first
//! segment) and a suffix; each registered route under the prefix tries to
//! regex-match its `format` against the suffix, capturing named params.
use super::{ControllerKind, ParamBag};
use once_cell::sync::Lazy;
use regex::Regex;

/// One registered route.
#[derive(Clone)]
pub struct Route {
    pub prefix: &'static str,
    /// Regex matched against the suffix (after `prefix/`).
    pub regex: &'static str,
    /// Param names in capture-group order.
    pub param_names: &'static [&'static str],
    pub controller: ControllerKind,
    pub action: &'static str,
}

/// A matched route.
pub struct RouteMatch {
    pub controller: ControllerKind,
    pub action: String,
    pub params: ParamBag,
}

/// The router holds the static route table (mirrors the `xf_route` seed).
pub struct Router;

static ROUTES: Lazy<Vec<Route>> = Lazy::new(|| {
    use ControllerKind::*;
    vec![
        // Board index.
        Route {
            prefix: "",
            regex: r"^$",
            param_names: &[],
            controller: Index,
            action: "Index",
        },
        // Forums — specific actions before the catch-all forum view.
        Route {
            prefix: "forums",
            regex: r"^(\d+)/post-thread/?$",
            param_names: &["node_id"],
            controller: Forum,
            action: "PostThread",
        },
        Route {
            prefix: "forums",
            regex: r"^-/mark-read(?:/(\d+))?/?$",
            param_names: &["node_id"],
            controller: Forum,
            action: "MarkRead",
        },
        Route {
            prefix: "forums",
            regex: r"^(\d+)(?:/[^/]+)?/?$",
            param_names: &["node_id"],
            controller: Forum,
            action: "Forum",
        },
        Route {
            prefix: "forums",
            regex: r"^$",
            param_names: &[],
            controller: Forum,
            action: "Index",
        },
        // Threads — reply / mark-read before the catch-all thread view.
        Route {
            prefix: "threads",
            regex: r"^(\d+)/add-reply/?$",
            param_names: &["thread_id"],
            controller: Thread,
            action: "AddReply",
        },
        Route {
            prefix: "threads",
            regex: r"^(\d+)/mark-read/?$",
            param_names: &["thread_id"],
            controller: Thread,
            action: "MarkRead",
        },
        Route {
            prefix: "threads",
            regex: r"^(\d+)(?:/[^/]+)?/?$",
            param_names: &["thread_id"],
            controller: Thread,
            action: "Index",
        },
        // Posts — edit / delete before the bare post redirect.
        Route {
            prefix: "posts",
            regex: r"^(\d+)/edit/?$",
            param_names: &["post_id"],
            controller: Post,
            action: "Edit",
        },
        Route {
            prefix: "posts",
            regex: r"^(\d+)/delete/?$",
            param_names: &["post_id"],
            controller: Post,
            action: "Delete",
        },
        Route {
            prefix: "posts",
            regex: r"^(\d+)/?$",
            param_names: &["post_id"],
            controller: Post,
            action: "Index",
        },
        // Members — follow before the profile view.
        Route {
            prefix: "members",
            regex: r"^(\d+)/follow/?$",
            param_names: &["user_id"],
            controller: Member,
            action: "Follow",
        },
        Route {
            prefix: "members",
            regex: r"^(\d+)/?$",
            param_names: &["user_id"],
            controller: Member,
            action: "View",
        },
        Route {
            prefix: "members",
            regex: r"^$",
            param_names: &[],
            controller: Member,
            action: "List",
        },
        // Auth.
        Route {
            prefix: "login",
            regex: r"^$",
            param_names: &[],
            controller: Login,
            action: "Index",
        },
        Route {
            prefix: "register",
            regex: r"^$",
            param_names: &[],
            controller: Register,
            action: "Index",
        },
        Route {
            prefix: "logout",
            regex: r"^$",
            param_names: &[],
            controller: Logout,
            action: "Index",
        },
        Route {
            prefix: "account",
            regex: r"^$",
            param_names: &[],
            controller: Account,
            action: "Index",
        },
        // Misc.
        Route {
            prefix: "online",
            regex: r"^$",
            param_names: &[],
            controller: Online,
            action: "Index",
        },
        Route {
            prefix: "search",
            regex: r"^$",
            param_names: &[],
            controller: Search,
            action: "Index",
        },
        // Admin scaffold.
        Route {
            prefix: "admin",
            regex: r"^.*$",
            param_names: &[],
            controller: Admin,
            action: "Index",
        },
    ]
});

impl Router {
    /// Resolve `path` (no leading slash) to a [`RouteMatch`].
    pub fn route(path: &str) -> Option<RouteMatch> {
        let path = path.trim_start_matches('/');
        if path.is_empty() {
            // Board index.
            return self::match_route("", "");
        }
        let (prefix, suffix) = match path.split_once('/') {
            Some((p, s)) => (p, s),
            None => (path, ""),
        };

        // Try every route whose prefix matches, first-wins (registration order).
        for r in ROUTES.iter() {
            if r.prefix != prefix {
                continue;
            }
            if let Some(m) = compile_and_match(r, suffix) {
                return Some(m);
            }
        }
        // No explicit match: a bare prefix with no route -> 404.
        None
    }

    /// Build a link to a thread: `/threads/{id}/{slug}`.
    pub fn thread_link(id: i64, title: &str) -> String {
        format!("/threads/{id}/{}", crate::str::slug(title))
    }

    /// Build a link to a forum: `/forums/{id}/{slug}`.
    pub fn forum_link(id: i64, title: &str) -> String {
        format!("/forums/{id}/{}", crate::str::slug(title))
    }

    /// Build a link to a member: `/members/{id}`.
    pub fn member_link(id: i64) -> String {
        format!("/members/{id}")
    }

    /// Link to a specific post (redirects via the posts controller).
    pub fn post_link(id: i64) -> String {
        format!("/posts/{id}")
    }
}

fn compile_and_match(r: &Route, suffix: &str) -> Option<RouteMatch> {
    let re = Regex::new(r.regex).ok()?;
    let caps = re.captures(suffix)?;
    let mut params = ParamBag::new();
    for (i, name) in r.param_names.iter().enumerate() {
        if let Some(m) = caps.get(i + 1) {
            params.insert(*name, m.as_str().to_string());
        }
    }
    Some(RouteMatch {
        controller: r.controller,
        action: r.action.to_string(),
        params,
    })
}

fn match_route(prefix: &str, suffix: &str) -> Option<RouteMatch> {
    for r in ROUTES.iter() {
        if r.prefix != prefix {
            continue;
        }
        if let Some(m) = compile_and_match(r, suffix) {
            return Some(m);
        }
    }
    None
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn index_route() {
        let m = Router::route("").unwrap();
        assert_eq!(m.controller, ControllerKind::Index);
        assert_eq!(m.action, "Index");
    }

    #[test]
    fn forum_view() {
        let m = Router::route("forums/2/general-discussion").unwrap();
        assert_eq!(m.controller, ControllerKind::Forum);
        assert_eq!(m.action, "Forum");
        assert_eq!(m.params.int("node_id", 0), 2);
    }

    #[test]
    fn forum_view_no_slug() {
        let m = Router::route("forums/2").unwrap();
        assert_eq!(m.params.int("node_id", 0), 2);
    }

    #[test]
    fn thread_view() {
        let m = Router::route("threads/42/hello-world").unwrap();
        assert_eq!(m.controller, ControllerKind::Thread);
        assert_eq!(m.params.int("thread_id", 0), 42);
    }

    #[test]
    fn thread_reply() {
        let m = Router::route("threads/42/add-reply").unwrap();
        assert_eq!(m.action, "AddReply");
    }

    #[test]
    fn member_view() {
        let m = Router::route("members/7").unwrap();
        assert_eq!(m.controller, ControllerKind::Member);
        assert_eq!(m.params.int("user_id", 0), 7);
    }

    #[test]
    fn login_register_logout() {
        assert_eq!(Router::route("login").unwrap().controller, ControllerKind::Login);
        assert_eq!(Router::route("register").unwrap().controller, ControllerKind::Register);
        assert_eq!(Router::route("logout").unwrap().controller, ControllerKind::Logout);
    }

    #[test]
    fn unknown_is_none() {
        assert!(Router::route("does-not-exist").is_none());
    }
}
