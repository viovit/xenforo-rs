//! Application configuration — mirrors the `src/config.php` / `xf_option` values
//! that matter at runtime (board title, board URL, DB path, registration settings).
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Config {
    /// Board title (XF option `boardTitle`).
    pub board_title: String,
    /// Absolute board URL, no trailing slash (XF option `boardUrl`).
    pub board_url: String,
    /// Path to the SQLite database file.
    pub db_path: String,
    /// Bind address for the HTTP server.
    pub listen: String,
    /// Whether public registration is open (XF option `registrationSetup.enabled`).
    pub registration_enabled: bool,
    /// Minimum length of a username (XF option `usernameLength.minimum`).
    pub min_username_length: u32,
    /// Maximum length of a username.
    pub max_username_length: u32,
    /// Minimum password length.
    pub min_password_length: u32,
    /// Posts per page in a thread (XF option `messagesPerPage`).
    pub posts_per_page: u32,
    /// Threads per page in a forum (XF option `discussionsPerPage`).
    pub threads_per_page: u32,
    /// Whether guests can view the board.
    pub guests_view: bool,
    /// Cookie prefix (XF `config.php` `$config['cookie']['prefix']`).
    pub cookie_prefix: String,
    /// Session cookie lifetime in seconds.
    pub session_lifetime: i64,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            board_title: "xenforo-rs".into(),
            board_url: "http://localhost:8080".into(),
            db_path: "xf.db".into(),
            listen: "0.0.0.0:8080".into(),
            registration_enabled: true,
            min_username_length: 3,
            max_username_length: 50,
            min_password_length: 8,
            posts_per_page: 20,
            threads_per_page: 30,
            guests_view: true,
            cookie_prefix: "xf_".into(),
            session_lifetime: 30 * 24 * 60 * 60,
        }
    }
}

impl Config {
    /// Load from a JSON file, falling back to defaults merged with env overrides.
    pub fn load(path: &std::path::Path) -> Self {
        let mut cfg = std::fs::read_to_string(path)
            .ok()
            .and_then(|s| serde_json::from_str::<Config>(&s).ok())
            .unwrap_or_default();
        // Environment overrides mirror reading $config from env in config.php.
        if let Ok(v) = std::env::var("XF_BOARD_TITLE") {
            cfg.board_title = v;
        }
        if let Ok(v) = std::env::var("XF_BOARD_URL") {
            cfg.board_url = v;
        }
        if let Ok(v) = std::env::var("XF_DB_PATH") {
            cfg.db_path = v;
        }
        if let Ok(v) = std::env::var("XF_LISTEN") {
            cfg.listen = v;
        }
        if let Ok(v) = std::env::var("XF_REGISTRATION_ENABLED") {
            let v = v.to_ascii_lowercase();
            cfg.registration_enabled = !(v == "0" || v == "false");
        }
        cfg
    }

    /// Returns the cookie name for the session.
    pub fn session_cookie(&self) -> String {
        format!("{}session", self.cookie_prefix)
    }
}
