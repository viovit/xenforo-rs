//! Mirrors `XF\Mvc\Entity\Repository` — the data-access base class.
use crate::{entity::Finder, Db};

/// Base trait for repositories. Concrete repositories (`UserRepository`, …)
/// implement this and add their own finder/query methods.
pub trait Repository: Send + Sync {
    /// A short name like `"XF:User"` used for lookup.
    const SHORT_NAME: &'static str;

    /// Construct from a [`Db`] handle.
    fn from_db(db: Db) -> Self;

    /// Borrow the underlying database.
    fn db(&self) -> &Db;

    /// Begin a finder over `table`.
    fn finder(&self, table: &'static str) -> Finder {
        Finder::new(self.db().clone(), table)
    }
}
