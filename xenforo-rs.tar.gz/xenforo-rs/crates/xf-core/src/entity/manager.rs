//! Mirrors `XF\Mvc\Entity\Manager` — the entity manager / repository registry.
use crate::{entity::Finder, Db};
use once_cell::sync::OnceCell;
use std::any::{Any, TypeId};
use std::collections::HashMap;
use std::sync::{Arc, RwLock};

/// The entity manager. Holds the [`Db`] and a per-process cache of repository
/// singletons, exactly like `XF::app()->em()` returning shared repositories.
pub struct Manager {
    db: Db,
    repos: RwLock<HashMap<TypeId, Arc<dyn Any + Send + Sync>>>,
}

impl Manager {
    pub fn new(db: Db) -> Self {
        Self {
            db,
            repos: RwLock::new(HashMap::new()),
        }
    }

    pub fn db(&self) -> &Db {
        &self.db
    }

    /// Get (or construct and cache) a repository of type `R`.
    pub fn repository<R: crate::entity::Repository + 'static>(&self) -> Arc<R> {
        let type_id = TypeId::of::<R>();
        if let Some(existing) = self.repos.read().unwrap().get(&type_id) {
            return existing.clone().downcast::<R>().unwrap();
        }
        let repo = Arc::new(R::from_db(self.db.clone()));
        self.repos
            .write()
            .unwrap()
            .insert(type_id, repo.clone() as Arc<dyn Any + Send + Sync>);
        repo
    }

    /// Begin a finder over `table`, mirroring `$em->getFinder('XF:Thread')`.
    pub fn finder(&self, table: &'static str) -> Finder {
        Finder::new(self.db.clone(), table)
    }
}

/// Process-global app instance (mirrors `\XF::app()`).
static GLOBAL: OnceCell<Arc<Manager>> = OnceCell::new();

/// Install the global manager (called once by `App`).
pub fn set_global(m: Arc<Manager>) {
    let _ = GLOBAL.set(m);
}

/// Access the global manager; panics if not installed.
pub fn global() -> Arc<Manager> {
    GLOBAL.get().expect("entity manager not initialised").clone()
}
