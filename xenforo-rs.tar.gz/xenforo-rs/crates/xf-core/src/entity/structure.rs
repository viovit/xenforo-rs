//! Mirrors `XF\Mvc\Entity\Structure`.
use std::collections::BTreeMap;

/// Column type — the `self::UINT` / `self::STR` / `self::BOOL` … constants used
/// in `getStructure()` column definitions.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ColumnType {
    /// `self::UINT` — unsigned integer.
    Uint,
    /// `self::INT` — signed integer.
    Int,
    /// `self::STR` — string.
    Str,
    /// `self::BINARY` — byte string.
    Binary,
    /// `self::BOOL` — boolean (0/1).
    Bool,
    /// `self::JSON_ARRAY` — JSON-encoded array.
    JsonArray,
    /// `self::LIST_COMMA` — comma-separated list.
    ListComma,
    /// `self::FLOAT` — floating point.
    Float,
}

/// A column definition as declared in `getStructure()->columns`.
#[derive(Debug, Clone)]
pub struct Column {
    pub name: &'static str,
    pub ty: ColumnType,
    pub nullable: bool,
    pub auto_increment: bool,
    pub default: Option<&'static str>,
    pub max_length: Option<u32>,
    pub allowed_values: &'static [&'static str],
}

impl Column {
    pub const fn new(name: &'static str, ty: ColumnType) -> Self {
        Self {
            name,
            ty,
            nullable: false,
            auto_increment: false,
            default: None,
            max_length: None,
            allowed_values: &[],
        }
    }
}

/// Relation type — `self::TO_ONE` / `self::TO_MANY`.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RelationType {
    ToOne,
    ToMany,
}

/// A relation definition.
#[derive(Debug, Clone)]
pub struct Relation {
    pub entity: &'static str,
    pub ty: RelationType,
}

/// The entity structure. Built once per entity type and cached.
#[derive(Debug, Clone)]
pub struct Structure {
    pub short_name: &'static str,
    pub content_type: &'static str,
    pub table: &'static str,
    pub primary_key: &'static str,
    pub columns: Vec<Column>,
    pub relations: BTreeMap<&'static str, Relation>,
}

impl Structure {
    pub fn new(short_name: &'static str, table: &'static str, primary_key: &'static str, content_type: &'static str) -> Self {
        Self {
            short_name,
            content_type,
            table,
            primary_key,
            columns: Vec::new(),
            relations: BTreeMap::new(),
        }
    }

    pub fn col(mut self, c: Column) -> Self {
        self.columns.push(c);
        self
    }

    pub fn relation(mut self, name: &'static str, entity: &'static str, ty: RelationType) -> Self {
        self.relations.insert(name, Relation { entity, ty });
        self
    }
}
