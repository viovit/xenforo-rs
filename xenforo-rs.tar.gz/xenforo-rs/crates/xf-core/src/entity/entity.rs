//! Mirrors `XF\Mvc\Entity\Entity` — typed structs that hydrate from a row.
use super::structure::Structure;
use rusqlite::Row;

/// The entity trait. Each concrete entity (`User`, `Thread`, …) implements this.
pub trait Entity: Sized + Send + Sync + 'static {
    /// The short name, e.g. `"XF:User"` — mirrors `$structure->shortName`.
    const SHORT_NAME: &'static str;

    /// Returns the cached [`Structure`] for this entity.
    fn structure() -> &'static Structure;

    /// Hydrate an instance from a database row.
    fn from_row(row: &Row<'_>) -> rusqlite::Result<Self>;

    /// Primary key value (used by the manager for caching/identity).
    fn primary_key_value(&self) -> i64;
}
