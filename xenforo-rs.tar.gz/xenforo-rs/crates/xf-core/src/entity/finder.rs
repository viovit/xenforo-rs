//! Mirrors `XF\Mvc\Entity\Finder` — a fluent query builder over an entity table.
use super::Entity;
use crate::{error::Result, Db};
use rusqlite::{params_from_iter, types::Value as SqlValue};

/// Sort direction.
#[derive(Debug, Clone, Copy)]
pub enum Order {
    Asc,
    Desc,
}

/// Convert a Rust scalar into a bound SQL value.
pub trait IntoSqlValue {
    fn into_value(self) -> SqlValue;
}
impl IntoSqlValue for i64 {
    fn into_value(self) -> SqlValue {
        SqlValue::Integer(self)
    }
}
impl IntoSqlValue for i32 {
    fn into_value(self) -> SqlValue {
        SqlValue::Integer(self as i64)
    }
}
impl IntoSqlValue for u32 {
    fn into_value(self) -> SqlValue {
        SqlValue::Integer(self as i64)
    }
}
impl IntoSqlValue for &str {
    fn into_value(self) -> SqlValue {
        SqlValue::Text(self.to_string())
    }
}
impl IntoSqlValue for String {
    fn into_value(self) -> SqlValue {
        SqlValue::Text(self)
    }
}
impl IntoSqlValue for &String {
    fn into_value(self) -> SqlValue {
        SqlValue::Text(self.clone())
    }
}
impl IntoSqlValue for bool {
    fn into_value(self) -> SqlValue {
        SqlValue::Integer(if self { 1 } else { 0 })
    }
}
impl IntoSqlValue for Option<i64> {
    fn into_value(self) -> SqlValue {
        self.map(SqlValue::Integer).unwrap_or(SqlValue::Null)
    }
}
impl IntoSqlValue for Option<String> {
    fn into_value(self) -> SqlValue {
        self.map(SqlValue::Text).unwrap_or(SqlValue::Null)
    }
}

/// A query builder. Generic over the entity it returns so repositories get
/// typed results, mirroring `$repo->finder('XF:Thread')->where([...])->order(...)`.
pub struct Finder {
    db: Db,
    table: &'static str,
    select: String,
    wheres: Vec<String>,
    params: Vec<SqlValue>,
    orders: Vec<String>,
    limit: Option<i64>,
    offset: Option<i64>,
}

impl Finder {
    pub fn new(db: Db, table: &'static str) -> Self {
        Self {
            db,
            table,
            select: format!("SELECT * FROM {table}"),
            wheres: Vec::new(),
            params: Vec::new(),
            orders: Vec::new(),
            limit: None,
            offset: None,
        }
    }

    /// Override the select list (e.g. `SELECT COUNT(*)`).
    pub fn select_sql(mut self, sql: impl Into<String>) -> Self {
        self.select = sql.into();
        self
    }

    /// `where(col = ?)` convenience.
    pub fn where_eq<V: IntoSqlValue>(mut self, col: &str, val: V) -> Self {
        self.wheres.push(format!("{col} = ?"));
        self.params.push(val.into_value());
        self
    }

    /// Raw where clause with bound params.
    pub fn where_sql(mut self, sql: impl Into<String>, vals: Vec<SqlValue>) -> Self {
        self.wheres.push(sql.into());
        self.params.extend(vals);
        self
    }

    pub fn where_in(mut self, col: &str, vals: Vec<i64>) -> Self {
        if vals.is_empty() {
            self.wheres.push("1 = 0".into());
            return self;
        }
        let placeholders: Vec<&str> = vals.iter().map(|_| "?").collect();
        self.wheres
            .push(format!("{col} IN ({})", placeholders.join(",")));
        self.params.extend(vals.into_iter().map(SqlValue::Integer));
        self
    }

    pub fn order(mut self, col: &str, dir: Order) -> Self {
        let d = match dir {
            Order::Asc => "ASC",
            Order::Desc => "DESC",
        };
        self.orders.push(format!("{col} {d}"));
        self
    }

    pub fn limit(mut self, n: i64) -> Self {
        self.limit = Some(n);
        self
    }

    pub fn offset(mut self, n: i64) -> Self {
        self.offset = Some(n);
        self
    }

    fn build_sql(&self) -> String {
        let mut sql = self.select.clone();
        if !self.wheres.is_empty() {
            sql.push_str(" WHERE ");
            sql.push_str(&self.wheres.join(" AND "));
        }
        if !self.orders.is_empty() {
            sql.push_str(" ORDER BY ");
            sql.push_str(&self.orders.join(", "));
        }
        if let Some(l) = self.limit {
            sql.push_str(&format!(" LIMIT {l}"));
        }
        if let Some(o) = self.offset {
            sql.push_str(&format!(" OFFSET {o}"));
        }
        sql
    }

    /// Fetch all matching rows as entities.
    pub fn fetch<E: Entity>(self) -> Result<Vec<E>> {
        let sql = self.build_sql();
        tracing::trace!(%sql, "finder fetch");
        self.db.with_conn(|c| {
            let mut stmt = c.prepare(&sql)?;
            let rows = stmt
                .query_map(params_from_iter(self.params.iter()), E::from_row)?
                .collect::<rusqlite::Result<Vec<_>>>()?;
            Ok(rows)
        })
    }

    /// Fetch the first matching row.
    pub fn fetch_one<E: Entity>(mut self) -> Result<Option<E>> {
        if self.limit.is_none() {
            self.limit = Some(1);
        }
        Ok(self.fetch::<E>()?.into_iter().next())
    }

    /// Count matching rows.
    pub fn total_count(self) -> Result<i64> {
        let mut s = self;
        s.select = format!("SELECT COUNT(*) FROM {}", s.table);
        s.orders.clear();
        s.db.with_conn(|c| {
            let mut stmt = c.prepare(&s.build_sql())?;
            Ok(stmt.query_row(params_from_iter(s.params.iter()), |r| {
                r.get::<_, i64>(0)
            })?)
        })
    }
}
