//! Object-relational mapper — a faithful Rust translation of `XF\Mvc\Entity`.
//!
//! * [`Structure`]  mirrors `XF\Mvc\Entity\Structure` (table, primary key,
//!   columns, content type).
//! * [`Entity`]     is the `XF\Mvc\Entity\Entity` trait: typed structs that know
//!   their structure and can hydrate from a database row.
//! * [`Finder`]     is `XF\Mvc\Entity\Finder` — a fluent query builder.
//! * [`Repository`] is `XF\Mvc\Entity\Repository` — the data-access layer.
//! * [`Manager`]    is `XF\Mvc\Entity\Manager` — the entity manager / repo cache.
pub mod entity;
pub mod finder;
pub mod manager;
pub mod repository;
pub mod structure;

pub use entity::Entity;
pub use finder::{Finder, Order};
pub use manager::Manager;
pub use repository::Repository;
pub use structure::{Column, ColumnType, Relation, RelationType, Structure};
