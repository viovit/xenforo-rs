//! The application container — mirrors `XF\App`.
//!
//! Holds the [`Config`], [`Db`], repository singletons and the template
//! engine. The HTTP front controller calls [`App::handle`] for every request,
//! which resolves the visitor/session, dispatches through the MVC layer and
//! renders the reply.
use crate::config::Config;
use crate::db::Db;
use crate::entities::User;
use crate::entity::Manager;
use crate::error::Result;
use crate::mvc::{ControllerKind, Dispatcher, Renderer, Request, Response};
use crate::permission::PermissionSet;
use crate::session::{Session, SessionStore};
use crate::template::TemplateEngine;
use once_cell::sync::OnceCell;
use serde_json::{json, Value};
use std::sync::Arc;

/// The resolved visitor: user + permissions + session + csrf.
#[derive(Debug)]
pub struct Visitor {
    pub user: User,
    pub perms: PermissionSet,
    pub session_id: String,
    pub csrf_token: String,
}

impl Visitor {
    pub fn is_guest(&self) -> bool {
        self.user.is_guest()
    }
    pub fn is_admin(&self) -> bool {
        self.user.is_admin()
    }
}

/// Repository singletons held by the app.
struct Repos {
    user: Arc<crate::repositories::UserRepository>,
    node: Arc<crate::repositories::NodeRepository>,
    forum: Arc<crate::repositories::ForumRepository>,
    thread: Arc<crate::repositories::ThreadRepository>,
    post: Arc<crate::repositories::PostRepository>,
}

/// The application.
pub struct App {
    pub config: Config,
    pub db: Db,
    pub templates: TemplateEngine,
    repos: Repos,
    manager: Arc<Manager>,
}

static GLOBAL_APP: OnceCell<Arc<App>> = OnceCell::new();

impl App {
    /// Boot the application: open the DB, run migrations, build repositories.
    pub fn boot(config: Config) -> Result<Arc<Self>> {
        let db = Db::open(&config.db_path)?;
        let templates = TemplateEngine::new()?;
        TemplateEngine::install_global(templates.clone());

        let manager = Arc::new(Manager::new(db.clone()));
        crate::entity::manager::set_global(manager.clone());

        let repos = Repos {
            user: manager.repository::<crate::repositories::UserRepository>(),
            node: manager.repository::<crate::repositories::NodeRepository>(),
            forum: manager.repository::<crate::repositories::ForumRepository>(),
            thread: manager.repository::<crate::repositories::ThreadRepository>(),
            post: manager.repository::<crate::repositories::PostRepository>(),
        };

        let app = Arc::new(Self {
            config,
            db,
            templates,
            repos,
            manager,
        });
        let _ = GLOBAL_APP.set(app.clone());
        Ok(app)
    }

    /// Access the global app (must be booted first).
    pub fn global() -> Arc<App> {
        GLOBAL_APP.get().expect("App not booted").clone()
    }

    pub fn user_repo(&self) -> &crate::repositories::UserRepository {
        &self.repos.user
    }
    pub fn node_repo(&self) -> &crate::repositories::NodeRepository {
        &self.repos.node
    }
    pub fn forum_repo(&self) -> &crate::repositories::ForumRepository {
        &self.repos.forum
    }
    pub fn thread_repo(&self) -> &crate::repositories::ThreadRepository {
        &self.repos.thread
    }
    pub fn post_repo(&self) -> &crate::repositories::PostRepository {
        &self.repos.post
    }
    pub fn manager(&self) -> &Manager {
        &self.manager
    }

    /// Resolve the visitor for a request (session cookie → user → permissions).
    /// Cached on the request so it is only computed once.
    fn resolve_visitor(&self, req: &mut Request) -> Result<Arc<Visitor>> {
        if let Some(v) = req.visitor.clone() {
            return Ok(v);
        }
        let store = SessionStore::new(self.db.clone());
        let session = match req.cookie(&self.config.session_cookie()) {
            Some(id) => store.get(id)?.unwrap_or_else(|| {
                store.create(&req.remote_ip).expect("create session")
            }),
            None => store.create(&req.remote_ip)?,
        };
        let user = if session.user_id != 0 {
            self.repos.user.get_user(session.user_id)?.unwrap_or_default()
        } else {
            guest_user()
        };
        let perms = PermissionSet::for_user(&self.db, &user)?;
        let csrf = csrf_for(&session, &self.db, &session.session_id);
        let v = Arc::new(Visitor {
            user,
            perms,
            session_id: session.session_id.clone(),
            csrf_token: csrf,
        });
        req.visitor = Some(v.clone());
        Ok(v)
    }

    /// Read the already-resolved visitor (set by [`App::handle`]); falls back to
    /// a guest if the request has not been through `handle`.
    pub fn visitor(&self, req: &Request) -> Arc<Visitor> {
        self.visitor_of(req)
    }

    fn visitor_of(&self, req: &Request) -> Arc<Visitor> {
        req.visitor.clone().unwrap_or_else(|| {
            Arc::new(Visitor {
                user: guest_user(),
                perms: PermissionSet::guest(),
                session_id: String::new(),
                csrf_token: crate::str::random_hex(16),
            })
        })
    }

    /// The main request handler: resolve visitor → dispatch → render.
    pub fn handle(&self, req: &mut Request) -> Response {
        let had_cookie = req.cookie(&self.config.session_cookie()).is_some();
        let visitor = match self.resolve_visitor(req) {
            Ok(v) => v,
            Err(e) => {
                tracing::error!(error = %e, "visitor resolution failed");
                return Response::new(500, b"internal error".to_vec(), "text/plain");
            }
        };

        if let Err(e) = self.repos.user.touch_activity(visitor.user.user_id) {
            tracing::warn!(error = %e, "touch activity failed");
        }

        let reply = Dispatcher::dispatch(req, self);
        let mut response = Renderer::render(reply, req, self);

        // Send a session cookie if this request started a fresh session.
        if !had_cookie && !visitor.session_id.is_empty() {
            let cookie = crate::session::cookie(
                &self.config.session_cookie(),
                &visitor.session_id,
                &self.config,
            );
            response.headers.push(("set-cookie".into(), cookie));
        }
        response
    }

    /// Render a template, merging in the global context (board, visitor, csrf).
    pub fn render_template(&self, name: &str, context: Value, req: &Request) -> Result<String> {
        let visitor = self.visitor_of(req);
        let globals = json!({
            "board_title": self.config.board_title,
            "board_url": self.config.board_url,
            "csrf_token": visitor.csrf_token,
            "current_year": chrono::Utc::now().format("%Y").to_string(),
            "visitor": visitor_json(&visitor.user),
        });
        let merged = merge_context(context, globals);
        self.templates.render(name, &merged)
    }

    /// Record session activity for the current request (postDispatch).
    pub fn record_session_activity(&self, kind: ControllerKind, action: &str, req: &Request) {
        let visitor = self.visitor_of(req);
        let now = crate::time::now();
        let uid = visitor.user.user_id;
        let unique_key = if uid == 0 {
            req.remote_ip.clone()
        } else {
            String::new()
        };
        let controller = format!("{kind:?}");
        let _ = self.db.execute(
            "INSERT INTO xf_session_activity \
             (user_id, unique_key, controller, action, params, view_state, ip, last_activity) \
             VALUES (?, ?, ?, ?, '{}', 'valid', ?, ?) \
             ON CONFLICT(user_id, unique_key) DO UPDATE SET \
                 controller = excluded.controller, action = excluded.action, \
                 view_state = excluded.view_state, ip = excluded.ip, \
                 last_activity = excluded.last_activity",
            &[
                &uid as &dyn rusqlite::ToSql,
                &unique_key,
                &controller,
                &action,
                &req.remote_ip,
                &now,
            ],
        );
    }

    /// Create a session for `user_id` (used by the login controller).
    pub fn start_session_for(&self, user_id: i64, ip: &str) -> Result<Session> {
        let store = SessionStore::new(self.db.clone());
        let session = store.create(ip)?;
        store.attach_user(&session.session_id, user_id)?;
        Ok(session)
    }

    /// Destroy a session (logout).
    pub fn destroy_session(&self, session_id: &str) -> Result<()> {
        SessionStore::new(self.db.clone()).destroy(session_id)
    }
}

/// Build a guest user (id 0).
fn guest_user() -> User {
    let mut u = User::default();
    u.user_id = 0;
    u.username = "Guest".into();
    u.user_group_id = 4;
    u.user_state = "valid".into();
    u.timezone = "UTC".into();
    u
}

/// Serialise a [`User`] into the JSON shape templates expect.
fn visitor_json(user: &User) -> Value {
    json!({
        "user_id": user.user_id,
        "username": user.username,
        "email": user.email,
        "is_guest": user.is_guest(),
        "is_admin": user.is_admin(),
        "is_staff": user.is_staff,
        "message_count": user.message_count,
        "reaction_score": user.reaction_score,
        "custom_title": user.custom_title,
        "register_date": user.register_date,
        "last_activity": user.last_activity,
    })
}

/// Merge `page` context with `globals` (globals only fill missing top-level keys).
fn merge_context(mut page: Value, globals: Value) -> Value {
    if let (Some(p), Some(g)) = (page.as_object_mut(), globals.as_object()) {
        for (k, v) in g {
            p.entry(k.clone()).or_insert_with(|| v.clone());
        }
    } else {
        return globals;
    }
    page
}

/// Derive a CSRF token from the session (stored in `session_data` JSON).
/// If absent, one is generated and persisted.
fn csrf_for(session: &Session, db: &Db, _id: &str) -> String {
    if let Ok(v) = serde_json::from_str::<serde_json::Value>(&session.session_data) {
        if let Some(c) = v.get("csrf").and_then(|c| c.as_str()) {
            if !c.is_empty() {
                return c.to_string();
            }
        }
    }
    let token = crate::str::random_hex(16);
    let data = serde_json::to_string(&serde_json::json!({ "csrf": token })).unwrap_or_default();
    let _ = db.execute(
        "UPDATE xf_session SET session_data = ? WHERE session_id = ?",
        &[&data as &dyn rusqlite::ToSql, &session.session_id],
    );
    token
}
