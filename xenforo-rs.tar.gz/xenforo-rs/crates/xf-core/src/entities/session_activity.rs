//! `XF\Entity\SessionActivity` — `xf_session_activity`.
use crate::entity::{Entity, Structure};
use once_cell::sync::Lazy;
use rusqlite::Row;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct SessionActivity {
    pub user_id: i64,
    pub unique_key: String,
    pub controller: String,
    pub action: String,
    pub params: String,
    pub view_state: String,
    pub ip: String,
    pub last_activity: i64,
}

static SESSION_ACTIVITY_STRUCTURE: Lazy<Structure> = Lazy::new(|| {
    Structure::new(
        "XF:SessionActivity",
        "xf_session_activity",
        "user_id",
        "session_activity",
    )
});

impl Entity for SessionActivity {
    const SHORT_NAME: &'static str = "XF:SessionActivity";
    fn structure() -> &'static Structure {
        &SESSION_ACTIVITY_STRUCTURE
    }
    fn from_row(row: &Row<'_>) -> rusqlite::Result<Self> {
        Ok(Self {
            user_id: row.get("user_id")?,
            unique_key: row.get("unique_key")?,
            controller: row.get("controller")?,
            action: row.get("action")?,
            params: row.get("params")?,
            view_state: row.get("view_state")?,
            ip: row.get("ip")?,
            last_activity: row.get("last_activity")?,
        })
    }
    fn primary_key_value(&self) -> i64 {
        self.user_id
    }
}
