//! `XF\Entity\Forum` (`xf_forum`) and `XF\Entity\Category` (`xf_category`).
use crate::entity::{Entity, Structure};
use once_cell::sync::Lazy;
use rusqlite::Row;
use serde::{Deserialize, Serialize};

/// `XF\Entity\Forum` — forum-specific data, keyed by `node_id`.
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct Forum {
    pub node_id: i64,
    pub discussion_count: i64,
    pub message_count: i64,
    pub last_post_id: i64,
    pub last_post_date: i64,
    pub last_post_user_id: i64,
    pub last_post_username: String,
    pub last_thread_id: i64,
    pub last_thread_title: String,
    pub last_thread_prefix_id: i64,
    pub moderate_threads: bool,
    pub moderate_replies: bool,
    pub forum_type_id: String,
    pub type_config: String,
    pub allow_posting: bool,
    pub count_messages: bool,
    pub auto_feature: bool,
    pub find_new: bool,
    pub allow_index: String,
    pub index_criteria: String,
    pub require_prefix: bool,
    pub allowed_watch_notifications: String,
    pub field_cache: String,
    pub prefix_cache: String,
    pub prompt_cache: String,
    pub default_prefix_id: i64,
    pub default_sort_order: String,
    pub default_sort_direction: String,
    pub list_date_limit_days: i64,
    pub min_tags: i64,
}

static FORUM_STRUCTURE: Lazy<Structure> =
    Lazy::new(|| Structure::new("XF:Forum", "xf_forum", "node_id", "forum"));

impl Entity for Forum {
    const SHORT_NAME: &'static str = "XF:Forum";
    fn structure() -> &'static Structure {
        &FORUM_STRUCTURE
    }
    fn from_row(row: &Row<'_>) -> rusqlite::Result<Self> {
        Ok(Self {
            node_id: row.get("node_id")?,
            discussion_count: row.get("discussion_count")?,
            message_count: row.get("message_count")?,
            last_post_id: row.get("last_post_id")?,
            last_post_date: row.get("last_post_date")?,
            last_post_user_id: row.get("last_post_user_id")?,
            last_post_username: row.get("last_post_username")?,
            last_thread_id: row.get("last_thread_id")?,
            last_thread_title: row.get("last_thread_title")?,
            last_thread_prefix_id: row.get("last_thread_prefix_id")?,
            moderate_threads: row.get::<_, i64>("moderate_threads")? != 0,
            moderate_replies: row.get::<_, i64>("moderate_replies")? != 0,
            forum_type_id: row.get("forum_type_id")?,
            type_config: row.get("type_config")?,
            allow_posting: row.get::<_, i64>("allow_posting")? != 0,
            count_messages: row.get::<_, i64>("count_messages")? != 0,
            auto_feature: row.get::<_, i64>("auto_feature")? != 0,
            find_new: row.get::<_, i64>("find_new")? != 0,
            allow_index: row.get("allow_index")?,
            index_criteria: row.get("index_criteria")?,
            require_prefix: row.get::<_, i64>("require_prefix")? != 0,
            allowed_watch_notifications: row.get("allowed_watch_notifications")?,
            field_cache: row.get("field_cache")?,
            prefix_cache: row.get("prefix_cache")?,
            prompt_cache: row.get("prompt_cache")?,
            default_prefix_id: row.get("default_prefix_id")?,
            default_sort_order: row.get("default_sort_order")?,
            default_sort_direction: row.get("default_sort_direction")?,
            list_date_limit_days: row.get("list_date_limit_days")?,
            min_tags: row.get("min_tags")?,
        })
    }
    fn primary_key_value(&self) -> i64 {
        self.node_id
    }
}

/// `XF\Entity\Category` — `xf_category`.
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct Category {
    pub node_id: i64,
}

static CATEGORY_STRUCTURE: Lazy<Structure> =
    Lazy::new(|| Structure::new("XF:Category", "xf_category", "node_id", "category"));

impl Entity for Category {
    const SHORT_NAME: &'static str = "XF:Category";
    fn structure() -> &'static Structure {
        &CATEGORY_STRUCTURE
    }
    fn from_row(row: &Row<'_>) -> rusqlite::Result<Self> {
        Ok(Self {
            node_id: row.get("node_id")?,
        })
    }
    fn primary_key_value(&self) -> i64 {
        self.node_id
    }
}
