//! Concrete entities — Rust translations of `src/XF/Entity/*.php`.
//!
//! Each struct carries the full column set declared in the corresponding
//! `getStructure()` method, so the data model matches XenForo 1:1.
pub mod forum;
pub mod node;
pub mod post;
pub mod session_activity;
pub mod thread;
pub mod user;

pub use forum::{Category, Forum};
pub use node::Node;
pub use post::Post;
pub use session_activity::SessionActivity;
pub use thread::Thread;
pub use user::{User, UserAuth, UserGroup, UserOption, UserPrivacy, UserProfile};
