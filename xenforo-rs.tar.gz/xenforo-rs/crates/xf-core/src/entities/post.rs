//! `XF\Entity\Post` — `xf_post`.
use crate::entity::{Entity, Structure};
use once_cell::sync::Lazy;
use rusqlite::Row;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct Post {
    pub post_id: i64,
    pub thread_id: i64,
    pub user_id: i64,
    pub username: String,
    pub post_date: i64,
    pub message: String,
    pub ip_id: i64,
    pub message_state: String,
    pub attach_count: i64,
    pub warning_id: i64,
    pub warning_message: String,
    pub position: i64,
    pub type_data: String,
    pub last_edit_date: i64,
    pub last_edit_user_id: i64,
    pub edit_count: i64,
    pub embed_metadata: Option<String>,
}

static POST_STRUCTURE: Lazy<Structure> =
    Lazy::new(|| Structure::new("XF:Post", "xf_post", "post_id", "post"));

impl Entity for Post {
    const SHORT_NAME: &'static str = "XF:Post";
    fn structure() -> &'static Structure {
        &POST_STRUCTURE
    }
    fn from_row(row: &Row<'_>) -> rusqlite::Result<Self> {
        Ok(Self {
            post_id: row.get("post_id")?,
            thread_id: row.get("thread_id")?,
            user_id: row.get("user_id")?,
            username: row.get("username")?,
            post_date: row.get("post_date")?,
            message: row.get("message")?,
            ip_id: row.get("ip_id")?,
            message_state: row.get("message_state")?,
            attach_count: row.get("attach_count")?,
            warning_id: row.get("warning_id")?,
            warning_message: row.get("warning_message")?,
            position: row.get("position")?,
            type_data: row.get("type_data")?,
            last_edit_date: row.get("last_edit_date")?,
            last_edit_user_id: row.get("last_edit_user_id")?,
            edit_count: row.get("edit_count")?,
            embed_metadata: row.get("embed_metadata").ok(),
        })
    }
    fn primary_key_value(&self) -> i64 {
        self.post_id
    }
}

impl Post {
    pub fn is_first_post(&self, thread_first_post_id: i64) -> bool {
        self.post_id == thread_first_post_id
    }
    pub fn is_visible(&self) -> bool {
        self.message_state == "visible"
    }
    pub fn is_edited(&self) -> bool {
        self.edit_count > 0
    }
}
