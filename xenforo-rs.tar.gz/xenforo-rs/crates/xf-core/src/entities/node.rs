//! `XF\Entity\Node` — `xf_node`. The nested-set node tree.
use crate::entity::{Column, ColumnType, Entity, Structure};
use once_cell::sync::Lazy;
use rusqlite::Row;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct Node {
    pub node_id: i64,
    pub title: String,
    pub node_name: Option<String>,
    pub description: String,
    pub node_type_id: String,
    pub parent_node_id: i64,
    pub display_order: i64,
    pub lft: i64,
    pub rgt: i64,
    pub depth: i64,
    pub style_id: i64,
    pub effective_style_id: i64,
    pub display_in_list: bool,
    pub breadcrumb_data: String,
    pub navigation_id: String,
    pub effective_navigation_id: String,
}

static NODE_STRUCTURE: Lazy<Structure> = Lazy::new(|| {
    Structure::new("XF:Node", "xf_node", "node_id", "node")
        .col(Column::new("node_id", ColumnType::Uint))
        .col(Column::new("title", ColumnType::Str))
        .col(Column::new("node_name", ColumnType::Str))
        .col(Column::new("node_type_id", ColumnType::Binary))
        .col(Column::new("parent_node_id", ColumnType::Uint))
        .col(Column::new("display_order", ColumnType::Uint))
        .col(Column::new("lft", ColumnType::Uint))
        .col(Column::new("rgt", ColumnType::Uint))
        .col(Column::new("depth", ColumnType::Uint))
        .col(Column::new("display_in_list", ColumnType::Bool))
        .relation("Parent", "XF:Node", RelationType::ToOne)
});

use crate::entity::RelationType;

impl Entity for Node {
    const SHORT_NAME: &'static str = "XF:Node";
    fn structure() -> &'static Structure {
        &NODE_STRUCTURE
    }
    fn from_row(row: &Row<'_>) -> rusqlite::Result<Self> {
        Ok(Self {
            node_id: row.get("node_id")?,
            title: row.get("title")?,
            node_name: row.get::<_, Option<String>>("node_name")?,
            description: row.get("description")?,
            node_type_id: row.get("node_type_id")?,
            parent_node_id: row.get("parent_node_id")?,
            display_order: row.get("display_order")?,
            lft: row.get("lft")?,
            rgt: row.get("rgt")?,
            depth: row.get("depth")?,
            style_id: row.get("style_id")?,
            effective_style_id: row.get("effective_style_id")?,
            display_in_list: row.get::<_, i64>("display_in_list")? != 0,
            breadcrumb_data: row.get("breadcrumb_data")?,
            navigation_id: row.get("navigation_id")?,
            effective_navigation_id: row.get("effective_navigation_id")?,
        })
    }
    fn primary_key_value(&self) -> i64 {
        self.node_id
    }
}

impl Node {
    /// True when this node is a forum (has a row in `xf_forum`).
    pub fn is_forum(&self) -> bool {
        self.node_type_id == "Forum"
    }
    /// True when this node is a category.
    pub fn is_category(&self) -> bool {
        self.node_type_id == "Category"
    }
}
