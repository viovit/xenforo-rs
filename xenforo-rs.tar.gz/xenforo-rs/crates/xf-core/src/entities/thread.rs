//! `XF\Entity\Thread` — `xf_thread`.
use crate::entity::{Entity, Structure};
use once_cell::sync::Lazy;
use rusqlite::Row;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct Thread {
    pub thread_id: i64,
    pub node_id: i64,
    pub title: String,
    pub reply_count: i64,
    pub view_count: i64,
    pub user_id: i64,
    pub username: String,
    pub post_date: i64,
    pub sticky: bool,
    pub discussion_state: String,
    pub discussion_open: bool,
    pub discussion_type: String,
    pub type_data: String,
    pub index_state: String,
    pub first_post_id: i64,
    pub last_post_date: i64,
    pub last_post_id: i64,
    pub last_post_user_id: i64,
    pub last_post_username: String,
    pub first_post_reaction_score: i64,
    pub first_post_reactions: Option<String>,
    pub prefix_id: i64,
    pub custom_fields: String,
    pub tags: String,
}

static THREAD_STRUCTURE: Lazy<Structure> =
    Lazy::new(|| Structure::new("XF:Thread", "xf_thread", "thread_id", "thread"));

impl Entity for Thread {
    const SHORT_NAME: &'static str = "XF:Thread";
    fn structure() -> &'static Structure {
        &THREAD_STRUCTURE
    }
    fn from_row(row: &Row<'_>) -> rusqlite::Result<Self> {
        Ok(Self {
            thread_id: row.get("thread_id")?,
            node_id: row.get("node_id")?,
            title: row.get("title")?,
            reply_count: row.get("reply_count")?,
            view_count: row.get("view_count")?,
            user_id: row.get("user_id")?,
            username: row.get("username")?,
            post_date: row.get("post_date")?,
            sticky: row.get::<_, i64>("sticky")? != 0,
            discussion_state: row.get("discussion_state")?,
            discussion_open: row.get::<_, i64>("discussion_open")? != 0,
            discussion_type: row.get("discussion_type")?,
            type_data: row.get("type_data")?,
            index_state: row.get("index_state")?,
            first_post_id: row.get("first_post_id")?,
            last_post_date: row.get("last_post_date")?,
            last_post_id: row.get("last_post_id")?,
            last_post_user_id: row.get("last_post_user_id")?,
            last_post_username: row.get("last_post_username")?,
            first_post_reaction_score: row.get("first_post_reaction_score")?,
            first_post_reactions: row.get("first_post_reactions").ok(),
            prefix_id: row.get("prefix_id")?,
            custom_fields: row.get("custom_fields")?,
            tags: row.get("tags")?,
        })
    }
    fn primary_key_value(&self) -> i64 {
        self.thread_id
    }
}

impl Thread {
    /// Total number of posts = reply_count + 1 (the first post).
    pub fn post_count(&self) -> i64 {
        self.reply_count + 1
    }

    pub fn is_visible(&self) -> bool {
        self.discussion_state == "visible"
    }
    pub fn is_deleted(&self) -> bool {
        self.discussion_state == "deleted"
    }
    pub fn is_moderated(&self) -> bool {
        self.discussion_state == "moderated"
    }
    pub fn is_open(&self) -> bool {
        self.discussion_open
    }
}
