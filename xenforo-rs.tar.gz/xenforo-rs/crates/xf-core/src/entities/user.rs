//! User-related entities (`XF\Entity\User`, `UserAuth`, `UserGroup`, …).
use crate::entity::{Column, ColumnType, Entity, RelationType, Structure};
use once_cell::sync::Lazy;
use rusqlite::Row;
use serde::{Deserialize, Serialize};

// ---------------------------------------------------------------------------
// User
// ---------------------------------------------------------------------------
/// `XF\Entity\User` — `xf_user`.
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct User {
    pub user_id: i64,
    pub username: String,
    pub username_date: i64,
    pub username_date_visible: i64,
    pub email: String,
    pub style_id: i64,
    pub style_variation: String,
    pub language_id: i64,
    pub timezone: String,
    pub visible: bool,
    pub activity_visible: bool,
    pub user_group_id: i64,
    pub secondary_group_ids: String,
    pub display_style_group_id: i64,
    pub permission_combination_id: i64,
    pub message_count: i64,
    pub question_solution_count: i64,
    pub alerts_unviewed: i64,
    pub alerts_unread: i64,
    pub conversations_unread: i64,
    pub register_date: i64,
    pub last_activity: i64,
    pub last_summary_email_date: Option<i64>,
    pub trophy_points: i64,
    pub avatar_date: i64,
    pub avatar_width: i64,
    pub avatar_height: i64,
    pub avatar_highdpi: bool,
    pub avatar_optimized: bool,
    pub gravatar: String,
    pub user_state: String,
    pub security_lock: String,
    pub is_moderator: bool,
    pub is_admin: bool,
    pub is_staff: bool,
    pub is_banned: bool,
    pub reaction_score: i64,
    pub vote_score: i64,
    pub custom_title: String,
    pub warning_points: i64,
    pub secret_key: String,
    pub privacy_policy_accepted: i64,
    pub terms_accepted: i64,
}

static USER_STRUCTURE: Lazy<Structure> = Lazy::new(|| {
    Structure::new("XF:User", "xf_user", "user_id", "user")
        .col(Column::new("user_id", ColumnType::Uint))
        .col(Column::new("username", ColumnType::Str))
        .col(Column::new("email", ColumnType::Str))
        .col(Column::new("user_group_id", ColumnType::Uint))
        .col(Column::new("secondary_group_ids", ColumnType::ListComma))
        .col(Column::new("permission_combination_id", ColumnType::Uint))
        .col(Column::new("message_count", ColumnType::Uint))
        .col(Column::new("register_date", ColumnType::Uint))
        .col(Column::new("last_activity", ColumnType::Uint))
        .col(Column::new("user_state", ColumnType::Str))
        .col(Column::new("is_moderator", ColumnType::Bool))
        .col(Column::new("is_admin", ColumnType::Bool))
        .col(Column::new("is_staff", ColumnType::Bool))
        .col(Column::new("is_banned", ColumnType::Bool))
        .col(Column::new("reaction_score", ColumnType::Int))
        .col(Column::new("secret_key", ColumnType::Binary))
        .relation("Auth", "XF:UserAuth", RelationType::ToOne)
        .relation("Option", "XF:UserOption", RelationType::ToOne)
        .relation("Profile", "XF:UserProfile", RelationType::ToOne)
        .relation("Privacy", "XF:UserPrivacy", RelationType::ToOne)
});

impl Entity for User {
    const SHORT_NAME: &'static str = "XF:User";
    fn structure() -> &'static Structure {
        &USER_STRUCTURE
    }
    fn from_row(row: &Row<'_>) -> rusqlite::Result<Self> {
        Ok(Self {
            user_id: row.get("user_id")?,
            username: row.get("username")?,
            username_date: row.get("username_date")?,
            username_date_visible: row.get("username_date_visible")?,
            email: row.get("email")?,
            style_id: row.get("style_id")?,
            style_variation: row.get("style_variation")?,
            language_id: row.get("language_id")?,
            timezone: row.get("timezone")?,
            visible: row.get::<_, i64>("visible")? != 0,
            activity_visible: row.get::<_, i64>("activity_visible")? != 0,
            user_group_id: row.get("user_group_id")?,
            secondary_group_ids: row.get("secondary_group_ids")?,
            display_style_group_id: row.get("display_style_group_id")?,
            permission_combination_id: row.get("permission_combination_id")?,
            message_count: row.get("message_count")?,
            question_solution_count: row.get("question_solution_count")?,
            alerts_unviewed: row.get("alerts_unviewed")?,
            alerts_unread: row.get("alerts_unread")?,
            conversations_unread: row.get("conversations_unread")?,
            register_date: row.get("register_date")?,
            last_activity: row.get("last_activity")?,
            last_summary_email_date: row.get("last_summary_email_date").ok(),
            trophy_points: row.get("trophy_points")?,
            avatar_date: row.get("avatar_date")?,
            avatar_width: row.get("avatar_width")?,
            avatar_height: row.get("avatar_height")?,
            avatar_highdpi: row.get::<_, i64>("avatar_highdpi")? != 0,
            avatar_optimized: row.get::<_, i64>("avatar_optimized")? != 0,
            gravatar: row.get("gravatar")?,
            user_state: row.get("user_state")?,
            security_lock: row.get("security_lock")?,
            is_moderator: row.get::<_, i64>("is_moderator")? != 0,
            is_admin: row.get::<_, i64>("is_admin")? != 0,
            is_staff: row.get::<_, i64>("is_staff")? != 0,
            is_banned: row.get::<_, i64>("is_banned")? != 0,
            reaction_score: row.get("reaction_score")?,
            vote_score: row.get("vote_score")?,
            custom_title: row.get("custom_title")?,
            warning_points: row.get("warning_points")?,
            secret_key: row.get("secret_key")?,
            privacy_policy_accepted: row.get("privacy_policy_accepted")?,
            terms_accepted: row.get("terms_accepted")?,
        })
    }
    fn primary_key_value(&self) -> i64 {
        self.user_id
    }
}

impl User {
    /// Returns the list of group ids the user belongs to (primary + secondary).
    pub fn group_ids(&self) -> Vec<i64> {
        let mut ids = vec![self.user_group_id];
        for part in self.secondary_group_ids.split(',') {
            if !part.is_empty() {
                if let Ok(g) = part.trim().parse::<i64>() {
                    ids.push(g);
                }
            }
        }
        ids.sort();
        ids.dedup();
        ids
    }

    /// True if the user is a guest (id 0).
    pub fn is_guest(&self) -> bool {
        self.user_id == 0
    }

    /// Convenience: is this user an administrator?
    pub fn is_admin(&self) -> bool {
        self.is_admin || self.user_group_id == 1
    }
}

// ---------------------------------------------------------------------------
// UserAuth — `xf_user_auth`
// ---------------------------------------------------------------------------
/// `XF\Entity\UserAuth`. Stores the password hash keyed by scheme class.
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct UserAuth {
    pub user_id: i64,
    pub scheme_class: String,
    /// JSON blob, e.g. `{"hash":"$2b$..."}`.
    pub data: String,
}

impl UserAuth {
    /// Extract the bcrypt hash from the `data` JSON.
    pub fn hash(&self) -> Option<String> {
        let v: serde_json::Value = serde_json::from_str(&self.data).ok()?;
        v.get("hash").and_then(|h| h.as_str()).map(String::from)
    }
}

static USER_AUTH_STRUCTURE: Lazy<Structure> =
    Lazy::new(|| Structure::new("XF:UserAuth", "xf_user_auth", "user_id", "user"));

impl Entity for UserAuth {
    const SHORT_NAME: &'static str = "XF:UserAuth";
    fn structure() -> &'static Structure {
        &USER_AUTH_STRUCTURE
    }
    fn from_row(row: &Row<'_>) -> rusqlite::Result<Self> {
        Ok(Self {
            user_id: row.get("user_id")?,
            scheme_class: row.get("scheme_class")?,
            data: row.get("data")?,
        })
    }
    fn primary_key_value(&self) -> i64 {
        self.user_id
    }
}

// ---------------------------------------------------------------------------
// UserGroup — `xf_user_group`
// ---------------------------------------------------------------------------
/// `XF\Entity\UserGroup`.
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct UserGroup {
    pub user_group_id: i64,
    pub title: String,
    pub display_style_priority: i64,
    pub username_css: String,
    pub user_title: String,
    pub banner_css: String,
    pub banner_text: String,
}

impl Entity for UserGroup {
    const SHORT_NAME: &'static str = "XF:UserGroup";
    fn structure() -> &'static Structure {
        static S: Lazy<Structure> = Lazy::new(|| {
            Structure::new("XF:UserGroup", "xf_user_group", "user_group_id", "user_group")
        });
        &S
    }
    fn from_row(row: &Row<'_>) -> rusqlite::Result<Self> {
        Ok(Self {
            user_group_id: row.get("user_group_id")?,
            title: row.get("title")?,
            display_style_priority: row.get("display_style_priority")?,
            username_css: row.get("username_css")?,
            user_title: row.get("user_title")?,
            banner_css: row.get("banner_css")?,
            banner_text: row.get("banner_text")?,
        })
    }
    fn primary_key_value(&self) -> i64 {
        self.user_group_id
    }
}

// ---------------------------------------------------------------------------
// UserOption / UserProfile / UserPrivacy — `xf_user_option`, etc.
// ---------------------------------------------------------------------------
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct UserOption {
    pub user_id: i64,
    pub show_signature: bool,
    pub content_show_signature: bool,
    pub receive_admin_email: bool,
    pub email_on_conversation: bool,
    pub is_discouraged: bool,
    pub creation_watch_state: String,
    pub interaction_watch_state: String,
}

impl Entity for UserOption {
    const SHORT_NAME: &'static str = "XF:UserOption";
    fn structure() -> &'static Structure {
        static S: Lazy<Structure> =
            Lazy::new(|| Structure::new("XF:UserOption", "xf_user_option", "user_id", "user_option"));
        &S
    }
    fn from_row(row: &Row<'_>) -> rusqlite::Result<Self> {
        Ok(Self {
            user_id: row.get("user_id")?,
            show_signature: row.get::<_, i64>("show_signature")? != 0,
            content_show_signature: row.get::<_, i64>("content_show_signature")? != 0,
            receive_admin_email: row.get::<_, i64>("receive_admin_email")? != 0,
            email_on_conversation: row.get::<_, i64>("email_on_conversation")? != 0,
            is_discouraged: row.get::<_, i64>("is_discouraged")? != 0,
            creation_watch_state: row.get("creation_watch_state")?,
            interaction_watch_state: row.get("interaction_watch_state")?,
        })
    }
    fn primary_key_value(&self) -> i64 {
        self.user_id
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct UserProfile {
    pub user_id: i64,
    pub dob_day: i64,
    pub dob_month: i64,
    pub dob_year: i64,
    pub status: String,
    pub status_date: i64,
    pub status_profile_post_id: i64,
    pub signature: String,
    pub website: String,
    pub location: String,
    pub following: String,
    pub followers: String,
    pub about: String,
}

impl Entity for UserProfile {
    const SHORT_NAME: &'static str = "XF:UserProfile";
    fn structure() -> &'static Structure {
        static S: Lazy<Structure> = Lazy::new(|| {
            Structure::new("XF:UserProfile", "xf_user_profile", "user_id", "user_profile")
        });
        &S
    }
    fn from_row(row: &Row<'_>) -> rusqlite::Result<Self> {
        Ok(Self {
            user_id: row.get("user_id")?,
            dob_day: row.get("dob_day")?,
            dob_month: row.get("dob_month")?,
            dob_year: row.get("dob_year")?,
            status: row.get("status")?,
            status_date: row.get("status_date")?,
            status_profile_post_id: row.get("status_profile_post_id")?,
            signature: row.get("signature")?,
            website: row.get("website")?,
            location: row.get("location")?,
            following: row.get("following")?,
            followers: row.get("followers")?,
            about: row.get("about")?,
        })
    }
    fn primary_key_value(&self) -> i64 {
        self.user_id
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct UserPrivacy {
    pub user_id: i64,
    pub allow_view_profile: String,
    pub allow_post_profile: String,
    pub allow_send_personal_conversation: String,
    pub allow_view_identities: String,
    pub allow_receive_news_feed: String,
}

impl Entity for UserPrivacy {
    const SHORT_NAME: &'static str = "XF:UserPrivacy";
    fn structure() -> &'static Structure {
        static S: Lazy<Structure> = Lazy::new(|| {
            Structure::new("XF:UserPrivacy", "xf_user_privacy", "user_id", "user_privacy")
        });
        &S
    }
    fn from_row(row: &Row<'_>) -> rusqlite::Result<Self> {
        Ok(Self {
            user_id: row.get("user_id")?,
            allow_view_profile: row.get("allow_view_profile")?,
            allow_post_profile: row.get("allow_post_profile")?,
            allow_send_personal_conversation: row.get("allow_send_personal_conversation")?,
            allow_view_identities: row.get("allow_view_identities")?,
            allow_receive_news_feed: row.get("allow_receive_news_feed")?,
        })
    }
    fn primary_key_value(&self) -> i64 {
        self.user_id
    }
}
