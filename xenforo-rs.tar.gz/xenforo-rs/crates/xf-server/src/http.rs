//! HTTP front controller — a thin axum adapter around the XF MVC pipeline.
//!
//! Every request is converted into an [`xf_core::mvc::Request`], handed to
//! [`xf_core::App::handle`], and the returned [`xf_core::mvc::Response`] is
//! translated back into an axum response. This keeps the XenForo single
//! front-controller architecture intact (`index.php` → router → dispatcher).
use axum::body::Bytes;
use axum::extract::Request as AxumRequest;
use axum::http::{HeaderMap, HeaderName, HeaderValue, StatusCode};
use axum::response::{IntoResponse, Response as AxumResponse};
use axum::routing::get;
use axum::Router;
use std::collections::HashMap;
use std::sync::Arc;
use xf_core::app::App;
use xf_core::mvc::{Method, Request, Response};

/// Build the axum router for `app`.
pub fn build_router(app: Arc<App>) -> Router {
    Router::new()
        .route("/static/xf.css", get(serve_css))
        .route("/favicon.ico", get(serve_favicon))
        .with_state(app.clone())
        .fallback(move |axum_req: AxumRequest| serve_app(axum_req, app.clone()))
}

/// Embedded default stylesheet.
const CSS: &str = include_str!("../../../static/xf.css");

async fn serve_css() -> impl IntoResponse {
    (
        StatusCode::OK,
        [("content-type", "text/css; charset=utf-8")],
        CSS,
    )
}

async fn serve_favicon() -> impl IntoResponse {
    (
        StatusCode::NO_CONTENT,
        [("content-type", "image/x-icon")],
        "",
    )
}

async fn serve_app(axum_req: AxumRequest, app: Arc<App>) -> AxumResponse {
    // Capture owned copies of everything we need before consuming the body.
    let method = axum_req.method().as_str().to_string();
    let uri = axum_req.uri().clone();
    let path = uri.path().trim_start_matches('/').to_string();
    let query = uri.query().unwrap_or("").to_string();
    let headers = axum_req.headers().clone();

    // Read the body bytes (capped at 1 MiB for a forum form post).
    let bytes = match axum::body::to_bytes(axum_req.into_body(), 1024 * 1024).await {
        Ok(b) => b,
        Err(e) => {
            tracing::warn!(error = %e, "failed to read body");
            return (StatusCode::BAD_REQUEST, "bad body").into_response();
        }
    };

    let mut xf_req = build_request(&method, &path, &query, &headers, &bytes);
    let resp = app.handle(&mut xf_req);
    to_axum(resp)
}

/// Build an [`xf_core::mvc::Request`] from raw HTTP inputs.
fn build_request(
    method: &str,
    path: &str,
    query: &str,
    headers: &HeaderMap,
    body: &Bytes,
) -> Request {
    let method = Method::from_str(method);
    let mut req = Request {
        method,
        path: path.to_string(),
        query: parse_qs(query),
        form: HashMap::new(),
        headers: HashMap::new(),
        cookies: HashMap::new(),
        remote_ip: headers
            .get("x-forwarded-for")
            .and_then(|v| v.to_str().ok())
            .and_then(|s| s.split(',').next())
            .unwrap_or("127.0.0.1")
            .trim()
            .to_string(),
        response_type: String::new(),
        visitor: None,
    };

    // Copy headers (lowercased).
    for (k, v) in headers.iter() {
        if let Ok(val) = v.to_str() {
            req.headers.insert(k.as_str().to_string(), val.to_string());
        }
    }

    // Detect response type hint (`_xfResponseType` or `.json` extension).
    if let Some(rt) = req.query.get("_xfResponseType") {
        req.response_type = rt.clone();
    } else if path.ends_with(".json") {
        req.response_type = "json".into();
        req.path = path.trim_end_matches(".json").to_string();
    }

    // Parse cookies from the Cookie header.
    if let Some(cookie_hdr) = headers.get("cookie").and_then(|v| v.to_str().ok()) {
        for pair in cookie_hdr.split(';') {
            if let Some((k, v)) = pair.trim().split_once('=') {
                req.cookies.insert(k.to_string(), v.to_string());
            }
        }
    }

    // Parse a urlencoded form body.
    let ct = headers
        .get("content-type")
        .and_then(|v| v.to_str().ok())
        .unwrap_or("");
    if ct.starts_with("application/x-www-form-urlencoded") && !body.is_empty() {
        if let Ok(s) = std::str::from_utf8(body) {
            req.form = parse_qs(s);
        }
    }

    req
}

/// Parse `key=value&key2=value2` (URL-decoded).
fn parse_qs(s: &str) -> HashMap<String, String> {
    let mut out = HashMap::new();
    for pair in s.split('&') {
        if pair.is_empty() {
            continue;
        }
        let (k, v) = match pair.split_once('=') {
            Some((k, v)) => (k, v),
            None => (pair, ""),
        };
        out.insert(url_decode(k), url_decode(v));
    }
    out
}

/// Minimal percent-decoding (handles `%XX` and `+`).
fn url_decode(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    let mut chars = s.chars();
    while let Some(c) = chars.next() {
        match c {
            '+' => out.push(' '),
            '%' => {
                let mut hex = String::new();
                if let Some(a) = chars.next() {
                    hex.push(a);
                }
                if let Some(b) = chars.next() {
                    hex.push(b);
                }
                if let Ok(byte) = u8::from_str_radix(&hex, 16) {
                    out.push(byte as char);
                } else {
                    out.push('%');
                    out.push_str(&hex);
                }
            }
            _ => out.push(c),
        }
    }
    out
}

/// Convert an [`xf_core::mvc::Response`] into an axum response.
fn to_axum(resp: Response) -> AxumResponse {
    let status = StatusCode::from_u16(resp.status).unwrap_or(StatusCode::OK);
    let mut headers = HeaderMap::new();
    for (k, v) in resp.headers {
        if let (Ok(name), Ok(val)) = (
            HeaderName::from_bytes(k.as_bytes()),
            HeaderValue::from_str(&v),
        ) {
            headers.insert(name, val);
        }
    }
    (status, headers, resp.body).into_response()
}
