//! xenforo-rs server binary.
//!
//! Usage:
//!     xf                  # start the HTTP server (alias of `serve`)
//!     xf serve            # start the HTTP server
//!     xf install          # create / migrate the database
//!     xf seed             # insert demo forum + admin user + welcome thread
//!     xf create-user --username X --email Y --password Z [--admin]
mod cli;
mod http;

fn main() {
    // Initialise structured logging.
    tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| tracing_subscriber::EnvFilter::new("info")),
        )
        .with_target(false)
        .compact()
        .init();

    let args: Vec<String> = std::env::args().collect();
    std::process::exit(cli::run(&args));
}
