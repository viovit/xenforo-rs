//! Command-line interface — mirrors `xf cmd.php` (install / seed / create-user / serve).
use std::path::Path;
use xf_core::app::App;
use xf_core::config::Config;
use xf_core::permission;

/// Parse argv and dispatch a subcommand. Returns the process exit code.
pub fn run(args: &[String]) -> i32 {
    let cmd = args.get(1).map(|s| s.as_str()).unwrap_or("serve");
    let cfg = load_config(args);

    match cmd {
        "serve" | "server" => serve(&cfg),
        "install" => install(&cfg),
        "seed" => seed(&cfg),
        "create-user" => create_user(&cfg, args),
        "help" | "--help" | "-h" => {
            print_help();
            0
        }
        other => {
            eprintln!("Unknown command: {other}");
            print_help();
            2
        }
    }
}

fn load_config(args: &[String]) -> Config {
    // --config <path>
    let mut iter = args.iter().skip(1);
    let mut path: Option<&str> = None;
    while let Some(a) = iter.next() {
        if a == "--config" {
            if let Some(p) = iter.next() {
                path = Some(p.as_str());
            }
        }
    }
    if let Some(p) = path {
        Config::load(Path::new(p))
    } else {
        Config::load(Path::new("config.json"))
    }
}

fn print_help() {
    eprintln!(
        "xenforo-rs {version} — Rust port of the XenForo 2.3 forum engine\n\
         \n\
         USAGE:\n    xf <command> [--config config.json]\n\
         \n\
         COMMANDS:\n    \
         serve         Start the HTTP server (default)\n    \
         install       Create / migrate the database\n    \
         seed          Insert demo forum + welcome thread\n    \
         create-user   Create a user (--username --email --password [--admin])\n    \
         help          Show this message",
        version = env!("CARGO_PKG_VERSION")
    );
}

fn install(cfg: &Config) -> i32 {
    match App::boot(cfg.clone()) {
        Ok(app) => {
            // Boot already runs migrations; report counts.
            let stats = app
                .db
                .with_conn(|c| {
                    let u: i64 = c.query_row("SELECT COUNT(*) FROM xf_user", [], |r| r.get(0))?;
                    let n: i64 = c.query_row("SELECT COUNT(*) FROM xf_node", [], |r| r.get(0))?;
                    Ok::<_, rusqlite::Error>((u, n))
                })
                .unwrap_or((0, 0));
            println!(
                "✓ Database ready at `{}` ({} users, {} nodes).",
                cfg.db_path, stats.0, stats.1
            );
            0
        }
        Err(e) => {
            eprintln!("✗ install failed: {e}");
            1
        }
    }
}

fn seed(cfg: &Config) -> i32 {
    let app = match App::boot(cfg.clone()) {
        Ok(a) => a,
        Err(e) => {
            eprintln!("✗ boot failed: {e}");
            return 1;
        }
    };
    // Ensure the default Registered + admin users exist with known credentials.
    let admin_id = match app.user_repo().get_user_by_name("admin") {
        Ok(Some(u)) => u.user_id,
        _ => match app.user_repo().create_user("admin", "admin@example.com", "admin1234", 1) {
            Ok(id) => {
                // Promote to admin.
                let _ = app.db.execute(
                    "UPDATE xf_user SET is_admin = 1, user_group_id = 1, permission_combination_id = 1 WHERE user_id = ?",
                    &[&id as &dyn rusqlite::ToSql],
                );
                println!("✓ Created admin user (username: admin, password: admin1234)");
                id
            }
            Err(e) => {
                eprintln!("✗ create admin failed: {e}");
                return 1;
            }
        },
    };

    // Grant admin (group 1) content permissions on the default forum node (2).
    let _ = permission::grant_content(&app.db, 1, "node", 2, "forum", "view", "allow");
    let _ = permission::grant_content(&app.db, 1, "node", 2, "forum", "viewContent", "allow");
    let _ = permission::grant_content(&app.db, 1, "node", 2, "forum", "postThread", "allow");
    let _ = permission::grant_content(&app.db, 1, "node", 2, "forum", "reply", "allow");
    let _ = permission::grant_content(&app.db, 1, "node", 2, "forum", "deleteOwnPost", "allow");

    // Welcome thread in the default forum (node 2).
    let welcome = "Welcome to xenforo-rs — a Rust port of the XenForo 2.3 forum engine.\n\
                   \n\
                   This installation ships with the core pub functionality: forum list, \
                   thread view, BBCode rendering, registration and login (bcrypt), \
                   member profiles, search and a lightweight admin dashboard.\n\
                   \n\
                   Log in as [b]admin[/b] / [i]admin1234[/i] to try posting.\n\
                   \n\
                   [code]cargo run -- serve[/code]";
    let (tid, _) = app
        .thread_repo()
        .create_thread(2, admin_id, "admin", "Welcome to xenforo-rs", welcome)
        .expect("seed welcome thread");
    let _ = app.forum_repo().rebuild_totals(2);
    println!("✓ Seeded welcome thread #{tid} in forum #2");
    0
}

fn create_user(cfg: &Config, args: &[String]) -> i32 {
    let mut username = String::new();
    let mut email = String::new();
    let mut password = String::new();
    let mut admin = false;
    let mut iter = args.iter().skip(2);
    while let Some(a) = iter.next() {
        match a.as_str() {
            "--username" => username = iter.next().cloned().unwrap_or_default(),
            "--email" => email = iter.next().cloned().unwrap_or_default(),
            "--password" => password = iter.next().cloned().unwrap_or_default(),
            "--admin" => admin = true,
            _ => {}
        }
    }
    if username.is_empty() || email.is_empty() || password.is_empty() {
        eprintln!("Usage: xf create-user --username X --email Y --password Z [--admin]");
        return 2;
    }
    let app = match App::boot(cfg.clone()) {
        Ok(a) => a,
        Err(e) => {
            eprintln!("✗ boot failed: {e}");
            return 1;
        }
    };
    let group = if admin { 1 } else { 3 };
    match app.user_repo().create_user(&username, &email, &password, group) {
        Ok(id) => {
            if admin {
                let _ = app.db.execute(
                    "UPDATE xf_user SET is_admin = 1 WHERE user_id = ?",
                    &[&id as &dyn rusqlite::ToSql],
                );
            }
            println!("✓ Created user #{id} ({username})");
            0
        }
        Err(e) => {
            eprintln!("✗ create-user failed: {e}");
            1
        }
    }
}

fn serve(cfg: &Config) -> i32 {
    let app = match App::boot(cfg.clone()) {
        Ok(a) => a,
        Err(e) => {
            eprintln!("✗ boot failed: {e}");
            return 1;
        }
    };
    let listen = cfg.listen.clone();
    println!("▶ xenforo-rs listening on http://{listen}  (board: {})", cfg.board_title);
    let router = crate::http::build_router(app);
    let runtime = match tokio::runtime::Builder::new_multi_thread()
        .enable_all()
        .build()
    {
        Ok(rt) => rt,
        Err(e) => {
            eprintln!("✗ tokio runtime: {e}");
            return 1;
        }
    };
    runtime.block_on(async move {
        let listener = match tokio::net::TcpListener::bind(&listen).await {
            Ok(l) => l,
            Err(e) => {
                eprintln!("✗ bind {listen} failed: {e}");
                return;
            }
        };
        if let Err(e) = axum::serve(listener, router).await {
            eprintln!("✗ server error: {e}");
        }
    });
    0
}
