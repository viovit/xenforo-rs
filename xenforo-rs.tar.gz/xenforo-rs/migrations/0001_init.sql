-- ============================================================================
-- xenforo-rs schema migration 0001_init
-- ----------------------------------------------------------------------------
-- Mirrors the XenForo 2.3 `xf_*` table layout as declared by the entity
-- `getStructure()` methods (src/XF/Entity/*.php). Column names and types match
-- 1:1 where SQLite's type system allows (JSON_ARRAY/LIST_COMMA -> TEXT,
-- BOOL -> INTEGER 0/1, BINARY -> TEXT, UINT/INT -> INTEGER).
-- ============================================================================

-- ---------------------------------------------------------------------------
-- User groups & permission combinations
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS xf_user_group (
    user_group_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    title           TEXT NOT NULL DEFAULT '',
    display_style_priority INTEGER NOT NULL DEFAULT 0,
    username_css    TEXT NOT NULL DEFAULT '',
    user_title     TEXT NOT NULL DEFAULT '',
    banner_css     TEXT NOT NULL DEFAULT '',
    banner_text    TEXT NOT NULL DEFAULT ''
);

-- A permission combination is a unique set of user groups a user belongs to.
CREATE TABLE IF NOT EXISTS xf_permission_combination (
    permission_combination_id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_group_id            INTEGER NOT NULL DEFAULT 0,
    secondary_group_ids      TEXT NOT NULL DEFAULT '',
    cache_value              TEXT
);

-- Global + content permissions keyed by combination + content.
CREATE TABLE IF NOT EXISTS xf_permission_entry (
    entry_id               INTEGER PRIMARY KEY AUTOINCREMENT,
    permission_combination_id INTEGER NOT NULL DEFAULT 0,
    content_type           TEXT NOT NULL DEFAULT '',
    content_id             INTEGER NOT NULL DEFAULT 0,
    permission_group_id    TEXT NOT NULL DEFAULT '',
    permission_id          TEXT NOT NULL DEFAULT '',
    permission_value       TEXT NOT NULL DEFAULT 'reset',  -- reset|allow|deny|content_allow
    permission_value_int   INTEGER NOT NULL DEFAULT 0,
    UNIQUE(permission_combination_id, content_type, content_id, permission_group_id, permission_id)
);

-- ---------------------------------------------------------------------------
-- Users
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS xf_user (
    user_id              INTEGER PRIMARY KEY AUTOINCREMENT,
    username             TEXT NOT NULL,
    username_date        INTEGER NOT NULL DEFAULT 0,
    username_date_visible INTEGER NOT NULL DEFAULT 0,
    email                TEXT NOT NULL DEFAULT '',
    style_id             INTEGER NOT NULL DEFAULT 0,
    style_variation      TEXT NOT NULL DEFAULT '',
    language_id          INTEGER NOT NULL DEFAULT 0,
    timezone             TEXT NOT NULL DEFAULT 'Europe/London',
    visible              INTEGER NOT NULL DEFAULT 1,
    activity_visible     INTEGER NOT NULL DEFAULT 1,
    user_group_id        INTEGER NOT NULL,
    secondary_group_ids  TEXT NOT NULL DEFAULT '',
    display_style_group_id INTEGER NOT NULL DEFAULT 0,
    permission_combination_id INTEGER NOT NULL DEFAULT 0,
    message_count        INTEGER NOT NULL DEFAULT 0,
    question_solution_count INTEGER NOT NULL DEFAULT 0,
    alerts_unviewed      INTEGER NOT NULL DEFAULT 0,
    alerts_unread        INTEGER NOT NULL DEFAULT 0,
    conversations_unread INTEGER NOT NULL DEFAULT 0,
    register_date        INTEGER NOT NULL DEFAULT 0,
    last_activity        INTEGER NOT NULL DEFAULT 0,
    last_summary_email_date INTEGER,
    trophy_points        INTEGER NOT NULL DEFAULT 0,
    avatar_date          INTEGER NOT NULL DEFAULT 0,
    avatar_width         INTEGER NOT NULL DEFAULT 0,
    avatar_height        INTEGER NOT NULL DEFAULT 0,
    avatar_highdpi       INTEGER NOT NULL DEFAULT 0,
    avatar_optimized     INTEGER NOT NULL DEFAULT 0,
    gravatar             TEXT NOT NULL DEFAULT '',
    user_state           TEXT NOT NULL DEFAULT 'valid',
    security_lock        TEXT NOT NULL DEFAULT '',
    is_moderator         INTEGER NOT NULL DEFAULT 0,
    is_admin             INTEGER NOT NULL DEFAULT 0,
    is_staff             INTEGER NOT NULL DEFAULT 0,
    is_banned            INTEGER NOT NULL DEFAULT 0,
    reaction_score      INTEGER NOT NULL DEFAULT 0,
    vote_score          INTEGER NOT NULL DEFAULT 0,
    custom_title        TEXT NOT NULL DEFAULT '',
    warning_points      INTEGER NOT NULL DEFAULT 0,
    secret_key          TEXT NOT NULL,
    privacy_policy_accepted INTEGER NOT NULL DEFAULT 0,
    terms_accepted      INTEGER NOT NULL DEFAULT 0,
    UNIQUE(username)
);

CREATE TABLE IF NOT EXISTS xf_user_auth (
    user_id      INTEGER PRIMARY KEY,
    scheme_class TEXT NOT NULL DEFAULT 'XF:Core12',
    data         TEXT NOT NULL DEFAULT '{}'  -- JSON: {"hash":"$2b$..."}
);

CREATE TABLE IF NOT EXISTS xf_user_option (
    user_id INTEGER PRIMARY KEY,
    show_signature      INTEGER NOT NULL DEFAULT 1,
    content_show_signature INTEGER NOT NULL DEFAULT 1,
    receive_admin_email INTEGER NOT NULL DEFAULT 1,
    email_on_conversation INTEGER NOT NULL DEFAULT 1,
    is_discouraged     INTEGER NOT NULL DEFAULT 0,
    creation_watch_state TEXT NOT NULL DEFAULT 'watch_update',
    interaction_watch_state TEXT NOT NULL DEFAULT 'watch_update'
);

CREATE TABLE IF NOT EXISTS xf_user_privacy (
    user_id INTEGER PRIMARY KEY,
    allow_view_profile  TEXT NOT NULL DEFAULT 'everyone',
    allow_post_profile  TEXT NOT NULL DEFAULT 'members',
    allow_send_personal_conversation TEXT NOT NULL DEFAULT 'members',
    allow_view_identities TEXT NOT NULL DEFAULT 'everyone',
    allow_receive_news_feed TEXT NOT NULL DEFAULT 'everyone'
);

CREATE TABLE IF NOT EXISTS xf_user_profile (
    user_id INTEGER PRIMARY KEY,
    dob_day   INTEGER NOT NULL DEFAULT 0,
    dob_month INTEGER NOT NULL DEFAULT 0,
    dob_year  INTEGER NOT NULL DEFAULT 0,
    status    TEXT NOT NULL DEFAULT '',
    status_date INTEGER NOT NULL DEFAULT 0,
    status_profile_post_id INTEGER NOT NULL DEFAULT 0,
    signature TEXT NOT NULL DEFAULT '',
    website   TEXT NOT NULL DEFAULT '',
    location  TEXT NOT NULL DEFAULT '',
    following TEXT NOT NULL DEFAULT '',
    followers TEXT NOT NULL DEFAULT '',
    about     TEXT NOT NULL DEFAULT ''
);

-- ---------------------------------------------------------------------------
-- Node tree (forums / categories / link-forums / pages ...)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS xf_node (
    node_id            INTEGER PRIMARY KEY AUTOINCREMENT,
    title              TEXT NOT NULL,
    node_name          TEXT UNIQUE,
    description        TEXT NOT NULL DEFAULT '',
    node_type_id       TEXT NOT NULL,
    parent_node_id     INTEGER NOT NULL DEFAULT 0,
    display_order     INTEGER NOT NULL DEFAULT 1,
    lft               INTEGER NOT NULL DEFAULT 0,
    rgt               INTEGER NOT NULL DEFAULT 0,
    depth             INTEGER NOT NULL DEFAULT 0,
    style_id          INTEGER NOT NULL DEFAULT 0,
    effective_style_id INTEGER NOT NULL DEFAULT 0,
    display_in_list   INTEGER NOT NULL DEFAULT 1,
    breadcrumb_data   TEXT NOT NULL DEFAULT '[]',
    navigation_id     TEXT NOT NULL DEFAULT '',
    effective_navigation_id TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS xf_category (
    node_id INTEGER PRIMARY KEY
);

CREATE TABLE IF NOT EXISTS xf_forum (
    node_id                     INTEGER PRIMARY KEY,
    discussion_count            INTEGER NOT NULL DEFAULT 0,
    message_count               INTEGER NOT NULL DEFAULT 0,
    last_post_id                INTEGER NOT NULL DEFAULT 0,
    last_post_date              INTEGER NOT NULL DEFAULT 0,
    last_post_user_id           INTEGER NOT NULL DEFAULT 0,
    last_post_username          TEXT NOT NULL DEFAULT '',
    last_thread_id              INTEGER NOT NULL DEFAULT 0,
    last_thread_title           TEXT NOT NULL DEFAULT '',
    last_thread_prefix_id       INTEGER NOT NULL DEFAULT 0,
    moderate_threads            INTEGER NOT NULL DEFAULT 0,
    moderate_replies            INTEGER NOT NULL DEFAULT 0,
    forum_type_id               TEXT NOT NULL DEFAULT 'discussion',
    type_config                 TEXT NOT NULL DEFAULT '[]',
    allow_posting               INTEGER NOT NULL DEFAULT 1,
    count_messages              INTEGER NOT NULL DEFAULT 1,
    auto_feature                INTEGER NOT NULL DEFAULT 0,
    find_new                    INTEGER NOT NULL DEFAULT 1,
    allow_index                 TEXT NOT NULL DEFAULT 'allow',
    index_criteria              TEXT NOT NULL DEFAULT '[]',
    require_prefix              INTEGER NOT NULL DEFAULT 0,
    allowed_watch_notifications TEXT NOT NULL DEFAULT 'all',
    field_cache                 TEXT NOT NULL DEFAULT '[]',
    prefix_cache                TEXT NOT NULL DEFAULT '[]',
    prompt_cache                TEXT NOT NULL DEFAULT '[]',
    default_prefix_id           INTEGER NOT NULL DEFAULT 0,
    default_sort_order          TEXT NOT NULL DEFAULT 'last_post_date',
    default_sort_direction     TEXT NOT NULL DEFAULT 'desc',
    list_date_limit_days        INTEGER NOT NULL DEFAULT 0,
    min_tags                    INTEGER NOT NULL DEFAULT 0
);

-- ---------------------------------------------------------------------------
-- Threads & posts
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS xf_thread (
    thread_id                   INTEGER PRIMARY KEY AUTOINCREMENT,
    node_id                     INTEGER NOT NULL,
    title                       TEXT NOT NULL,
    reply_count                 INTEGER NOT NULL DEFAULT 0,
    view_count                  INTEGER NOT NULL DEFAULT 0,
    user_id                     INTEGER NOT NULL,
    username                    TEXT NOT NULL,
    post_date                   INTEGER NOT NULL DEFAULT 0,
    sticky                      INTEGER NOT NULL DEFAULT 0,
    discussion_state            TEXT NOT NULL DEFAULT 'visible',
    discussion_open             INTEGER NOT NULL DEFAULT 1,
    discussion_type             TEXT NOT NULL DEFAULT '',
    type_data                   TEXT NOT NULL DEFAULT '[]',
    index_state                 TEXT NOT NULL DEFAULT 'default',
    first_post_id               INTEGER NOT NULL DEFAULT 0,
    last_post_date              INTEGER NOT NULL DEFAULT 0,
    last_post_id                INTEGER NOT NULL DEFAULT 0,
    last_post_user_id           INTEGER NOT NULL DEFAULT 0,
    last_post_username          TEXT NOT NULL DEFAULT '',
    first_post_reaction_score  INTEGER NOT NULL DEFAULT 0,
    first_post_reactions        TEXT,
    prefix_id                   INTEGER NOT NULL DEFAULT 0,
    custom_fields               TEXT NOT NULL DEFAULT '[]',
    tags                        TEXT NOT NULL DEFAULT '[]'
);
CREATE INDEX IF NOT EXISTS idx_thread_node ON xf_thread(node_id, sticky, last_post_date);
CREATE INDEX IF NOT EXISTS idx_thread_user ON xf_thread(user_id);

CREATE TABLE IF NOT EXISTS xf_post (
    post_id          INTEGER PRIMARY KEY AUTOINCREMENT,
    thread_id        INTEGER NOT NULL,
    user_id          INTEGER NOT NULL,
    username         TEXT NOT NULL,
    post_date        INTEGER NOT NULL,
    message          TEXT NOT NULL,
    ip_id            INTEGER NOT NULL DEFAULT 0,
    message_state    TEXT NOT NULL DEFAULT 'visible',
    attach_count     INTEGER NOT NULL DEFAULT 0,
    warning_id       INTEGER NOT NULL DEFAULT 0,
    warning_message  TEXT NOT NULL DEFAULT '',
    position         INTEGER NOT NULL DEFAULT 0,
    type_data        TEXT NOT NULL DEFAULT '[]',
    last_edit_date   INTEGER NOT NULL DEFAULT 0,
    last_edit_user_id INTEGER NOT NULL DEFAULT 0,
    edit_count       INTEGER NOT NULL DEFAULT 0,
    embed_metadata   TEXT
);
CREATE INDEX IF NOT EXISTS idx_post_thread ON xf_post(thread_id, position);
CREATE INDEX IF NOT EXISTS idx_post_user ON xf_post(user_id);

-- Read state tracking.
CREATE TABLE IF NOT EXISTS xf_thread_read (
    thread_id INTEGER NOT NULL,
    user_id   INTEGER NOT NULL,
    thread_read_date INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY(thread_id, user_id)
);
CREATE TABLE IF NOT EXISTS xf_forum_read (
    node_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    forum_read_date INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY(node_id, user_id)
);

-- ---------------------------------------------------------------------------
-- Sessions / activity
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS xf_session (
    session_id        TEXT PRIMARY KEY,
    session_data     TEXT NOT NULL DEFAULT '{}',
    user_id          INTEGER NOT NULL DEFAULT 0,
    ip               TEXT NOT NULL DEFAULT '',
    last_activity    INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS xf_session_activity (
    user_id          INTEGER NOT NULL DEFAULT 0,
    unique_key       TEXT NOT NULL DEFAULT '',
    controller       TEXT NOT NULL DEFAULT '',
    action           TEXT NOT NULL DEFAULT '',
    params           TEXT NOT NULL DEFAULT '{}',
    view_state       TEXT NOT NULL DEFAULT '',
    ip               TEXT NOT NULL DEFAULT '',
    last_activity    INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY(user_id, unique_key)
);

-- Deletion log (lightweight).
CREATE TABLE IF NOT EXISTS xf_deletion_log (
    deletion_log_id INTEGER PRIMARY KEY AUTOINCREMENT,
    content_type   TEXT NOT NULL,
    content_id     INTEGER NOT NULL,
    delete_user_id INTEGER NOT NULL DEFAULT 0,
    delete_username TEXT NOT NULL DEFAULT '',
    delete_date    INTEGER NOT NULL DEFAULT 0,
    delete_reason  TEXT NOT NULL DEFAULT '',
    UNIQUE(content_type, content_id)
);

-- ============================================================================
-- Seed data: default user groups, permission combinations, root category
-- and a welcome forum.
-- ============================================================================
INSERT OR IGNORE INTO xf_user_group (user_group_id, title, display_style_priority, user_title)
VALUES
    (1, 'Administrateur', 100, 'Administrator'),
    (2, 'Moderating', 90, 'Moderator'),
    (3, 'Registered', 50, ''),
    (4, 'Guest', 0, 'Guest');

INSERT OR IGNORE INTO xf_permission_combination (permission_combination_id, user_group_id, secondary_group_ids, cache_value)
VALUES
    (1, 1, '', ''),
    (2, 2, '', ''),
    (3, 3, '', ''),
    (4, 4, '', '');

-- Global permission grants: allow the forum basics for every combination.
-- permission_group_id 'forum', permission ids 'view','viewContent','postThread','reply','editOwnPost','deleteOwnPost'
INSERT OR IGNORE INTO xf_permission_entry
    (permission_combination_id, content_type, content_id, permission_group_id, permission_id, permission_value)
VALUES
    (1, 'global', 0, 'forum', 'view',            'allow'),
    (1, 'global', 0, 'forum', 'viewContent',     'allow'),
    (1, 'global', 0, 'forum', 'postThread',      'allow'),
    (1, 'global', 0, 'forum', 'reply',           'allow'),
    (1, 'global', 0, 'forum', 'editOwnPost',     'allow'),
    (1, 'global', 0, 'forum', 'deleteOwnPost',   'allow'),
    (1, 'global', 0, 'general', 'view',          'allow'),
    (2, 'global', 0, 'forum', 'view',            'allow'),
    (2, 'global', 0, 'forum', 'viewContent',     'allow'),
    (2, 'global', 0, 'forum', 'postThread',      'allow'),
    (2, 'global', 0, 'forum', 'reply',           'allow'),
    (2, 'global', 0, 'general', 'view',          'allow'),
    (3, 'global', 0, 'forum', 'view',            'allow'),
    (3, 'global', 0, 'forum', 'viewContent',     'allow'),
    (3, 'global', 0, 'forum', 'postThread',      'allow'),
    (3, 'global', 0, 'forum', 'reply',           'allow'),
    (3, 'global', 0, 'forum', 'editOwnPost',     'allow'),
    (3, 'global', 0, 'forum', 'deleteOwnPost',   'allow'),
    (3, 'global', 0, 'general', 'view',          'allow'),
    (4, 'global', 0, 'forum', 'view',            'allow'),
    (4, 'global', 0, 'forum', 'viewContent',     'allow'),
    (4, 'global', 0, 'general', 'view',          'allow');

-- Root category node + a default discussion forum.
INSERT OR IGNORE INTO xf_node (node_id, title, node_name, description, node_type_id, parent_node_id, display_order, lft, rgt, depth, display_in_list)
VALUES
    (1, 'Main category', 'main', '', 'Category', 0, 1, 1, 4, 0, 1),
    (2, 'General discussion', 'general', 'A general discussion forum.', 'Forum', 1, 1, 2, 3, 1, 1);

INSERT OR IGNORE INTO xf_category (node_id) VALUES (1);
INSERT OR IGNORE INTO xf_forum (node_id, allow_posting, count_messages, find_new) VALUES (2, 1, 1, 1);
