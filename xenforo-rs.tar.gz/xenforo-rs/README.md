# xenforo-rs

A Rust port of the **XenForo 2.3** forum engine. This is an architecture-faithful
rewrite of the XenForo 2.3.13 codebase (~444k lines of PHP) — not a line-by-line
translation of every file, but a working Rust forum engine that reproduces
XenForo's core architecture and the public-facing functionality 1:1 in spirit.

## What was ported

| XenForo (`src/XF/`)                         | xenforo-rs (`crates/xf-core/src/`)            |
| ------------------------------------------- | --------------------------------------------- |
| `App.php` (container)                       | `app.rs`                                      |
| `Mvc/Router`, `Dispatcher`, `Controller`    | `mvc/{router,dispatcher,controller}.rs`       |
| `Mvc/Reply/*`, `Mvc/Renderer/*`             | `mvc/{reply,renderer}.rs`                     |
| `Mvc/Entity/{Entity,Structure,Repository,Finder,Manager}` | `entity/`                          |
| `Entity/{User,UserAuth,UserGroup,Forum,Thread,Post,Node,Category,...}` | `entities/` (full column sets from `getStructure()`) |
| `Repository/{User,Forum,Thread,Post,Node}`  | `repositories/`                               |
| `BbCode/{Parser,RuleSet,Renderer/Html}`     | `bbcode/` (30+ default tags)                  |
| `Authentication/Core12` (bcrypt)            | `auth/core12.rs`                              |
| `Session/Session`                           | `session/`                                    |
| `Permission/*` (combination + content)      | `permission/`                                 |
| `Str/Formatter`, `Util/Str`                 | `str/`                                        |
| `Template/Templater`                        | `template/` (minijinja-backed)                |
| `Pub/Controller/{Index,Forum,Thread,Post,Member,Login,Logout,Register,Account,Online,Search}` | `pubc/controllers/` |
| `xf_*` schema                               | `migrations/0001_init.sql`                    |
| `index.php` front controller                | `crates/xf-server/src/http.rs` (axum adapter) |
| `cmd.php`                                   | `crates/xf-server/src/cli.rs`                 |

The database schema mirrors the real `xf_*` tables (column names and types from
each entity's `getStructure()`), backed by SQLite.

## Features

- **Forum list / category tree** (`/`) — nested-set node rendering.
- **Forum view** (`/forums/{id}/{slug}`) — paged thread list, last-post info.
- **Thread view** (`/threads/{id}/{slug}`) — paged posts, BBCode rendering, view counter.
- **Create thread** (`/forums/{id}/post-thread`) and **reply** (`/threads/{id}/add-reply`).
- **Post edit / delete** (`/posts/{id}/{edit,delete}`), soft-delete + counter rebuild.
- **Registration / login / logout** with bcrypt (`XF:Core12`), CSRF tokens, sessions.
- **Member list & profiles** (`/members`, `/members/{id}`), follow/unfollow.
- **Search** (`/search?q=`) across thread titles and post bodies.
- **Online list** (`/online`) from `xf_session_activity`.
- **Admin dashboard** (`/admin`) — gated on `is_admin`, board statistics.
- **Permissions** — global + per-node (`view`, `viewContent`, `postThread`, `reply`, `editOwnPost`, `deleteOwnPost`).
- **BBCode** — `b i u s color font size url email img quote code icode php html list spoiler ispoiler table tr th td hr heading indent media attach user` … with auto-linking and XSS-safe URL sanitising.
- **Templates** — `PAGE_CONTAINER` + page templates with `{% extends %}`, `{% block %}`, `{% include %}`, `{% for %}`.
- **CLI** — `install`, `seed`, `create-user`, `serve`.

## Build & run

### Prerequisites
Rust toolchain (stable, 1.75+). SQLite is compiled in (bundled via `rusqlite`), so
no system database is required.

### From source
```bash
cargo build --release -p xf-server
# Initialise the database and insert the demo forum + admin user:
./target/release/xf install
./target/release/xf seed     # admin / admin1234
./target/release/xf serve    # http://localhost:8080
```

Configuration is read from `config.json` (next to the binary) and can be
overridden with environment variables: `XF_BOARD_TITLE`, `XF_BOARD_URL`,
`XF_DB_PATH`, `XF_LISTEN`, `XF_REGISTRATION_ENABLED`, `RUST_LOG`.

### With Docker
```bash
docker compose up --build
# → http://localhost:8080   (auto installs + seeds on first boot)
```

Log in with **admin / admin1234**.

## Tests
```bash
cargo test --workspace
```
Unit tests cover BBCode parsing/rendering, the router, bcrypt auth and string
helpers; integration tests boot an in-memory app and exercise register → login →
thread → reply end-to-end through the real MVC pipeline.

## Layout
```
xenforo-rs/
├── Cargo.toml              # workspace
├── Dockerfile
├── docker-compose.yml
├── config.json
├── migrations/0001_init.sql
├── templates/              # PAGE_CONTAINER + forum/thread/member/... templates
├── static/xf.css
└── crates/
    ├── xf-core/            # library: app, mvc, entity, entities, repositories,
    │                       #   bbcode, auth, session, permission, template, pubc
    └── xf-server/          # binary: axum HTTP front controller + CLI
```

## Honest scope note

A literal 1:1 port of XenForo's ~444k lines (admin control panel, add-on
manager, search index, attachment storage, payment/profile-post/conversation
systems, OAuth API, style/import system, moderator queue, etc.) is a multi
engineer-year effort. This port covers the **core architecture and the complete
public forum feature set** listed above, compiling and running with tests and
Docker. The module layout is deliberately parallel to `src/XF/` so the remaining
sub-systems can be slotted in incrementally.
